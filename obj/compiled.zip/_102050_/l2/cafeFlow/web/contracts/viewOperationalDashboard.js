/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts" enhancement="_blank"/>
export {};
