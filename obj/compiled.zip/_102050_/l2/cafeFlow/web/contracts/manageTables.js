/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/manageTables.ts" enhancement="_blank"/>
export {};
