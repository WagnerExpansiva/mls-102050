/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
export class CafeFlowAiPromotionSuggestionsBase extends CollabLitElement {
    constructor() {
        /* ── State properties (from Definition.states[]) ── */
        super(...arguments);
        this.status = '';
        this.aiPromotionSuggestionsState = 'idle';
        this.aiPromotionSuggestionsId = '';
        this.aiPromotionSuggestionsOrderId = '';
        this.aiPromotionSuggestionsMenuItemId = '';
        this.aiPromotionSuggestionsKitchenTicketId = '';
        this.aiPromotionSuggestionsStatus = '';
        this.aiPromotionSuggestionsCreatedAt = '';
        this.aiPromotionSuggestionsData = [];
        /* ── i18n ── */
        this.message_pt = {
            'aiPromotionSuggestions.section.main.title': 'Assistente IA: sugestões de itens para promover (últimos 7 dias)',
            'aiPromotionSuggestions.organism.main.title': 'Sugestões de promoção com IA',
            'aiPromotionSuggestions.intent.query.title': 'Sugestões (últimos 7 dias)',
            'aiPromotionSuggestions.field.id.label': 'Item do pedido',
            'aiPromotionSuggestions.field.orderId.label': 'Pedido',
            'aiPromotionSuggestions.field.menuItemId.label': 'Item do cardápio',
            'aiPromotionSuggestions.field.kitchenTicketId.label': 'Ticket de cozinha',
            'aiPromotionSuggestions.field.quantity.label': 'Quantidade',
            'aiPromotionSuggestions.field.unitPrice.label': 'Preço unitário',
            'aiPromotionSuggestions.field.totalPrice.label': 'Preço total',
            'aiPromotionSuggestions.field.observations.label': 'Observações',
            'aiPromotionSuggestions.filter.id.label': 'Item do pedido (ID)',
            'aiPromotionSuggestions.filter.orderId.label': 'Pedido (ID)',
            'aiPromotionSuggestions.filter.menuItemId.label': 'Item do cardápio (ID)',
            'aiPromotionSuggestions.filter.kitchenTicketId.label': 'Ticket de cozinha (ID)',
            'aiPromotionSuggestions.filter.status.label': 'Status do item',
            'aiPromotionSuggestions.filter.createdAt.label': 'Criado em',
            'aiPromotionSuggestions.action.run.label': 'Gerar sugestões',
        };
        this.message_en = {
            'aiPromotionSuggestions.section.main.title': 'AI Assistant: item promotion suggestions (last 7 days)',
            'aiPromotionSuggestions.organism.main.title': 'AI promotion suggestions',
            'aiPromotionSuggestions.intent.query.title': 'Suggestions (last 7 days)',
            'aiPromotionSuggestions.field.id.label': 'Order item',
            'aiPromotionSuggestions.field.orderId.label': 'Order',
            'aiPromotionSuggestions.field.menuItemId.label': 'Menu item',
            'aiPromotionSuggestions.field.kitchenTicketId.label': 'Kitchen ticket',
            'aiPromotionSuggestions.field.quantity.label': 'Quantity',
            'aiPromotionSuggestions.field.unitPrice.label': 'Unit price',
            'aiPromotionSuggestions.field.totalPrice.label': 'Total price',
            'aiPromotionSuggestions.field.observations.label': 'Observations',
            'aiPromotionSuggestions.filter.id.label': 'Order item (ID)',
            'aiPromotionSuggestions.filter.orderId.label': 'Order (ID)',
            'aiPromotionSuggestions.filter.menuItemId.label': 'Menu item (ID)',
            'aiPromotionSuggestions.filter.kitchenTicketId.label': 'Kitchen ticket (ID)',
            'aiPromotionSuggestions.filter.status.label': 'Item status',
            'aiPromotionSuggestions.filter.createdAt.label': 'Created at',
            'aiPromotionSuggestions.action.run.label': 'Generate suggestions',
        };
    }
    get msg() {
        const lang = this.locale ?? 'pt';
        return lang === 'en' ? this.message_en : this.message_pt;
    }
    /* ── Query action: aiPromotionSuggestions ── */
    async loadAiPromotionSuggestions() {
        this.aiPromotionSuggestionsState = 'loading';
        setState('ui.aiPromotionSuggestions.action.aiPromotionSuggestions.status', 'loading');
        this.requestUpdate();
        const params = {
            id: this.aiPromotionSuggestionsId || undefined,
            orderId: this.aiPromotionSuggestionsOrderId || undefined,
            menuItemId: this.aiPromotionSuggestionsMenuItemId || undefined,
            kitchenTicketId: this.aiPromotionSuggestionsKitchenTicketId || undefined,
            status: (this.aiPromotionSuggestionsStatus || undefined),
            createdAt: this.aiPromotionSuggestionsCreatedAt || undefined,
        };
        const options = { mode: 'silent' };
        try {
            const response = await execBff('cafeFlow.aiPromotionSuggestions.aiPromotionSuggestions', params, options);
            if (response.ok) {
                this.aiPromotionSuggestionsData = response.data ?? [];
                setState('ui.aiPromotionSuggestions.data.aiPromotionSuggestions', this.aiPromotionSuggestionsData);
                this.aiPromotionSuggestionsState = 'success';
                setState('ui.aiPromotionSuggestions.action.aiPromotionSuggestions.status', 'success');
            }
            else {
                this.aiPromotionSuggestionsState = 'error';
                setState('ui.aiPromotionSuggestions.action.aiPromotionSuggestions.status', 'error');
            }
        }
        catch {
            this.aiPromotionSuggestionsState = 'error';
            setState('ui.aiPromotionSuggestions.action.aiPromotionSuggestions.status', 'error');
        }
        this.requestUpdate();
    }
    handleAiPromotionSuggestionsClick() {
        runBlockingUiAction(async () => {
            await this.loadAiPromotionSuggestions();
        });
    }
    /* ── State setters ── */
    setAiPromotionSuggestionsId(value) {
        this.aiPromotionSuggestionsId = value;
        setState('ui.aiPromotionSuggestions.input.aiPromotionSuggestions.id', value);
        this.requestUpdate();
    }
    handleAiPromotionSuggestionsIdChange(e) {
        const target = e.target;
        this.setAiPromotionSuggestionsId(target.value);
    }
    setAiPromotionSuggestionsOrderId(value) {
        this.aiPromotionSuggestionsOrderId = value;
        setState('ui.aiPromotionSuggestions.input.aiPromotionSuggestions.orderId', value);
        this.requestUpdate();
    }
    handleAiPromotionSuggestionsOrderIdChange(e) {
        const target = e.target;
        this.setAiPromotionSuggestionsOrderId(target.value);
    }
    setAiPromotionSuggestionsMenuItemId(value) {
        this.aiPromotionSuggestionsMenuItemId = value;
        setState('ui.aiPromotionSuggestions.input.aiPromotionSuggestions.menuItemId', value);
        this.requestUpdate();
    }
    handleAiPromotionSuggestionsMenuItemIdChange(e) {
        const target = e.target;
        this.setAiPromotionSuggestionsMenuItemId(target.value);
    }
    setAiPromotionSuggestionsKitchenTicketId(value) {
        this.aiPromotionSuggestionsKitchenTicketId = value;
        setState('ui.aiPromotionSuggestions.input.aiPromotionSuggestions.kitchenTicketId', value);
        this.requestUpdate();
    }
    handleAiPromotionSuggestionsKitchenTicketIdChange(e) {
        const target = e.target;
        this.setAiPromotionSuggestionsKitchenTicketId(target.value);
    }
    setAiPromotionSuggestionsStatus(value) {
        this.aiPromotionSuggestionsStatus = value;
        setState('ui.aiPromotionSuggestions.input.aiPromotionSuggestions.status', value);
        this.requestUpdate();
    }
    handleAiPromotionSuggestionsStatusChange(e) {
        const target = e.target;
        this.setAiPromotionSuggestionsStatus(target.value);
    }
    setAiPromotionSuggestionsCreatedAt(value) {
        this.aiPromotionSuggestionsCreatedAt = value;
        setState('ui.aiPromotionSuggestions.input.aiPromotionSuggestions.createdAt', value);
        this.requestUpdate();
    }
    handleAiPromotionSuggestionsCreatedAtChange(e) {
        const target = e.target;
        this.setAiPromotionSuggestionsCreatedAt(target.value);
    }
    /* ── Lifecycle ── */
    connectedCallback() {
        super.connectedCallback();
        // Initialize from shared state where available, falling back to defaults
        const sharedStatus = getState('ui.aiPromotionSuggestions.status');
        if (sharedStatus !== undefined) {
            this.status = sharedStatus;
        }
        const sharedActionStatus = getState('ui.aiPromotionSuggestions.action.aiPromotionSuggestions.status');
        if (sharedActionStatus !== undefined) {
            this.aiPromotionSuggestionsState = sharedActionStatus;
        }
        const sharedData = getState('ui.aiPromotionSuggestions.data.aiPromotionSuggestions');
        if (sharedData !== undefined) {
            this.aiPromotionSuggestionsData = sharedData;
        }
        // Run initial loads
        this.loadAiPromotionSuggestions();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowAiPromotionSuggestionsBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowAiPromotionSuggestionsBase.prototype, "aiPromotionSuggestionsState", void 0);
__decorate([
    property({ type: String })
], CafeFlowAiPromotionSuggestionsBase.prototype, "aiPromotionSuggestionsId", void 0);
__decorate([
    property({ type: String })
], CafeFlowAiPromotionSuggestionsBase.prototype, "aiPromotionSuggestionsOrderId", void 0);
__decorate([
    property({ type: String })
], CafeFlowAiPromotionSuggestionsBase.prototype, "aiPromotionSuggestionsMenuItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowAiPromotionSuggestionsBase.prototype, "aiPromotionSuggestionsKitchenTicketId", void 0);
__decorate([
    property({ type: String })
], CafeFlowAiPromotionSuggestionsBase.prototype, "aiPromotionSuggestionsStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowAiPromotionSuggestionsBase.prototype, "aiPromotionSuggestionsCreatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowAiPromotionSuggestionsBase.prototype, "aiPromotionSuggestionsData", void 0);
