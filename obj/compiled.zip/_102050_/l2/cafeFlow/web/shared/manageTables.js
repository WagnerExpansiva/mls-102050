/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/manageTables.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'manageTables.section.title': 'Gerenciar mesas',
    'manageTables.organism.title': 'Gerenciar mesas',
    'manageTables.form.title': 'Dados da mesa',
    'manageTables.field.tableId': 'Identificador da mesa',
    'manageTables.field.number': 'Número da mesa',
    'manageTables.field.status': 'Situação',
    'manageTables.action.submit': 'Salvar',
    'manageTables.status.title': 'Status da operação',
};
const message_en = {
    'manageTables.section.title': 'Manage tables',
    'manageTables.organism.title': 'Manage tables',
    'manageTables.form.title': 'Table data',
    'manageTables.field.tableId': 'Table identifier',
    'manageTables.field.number': 'Table number',
    'manageTables.field.status': 'Status',
    'manageTables.action.submit': 'Save',
    'manageTables.status.title': 'Operation status',
};
export class CafeFlowManageTablesBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.manageTablesState = 'idle';
        this.manageTablesTableId = '';
        this.manageTablesNumber = '';
        this.manageTablesStatus = '';
    }
    get msg() {
        const lang = (typeof document !== 'undefined' && document.documentElement?.lang) || 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.manageTables.status') ?? '';
        this.manageTablesState = getState('ui.manageTables.action.manageTables.status') ?? 'idle';
        this.manageTablesTableId = getState('ui.manageTables.input.manageTables.tableId') ?? '';
        this.manageTablesNumber = getState('ui.manageTables.input.manageTables.number') ?? '';
        this.manageTablesStatus = getState('ui.manageTables.input.manageTables.status') ?? '';
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- State setters ---
    setManageTablesTableId(value) {
        this.manageTablesTableId = value;
        setState('ui.manageTables.input.manageTables.tableId', value);
        this.requestUpdate();
    }
    handleManageTablesTableIdChange(e) {
        const value = e.target.value;
        this.setManageTablesTableId(value);
    }
    setManageTablesNumber(value) {
        this.manageTablesNumber = value;
        setState('ui.manageTables.input.manageTables.number', value);
        this.requestUpdate();
    }
    handleManageTablesNumberChange(e) {
        const value = e.target.value;
        this.setManageTablesNumber(value);
    }
    setManageTablesStatus(value) {
        this.manageTablesStatus = value;
        setState('ui.manageTables.input.manageTables.status', value);
        this.requestUpdate();
    }
    handleManageTablesStatusChange(e) {
        const value = e.target.value;
        this.setManageTablesStatus(value);
    }
    // --- Command action ---
    async manageTables() {
        this.manageTablesState = 'loading';
        setState('ui.manageTables.action.manageTables.status', 'loading');
        this.requestUpdate();
        const params = {
            tableId: this.manageTablesTableId || undefined,
            number: this.manageTablesNumber,
            status: this.manageTablesStatus,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.manageTables.manageTables', params, options);
            if (response.ok) {
                this.manageTablesState = 'success';
                setState('ui.manageTables.action.manageTables.status', 'success');
            }
            else {
                this.manageTablesState = 'error';
                setState('ui.manageTables.action.manageTables.status', 'error');
            }
        }
        catch {
            this.manageTablesState = 'error';
            setState('ui.manageTables.action.manageTables.status', 'error');
        }
        this.requestUpdate();
    }
    handleManageTablesClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.manageTables();
        });
    }
}
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "manageTablesState", void 0);
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "manageTablesTableId", void 0);
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "manageTablesNumber", void 0);
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "manageTablesStatus", void 0);
