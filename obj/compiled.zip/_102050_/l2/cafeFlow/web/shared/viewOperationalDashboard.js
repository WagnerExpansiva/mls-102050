/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'viewOperationalDashboard.section.title': 'Dashboard operacional do dia',
    'viewOperationalDashboard.organism.title': 'Visão operacional',
    'viewOperationalDashboard.filters.title': 'Filtros do dashboard',
    'viewOperationalDashboard.field.dailyShiftId': 'ID do turno',
    'viewOperationalDashboard.field.shiftDate': 'Data do turno',
    'viewOperationalDashboard.field.status': 'Status do turno',
    'viewOperationalDashboard.field.openedAt': 'Abertura do turno',
    'viewOperationalDashboard.field.closedAt': 'Fechamento do turno',
    'viewOperationalDashboard.field.createdAt': 'Criado em',
    'viewOperationalDashboard.action.run': 'Atualizar dashboard',
    'viewOperationalDashboard.summary.title': 'Resumo do turno',
    'viewOperationalDashboard.summary.dailyShiftId': 'ID do turno',
    'viewOperationalDashboard.summary.shiftDate': 'Data do turno',
    'viewOperationalDashboard.summary.status': 'Status',
    'viewOperationalDashboard.summary.openedAt': 'Abertura',
    'viewOperationalDashboard.summary.closedAt': 'Fechamento',
    'viewOperationalDashboard.summary.openingCashBalance': 'Caixa inicial',
    'viewOperationalDashboard.summary.closingCashBalance': 'Caixa final',
    'viewOperationalDashboard.summary.totalSales': 'Total de vendas',
};
const message_en = {
    'viewOperationalDashboard.section.title': 'Daily Operational Dashboard',
    'viewOperationalDashboard.organism.title': 'Operational Overview',
    'viewOperationalDashboard.filters.title': 'Dashboard Filters',
    'viewOperationalDashboard.field.dailyShiftId': 'Shift ID',
    'viewOperationalDashboard.field.shiftDate': 'Shift Date',
    'viewOperationalDashboard.field.status': 'Shift Status',
    'viewOperationalDashboard.field.openedAt': 'Shift Opening',
    'viewOperationalDashboard.field.closedAt': 'Shift Closing',
    'viewOperationalDashboard.field.createdAt': 'Created At',
    'viewOperationalDashboard.action.run': 'Refresh Dashboard',
    'viewOperationalDashboard.summary.title': 'Shift Summary',
    'viewOperationalDashboard.summary.dailyShiftId': 'Shift ID',
    'viewOperationalDashboard.summary.shiftDate': 'Shift Date',
    'viewOperationalDashboard.summary.status': 'Status',
    'viewOperationalDashboard.summary.openedAt': 'Opening',
    'viewOperationalDashboard.summary.closedAt': 'Closing',
    'viewOperationalDashboard.summary.openingCashBalance': 'Opening Cash Balance',
    'viewOperationalDashboard.summary.closingCashBalance': 'Closing Cash Balance',
    'viewOperationalDashboard.summary.totalSales': 'Total Sales',
};
export class CafeFlowViewOperationalDashboardBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewOperationalDashboardState = 'idle';
        this.viewOperationalDashboardDailyShiftId = '';
        this.viewOperationalDashboardShiftDate = '';
        this.viewOperationalDashboardStatus = '';
        this.viewOperationalDashboardOpenedAt = '';
        this.viewOperationalDashboardClosedAt = '';
        this.viewOperationalDashboardCreatedAt = '';
        this.viewOperationalDashboardData = [];
    }
    get msg() {
        const lang = (typeof document !== 'undefined' && document.documentElement?.lang) || 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.viewOperationalDashboard.status') ?? '';
        this.viewOperationalDashboardState =
            getState('ui.viewOperationalDashboard.action.viewOperationalDashboard.status') ?? 'idle';
        this.viewOperationalDashboardDailyShiftId =
            getState('ui.viewOperationalDashboard.input.viewOperationalDashboard.dailyShiftId') ?? '';
        this.viewOperationalDashboardShiftDate =
            getState('ui.viewOperationalDashboard.input.viewOperationalDashboard.shiftDate') ?? '';
        this.viewOperationalDashboardStatus =
            getState('ui.viewOperationalDashboard.input.viewOperationalDashboard.status') ?? '';
        this.viewOperationalDashboardOpenedAt =
            getState('ui.viewOperationalDashboard.input.viewOperationalDashboard.openedAt') ?? '';
        this.viewOperationalDashboardClosedAt =
            getState('ui.viewOperationalDashboard.input.viewOperationalDashboard.closedAt') ?? '';
        this.viewOperationalDashboardCreatedAt =
            getState('ui.viewOperationalDashboard.input.viewOperationalDashboard.createdAt') ?? '';
        this.viewOperationalDashboardData =
            getState('ui.viewOperationalDashboard.data.viewOperationalDashboard') ?? [];
        this.loadViewOperationalDashboard();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // ── Query action: viewOperationalDashboard ──────────────────────────
    async loadViewOperationalDashboard() {
        this.viewOperationalDashboardState = 'loading';
        setState('ui.viewOperationalDashboard.action.viewOperationalDashboard.status', 'loading');
        this.requestUpdate();
        const params = {
            dailyShiftId: this.viewOperationalDashboardDailyShiftId || undefined,
            shiftDate: this.viewOperationalDashboardShiftDate || undefined,
            status: this.viewOperationalDashboardStatus || undefined,
            openedAt: this.viewOperationalDashboardOpenedAt || undefined,
            closedAt: this.viewOperationalDashboardClosedAt || undefined,
            createdAt: this.viewOperationalDashboardCreatedAt || undefined,
        };
        const options = { mode: 'silent' };
        try {
            const response = await execBff('cafeFlow.viewOperationalDashboard.viewOperationalDashboard', params, options);
            if (response.ok) {
                const data = response.data ?? [];
                this.viewOperationalDashboardData = data;
                setState('ui.viewOperationalDashboard.data.viewOperationalDashboard', data);
                this.viewOperationalDashboardState = 'success';
                setState('ui.viewOperationalDashboard.action.viewOperationalDashboard.status', 'success');
            }
            else {
                this.viewOperationalDashboardState = 'error';
                setState('ui.viewOperationalDashboard.action.viewOperationalDashboard.status', 'error');
            }
        }
        catch {
            this.viewOperationalDashboardState = 'error';
            setState('ui.viewOperationalDashboard.action.viewOperationalDashboard.status', 'error');
        }
        this.requestUpdate();
    }
    handleViewOperationalDashboardClick() {
        runBlockingUiAction(async () => {
            await this.loadViewOperationalDashboard();
        });
    }
    // ── State setters ────────────────────────────────────────────────────
    setViewOperationalDashboardDailyShiftId(value) {
        this.viewOperationalDashboardDailyShiftId = value;
        setState('ui.viewOperationalDashboard.input.viewOperationalDashboard.dailyShiftId', value);
        this.requestUpdate();
    }
    handleViewOperationalDashboardDailyShiftIdChange(e) {
        const target = e.target;
        this.setViewOperationalDashboardDailyShiftId(target.value);
    }
    setViewOperationalDashboardShiftDate(value) {
        this.viewOperationalDashboardShiftDate = value;
        setState('ui.viewOperationalDashboard.input.viewOperationalDashboard.shiftDate', value);
        this.requestUpdate();
    }
    handleViewOperationalDashboardShiftDateChange(e) {
        const target = e.target;
        this.setViewOperationalDashboardShiftDate(target.value);
    }
    setViewOperationalDashboardStatus(value) {
        this.viewOperationalDashboardStatus = value;
        setState('ui.viewOperationalDashboard.input.viewOperationalDashboard.status', value);
        this.requestUpdate();
    }
    handleViewOperationalDashboardStatusChange(e) {
        const target = e.target;
        this.setViewOperationalDashboardStatus(target.value);
    }
    setViewOperationalDashboardOpenedAt(value) {
        this.viewOperationalDashboardOpenedAt = value;
        setState('ui.viewOperationalDashboard.input.viewOperationalDashboard.openedAt', value);
        this.requestUpdate();
    }
    handleViewOperationalDashboardOpenedAtChange(e) {
        const target = e.target;
        this.setViewOperationalDashboardOpenedAt(target.value);
    }
    setViewOperationalDashboardClosedAt(value) {
        this.viewOperationalDashboardClosedAt = value;
        setState('ui.viewOperationalDashboard.input.viewOperationalDashboard.closedAt', value);
        this.requestUpdate();
    }
    handleViewOperationalDashboardClosedAtChange(e) {
        const target = e.target;
        this.setViewOperationalDashboardClosedAt(target.value);
    }
    setViewOperationalDashboardCreatedAt(value) {
        this.viewOperationalDashboardCreatedAt = value;
        setState('ui.viewOperationalDashboard.input.viewOperationalDashboard.createdAt', value);
        this.requestUpdate();
    }
    handleViewOperationalDashboardCreatedAtChange(e) {
        const target = e.target;
        this.setViewOperationalDashboardCreatedAt(target.value);
    }
}
__decorate([
    property()
], CafeFlowViewOperationalDashboardBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowViewOperationalDashboardBase.prototype, "viewOperationalDashboardState", void 0);
__decorate([
    property()
], CafeFlowViewOperationalDashboardBase.prototype, "viewOperationalDashboardDailyShiftId", void 0);
__decorate([
    property()
], CafeFlowViewOperationalDashboardBase.prototype, "viewOperationalDashboardShiftDate", void 0);
__decorate([
    property()
], CafeFlowViewOperationalDashboardBase.prototype, "viewOperationalDashboardStatus", void 0);
__decorate([
    property()
], CafeFlowViewOperationalDashboardBase.prototype, "viewOperationalDashboardOpenedAt", void 0);
__decorate([
    property()
], CafeFlowViewOperationalDashboardBase.prototype, "viewOperationalDashboardClosedAt", void 0);
__decorate([
    property()
], CafeFlowViewOperationalDashboardBase.prototype, "viewOperationalDashboardCreatedAt", void 0);
__decorate([
    property()
], CafeFlowViewOperationalDashboardBase.prototype, "viewOperationalDashboardData", void 0);
