/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'section.dineInOrderLifecycle.title': 'Ciclo de pedido (mesa)',
    'organism.createOrder.title': 'Criar pedido',
    'intent.createOrder.form.title': 'Novo pedido',
    'field.createOrder.orderType': 'Tipo do pedido',
    'field.createOrder.status': 'Status do pedido',
    'field.createOrder.totalAmount': 'Valor total',
    'field.createOrder.notes': 'Observações',
    'field.createOrder.customerName': 'Nome do cliente',
    'field.createOrder.customerPhone': 'Telefone do cliente',
    'field.createOrder.numberOfGuests': 'Número de pessoas',
    'field.createOrder.closedAt': 'Fechado em',
    'field.createOrder.cancelledAt': 'Cancelado em',
    'field.createOrder.cancellationReason': 'Motivo do cancelamento',
    'action.createOrder.submit': 'Criar pedido',
    'organism.addOrderItem.title': 'Adicionar item ao pedido',
    'intent.addOrderItem.form.title': 'Adicionar item',
    'field.addOrderItem.quantity': 'Quantidade',
    'field.addOrderItem.unitPrice': 'Preço unitário',
    'field.addOrderItem.totalPrice': 'Preço total',
    'field.addOrderItem.observations': 'Observações do item',
    'field.addOrderItem.status': 'Status do item',
    'action.addOrderItem.submit': 'Adicionar item',
    'organism.createKitchenTicket.title': 'Criar ticket de cozinha',
    'intent.createKitchenTicket.form.title': 'Enviar para cozinha',
    'field.createKitchenTicket.status': 'Status do ticket',
    'action.createKitchenTicket.submit': 'Criar ticket',
    'organism.updateOrderStatus.title': 'Atualizar status do pedido',
    'intent.updateOrderStatus.form.title': 'Atualizar status do pedido',
    'field.updateOrderStatus.status': 'Novo status do pedido',
    'field.updateOrderStatus.closedAt': 'Fechado em',
    'field.updateOrderStatus.cancelledAt': 'Cancelado em',
    'field.updateOrderStatus.cancellationReason': 'Motivo do cancelamento',
    'action.updateOrderStatus.submit': 'Atualizar status',
    'organism.updateTableStatus.title': 'Atualizar ocupação da mesa',
    'intent.updateTableStatus.form.title': 'Atualizar status da mesa',
    'field.updateTableStatus.status': 'Status da mesa',
    'action.updateTableStatus.submit': 'Atualizar mesa',
};
const message_en = {
    'section.dineInOrderLifecycle.title': 'Dine-in order lifecycle',
    'organism.createOrder.title': 'Create order',
    'intent.createOrder.form.title': 'New order',
    'field.createOrder.orderType': 'Order type',
    'field.createOrder.status': 'Order status',
    'field.createOrder.totalAmount': 'Total amount',
    'field.createOrder.notes': 'Notes',
    'field.createOrder.customerName': 'Customer name',
    'field.createOrder.customerPhone': 'Customer phone',
    'field.createOrder.numberOfGuests': 'Number of guests',
    'field.createOrder.closedAt': 'Closed at',
    'field.createOrder.cancelledAt': 'Cancelled at',
    'field.createOrder.cancellationReason': 'Cancellation reason',
    'action.createOrder.submit': 'Create order',
    'organism.addOrderItem.title': 'Add order item',
    'intent.addOrderItem.form.title': 'Add item',
    'field.addOrderItem.quantity': 'Quantity',
    'field.addOrderItem.unitPrice': 'Unit price',
    'field.addOrderItem.totalPrice': 'Total price',
    'field.addOrderItem.observations': 'Item observations',
    'field.addOrderItem.status': 'Item status',
    'action.addOrderItem.submit': 'Add item',
    'organism.createKitchenTicket.title': 'Create kitchen ticket',
    'intent.createKitchenTicket.form.title': 'Send to kitchen',
    'field.createKitchenTicket.status': 'Ticket status',
    'action.createKitchenTicket.submit': 'Create ticket',
    'organism.updateOrderStatus.title': 'Update order status',
    'intent.updateOrderStatus.form.title': 'Update order status',
    'field.updateOrderStatus.status': 'New order status',
    'field.updateOrderStatus.closedAt': 'Closed at',
    'field.updateOrderStatus.cancelledAt': 'Cancelled at',
    'field.updateOrderStatus.cancellationReason': 'Cancellation reason',
    'action.updateOrderStatus.submit': 'Update status',
    'organism.updateTableStatus.title': 'Update table status',
    'intent.updateTableStatus.form.title': 'Update table status',
    'field.updateTableStatus.status': 'Table status',
    'action.updateTableStatus.submit': 'Update table',
};
export class CafeFlowDineInOrderLifecycleBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        // ── Page status ──────────────────────────────────────────────
        this.status = '';
        // ── createOrder action + inputs ──────────────────────────────
        this.createOrderState = 'idle';
        this.createOrderOrderType = '';
        this.createOrderStatus = '';
        this.createOrderTotalAmount = '';
        this.createOrderNotes = '';
        this.createOrderCustomerName = '';
        this.createOrderCustomerPhone = '';
        this.createOrderNumberOfGuests = '';
        this.createOrderClosedAt = '';
        this.createOrderCancelledAt = '';
        this.createOrderCancellationReason = '';
        // ── addOrderItem action + inputs ─────────────────────────────
        this.addOrderItemState = 'idle';
        this.addOrderItemQuantity = '';
        this.addOrderItemUnitPrice = '';
        this.addOrderItemTotalPrice = '';
        this.addOrderItemObservations = '';
        this.addOrderItemStatus = '';
        // ── createKitchenTicket action + inputs ──────────────────────
        this.createKitchenTicketState = 'idle';
        this.createKitchenTicketStatus = '';
        // ── updateOrderStatus action + inputs ────────────────────────
        this.updateOrderStatusState = 'idle';
        this.updateOrderStatusStatus = '';
        this.updateOrderStatusClosedAt = '';
        this.updateOrderStatusCancelledAt = '';
        this.updateOrderStatusCancellationReason = '';
        // ── updateTableStatus action + inputs ────────────────────────
        this.updateTableStatusState = 'idle';
        this.updateTableStatusStatus = '';
    }
    // ── i18n ─────────────────────────────────────────────────────
    get msg() {
        const lang = this.lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    // ═══════════════════════════════════════════════════════════════
    //  State setters – createOrder
    // ═══════════════════════════════════════════════════════════════
    setCreateOrderOrderType(value) {
        this.createOrderOrderType = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.orderType', value);
        this.requestUpdate();
    }
    handleCreateOrderOrderTypeChange(e) {
        const target = e.target;
        this.setCreateOrderOrderType(target.value);
    }
    setCreateOrderStatus(value) {
        this.createOrderStatus = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.status', value);
        this.requestUpdate();
    }
    handleCreateOrderStatusChange(e) {
        const target = e.target;
        this.setCreateOrderStatus(target.value);
    }
    setCreateOrderTotalAmount(value) {
        this.createOrderTotalAmount = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.totalAmount', value);
        this.requestUpdate();
    }
    handleCreateOrderTotalAmountChange(e) {
        const target = e.target;
        this.setCreateOrderTotalAmount(target.value);
    }
    setCreateOrderNotes(value) {
        this.createOrderNotes = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.notes', value);
        this.requestUpdate();
    }
    handleCreateOrderNotesChange(e) {
        const target = e.target;
        this.setCreateOrderNotes(target.value);
    }
    setCreateOrderCustomerName(value) {
        this.createOrderCustomerName = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.customerName', value);
        this.requestUpdate();
    }
    handleCreateOrderCustomerNameChange(e) {
        const target = e.target;
        this.setCreateOrderCustomerName(target.value);
    }
    setCreateOrderCustomerPhone(value) {
        this.createOrderCustomerPhone = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.customerPhone', value);
        this.requestUpdate();
    }
    handleCreateOrderCustomerPhoneChange(e) {
        const target = e.target;
        this.setCreateOrderCustomerPhone(target.value);
    }
    setCreateOrderNumberOfGuests(value) {
        this.createOrderNumberOfGuests = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.numberOfGuests', value);
        this.requestUpdate();
    }
    handleCreateOrderNumberOfGuestsChange(e) {
        const target = e.target;
        this.setCreateOrderNumberOfGuests(target.value);
    }
    setCreateOrderClosedAt(value) {
        this.createOrderClosedAt = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.closedAt', value);
        this.requestUpdate();
    }
    handleCreateOrderClosedAtChange(e) {
        const target = e.target;
        this.setCreateOrderClosedAt(target.value);
    }
    setCreateOrderCancelledAt(value) {
        this.createOrderCancelledAt = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.cancelledAt', value);
        this.requestUpdate();
    }
    handleCreateOrderCancelledAtChange(e) {
        const target = e.target;
        this.setCreateOrderCancelledAt(target.value);
    }
    setCreateOrderCancellationReason(value) {
        this.createOrderCancellationReason = value;
        setState('ui.dineInOrderLifecycle.input.createOrder.cancellationReason', value);
        this.requestUpdate();
    }
    handleCreateOrderCancellationReasonChange(e) {
        const target = e.target;
        this.setCreateOrderCancellationReason(target.value);
    }
    // ═══════════════════════════════════════════════════════════════
    //  State setters – addOrderItem
    // ═══════════════════════════════════════════════════════════════
    setAddOrderItemQuantity(value) {
        this.addOrderItemQuantity = value;
        setState('ui.dineInOrderLifecycle.input.addOrderItem.quantity', value);
        this.requestUpdate();
    }
    handleAddOrderItemQuantityChange(e) {
        const target = e.target;
        this.setAddOrderItemQuantity(target.value);
    }
    setAddOrderItemUnitPrice(value) {
        this.addOrderItemUnitPrice = value;
        setState('ui.dineInOrderLifecycle.input.addOrderItem.unitPrice', value);
        this.requestUpdate();
    }
    handleAddOrderItemUnitPriceChange(e) {
        const target = e.target;
        this.setAddOrderItemUnitPrice(target.value);
    }
    setAddOrderItemTotalPrice(value) {
        this.addOrderItemTotalPrice = value;
        setState('ui.dineInOrderLifecycle.input.addOrderItem.totalPrice', value);
        this.requestUpdate();
    }
    handleAddOrderItemTotalPriceChange(e) {
        const target = e.target;
        this.setAddOrderItemTotalPrice(target.value);
    }
    setAddOrderItemObservations(value) {
        this.addOrderItemObservations = value;
        setState('ui.dineInOrderLifecycle.input.addOrderItem.observations', value);
        this.requestUpdate();
    }
    handleAddOrderItemObservationsChange(e) {
        const target = e.target;
        this.setAddOrderItemObservations(target.value);
    }
    setAddOrderItemStatus(value) {
        this.addOrderItemStatus = value;
        setState('ui.dineInOrderLifecycle.input.addOrderItem.status', value);
        this.requestUpdate();
    }
    handleAddOrderItemStatusChange(e) {
        const target = e.target;
        this.setAddOrderItemStatus(target.value);
    }
    // ═══════════════════════════════════════════════════════════════
    //  State setters – createKitchenTicket
    // ═══════════════════════════════════════════════════════════════
    setCreateKitchenTicketStatus(value) {
        this.createKitchenTicketStatus = value;
        setState('ui.dineInOrderLifecycle.input.createKitchenTicket.status', value);
        this.requestUpdate();
    }
    handleCreateKitchenTicketStatusChange(e) {
        const target = e.target;
        this.setCreateKitchenTicketStatus(target.value);
    }
    // ═══════════════════════════════════════════════════════════════
    //  State setters – updateOrderStatus
    // ═══════════════════════════════════════════════════════════════
    setUpdateOrderStatusStatus(value) {
        this.updateOrderStatusStatus = value;
        setState('ui.dineInOrderLifecycle.input.updateOrderStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusStatusChange(e) {
        const target = e.target;
        this.setUpdateOrderStatusStatus(target.value);
    }
    setUpdateOrderStatusClosedAt(value) {
        this.updateOrderStatusClosedAt = value;
        setState('ui.dineInOrderLifecycle.input.updateOrderStatus.closedAt', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusClosedAtChange(e) {
        const target = e.target;
        this.setUpdateOrderStatusClosedAt(target.value);
    }
    setUpdateOrderStatusCancelledAt(value) {
        this.updateOrderStatusCancelledAt = value;
        setState('ui.dineInOrderLifecycle.input.updateOrderStatus.cancelledAt', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusCancelledAtChange(e) {
        const target = e.target;
        this.setUpdateOrderStatusCancelledAt(target.value);
    }
    setUpdateOrderStatusCancellationReason(value) {
        this.updateOrderStatusCancellationReason = value;
        setState('ui.dineInOrderLifecycle.input.updateOrderStatus.cancellationReason', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusCancellationReasonChange(e) {
        const target = e.target;
        this.setUpdateOrderStatusCancellationReason(target.value);
    }
    // ═══════════════════════════════════════════════════════════════
    //  State setters – updateTableStatus
    // ═══════════════════════════════════════════════════════════════
    setUpdateTableStatusStatus(value) {
        this.updateTableStatusStatus = value;
        setState('ui.dineInOrderLifecycle.input.updateTableStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateTableStatusStatusChange(e) {
        const target = e.target;
        this.setUpdateTableStatusStatus(target.value);
    }
    // ═══════════════════════════════════════════════════════════════
    //  Command actions
    // ═══════════════════════════════════════════════════════════════
    async createOrder(options) {
        this.createOrderState = 'loading';
        setState('ui.dineInOrderLifecycle.action.createOrder.status', 'loading');
        this.requestUpdate();
        const params = {
            orderType: this.createOrderOrderType,
            status: this.createOrderStatus,
            totalAmount: Number(this.createOrderTotalAmount) || 0,
            notes: this.createOrderNotes || undefined,
            customerName: this.createOrderCustomerName || undefined,
            customerPhone: this.createOrderCustomerPhone || undefined,
            numberOfGuests: this.createOrderNumberOfGuests ? Number(this.createOrderNumberOfGuests) : undefined,
            closedAt: this.createOrderClosedAt || undefined,
            cancelledAt: this.createOrderCancelledAt || undefined,
            cancellationReason: this.createOrderCancellationReason || undefined,
        };
        const response = await execBff('cafeFlow.dineInOrderLifecycle.createOrder', params, options ?? {});
        if (response.ok) {
            this.createOrderState = 'success';
            setState('ui.dineInOrderLifecycle.action.createOrder.status', 'success');
        }
        else {
            this.createOrderState = 'error';
            setState('ui.dineInOrderLifecycle.action.createOrder.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateOrderClick(e) {
        e.preventDefault();
        void runBlockingUiAction(() => this.createOrder());
    }
    async addOrderItem(options) {
        this.addOrderItemState = 'loading';
        setState('ui.dineInOrderLifecycle.action.addOrderItem.status', 'loading');
        this.requestUpdate();
        const params = {
            quantity: Number(this.addOrderItemQuantity) || 0,
            unitPrice: Number(this.addOrderItemUnitPrice) || 0,
            totalPrice: Number(this.addOrderItemTotalPrice) || 0,
            observations: this.addOrderItemObservations || undefined,
            status: this.addOrderItemStatus,
        };
        const response = await execBff('cafeFlow.dineInOrderLifecycle.addOrderItem', params, options ?? {});
        if (response.ok) {
            this.addOrderItemState = 'success';
            setState('ui.dineInOrderLifecycle.action.addOrderItem.status', 'success');
        }
        else {
            this.addOrderItemState = 'error';
            setState('ui.dineInOrderLifecycle.action.addOrderItem.status', 'error');
        }
        this.requestUpdate();
    }
    handleAddOrderItemClick(e) {
        e.preventDefault();
        void runBlockingUiAction(() => this.addOrderItem());
    }
    async createKitchenTicket(options) {
        this.createKitchenTicketState = 'loading';
        setState('ui.dineInOrderLifecycle.action.createKitchenTicket.status', 'loading');
        this.requestUpdate();
        const params = {
            status: this.createKitchenTicketStatus,
        };
        const response = await execBff('cafeFlow.dineInOrderLifecycle.createKitchenTicket', params, options ?? {});
        if (response.ok) {
            this.createKitchenTicketState = 'success';
            setState('ui.dineInOrderLifecycle.action.createKitchenTicket.status', 'success');
        }
        else {
            this.createKitchenTicketState = 'error';
            setState('ui.dineInOrderLifecycle.action.createKitchenTicket.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateKitchenTicketClick(e) {
        e.preventDefault();
        void runBlockingUiAction(() => this.createKitchenTicket());
    }
    async updateOrderStatus(options) {
        this.updateOrderStatusState = 'loading';
        setState('ui.dineInOrderLifecycle.action.updateOrderStatus.status', 'loading');
        this.requestUpdate();
        const params = {
            status: this.updateOrderStatusStatus,
            closedAt: this.updateOrderStatusClosedAt || undefined,
            cancelledAt: this.updateOrderStatusCancelledAt || undefined,
            cancellationReason: this.updateOrderStatusCancellationReason || undefined,
        };
        const response = await execBff('cafeFlow.dineInOrderLifecycle.updateOrderStatus', params, options ?? {});
        if (response.ok) {
            this.updateOrderStatusState = 'success';
            setState('ui.dineInOrderLifecycle.action.updateOrderStatus.status', 'success');
        }
        else {
            this.updateOrderStatusState = 'error';
            setState('ui.dineInOrderLifecycle.action.updateOrderStatus.status', 'error');
        }
        this.requestUpdate();
    }
    handleUpdateOrderStatusClick(e) {
        e.preventDefault();
        void runBlockingUiAction(() => this.updateOrderStatus());
    }
    async updateTableStatus(options) {
        this.updateTableStatusState = 'loading';
        setState('ui.dineInOrderLifecycle.action.updateTableStatus.status', 'loading');
        this.requestUpdate();
        const params = {
            status: this.updateTableStatusStatus,
        };
        const response = await execBff('cafeFlow.dineInOrderLifecycle.updateTableStatus', params, options ?? {});
        if (response.ok) {
            this.updateTableStatusState = 'success';
            setState('ui.dineInOrderLifecycle.action.updateTableStatus.status', 'success');
        }
        else {
            this.updateTableStatusState = 'error';
            setState('ui.dineInOrderLifecycle.action.updateTableStatus.status', 'error');
        }
        this.requestUpdate();
    }
    handleUpdateTableStatusClick(e) {
        e.preventDefault();
        void runBlockingUiAction(() => this.updateTableStatus());
    }
    // ═══════════════════════════════════════════════════════════════
    //  Lifecycle
    // ═══════════════════════════════════════════════════════════════
    connectedCallback() {
        super.connectedCallback();
        // Restore shared state if available, falling back to defaults
        this.status = getState('ui.dineInOrderLifecycle.status') ?? '';
        this.createOrderState = getState('ui.dineInOrderLifecycle.action.createOrder.status') ?? 'idle';
        this.createOrderOrderType = getState('ui.dineInOrderLifecycle.input.createOrder.orderType') ?? '';
        this.createOrderStatus = getState('ui.dineInOrderLifecycle.input.createOrder.status') ?? '';
        this.createOrderTotalAmount = getState('ui.dineInOrderLifecycle.input.createOrder.totalAmount') ?? '';
        this.createOrderNotes = getState('ui.dineInOrderLifecycle.input.createOrder.notes') ?? '';
        this.createOrderCustomerName = getState('ui.dineInOrderLifecycle.input.createOrder.customerName') ?? '';
        this.createOrderCustomerPhone = getState('ui.dineInOrderLifecycle.input.createOrder.customerPhone') ?? '';
        this.createOrderNumberOfGuests = getState('ui.dineInOrderLifecycle.input.createOrder.numberOfGuests') ?? '';
        this.createOrderClosedAt = getState('ui.dineInOrderLifecycle.input.createOrder.closedAt') ?? '';
        this.createOrderCancelledAt = getState('ui.dineInOrderLifecycle.input.createOrder.cancelledAt') ?? '';
        this.createOrderCancellationReason = getState('ui.dineInOrderLifecycle.input.createOrder.cancellationReason') ?? '';
        this.addOrderItemState = getState('ui.dineInOrderLifecycle.action.addOrderItem.status') ?? 'idle';
        this.addOrderItemQuantity = getState('ui.dineInOrderLifecycle.input.addOrderItem.quantity') ?? '';
        this.addOrderItemUnitPrice = getState('ui.dineInOrderLifecycle.input.addOrderItem.unitPrice') ?? '';
        this.addOrderItemTotalPrice = getState('ui.dineInOrderLifecycle.input.addOrderItem.totalPrice') ?? '';
        this.addOrderItemObservations = getState('ui.dineInOrderLifecycle.input.addOrderItem.observations') ?? '';
        this.addOrderItemStatus = getState('ui.dineInOrderLifecycle.input.addOrderItem.status') ?? '';
        this.createKitchenTicketState = getState('ui.dineInOrderLifecycle.action.createKitchenTicket.status') ?? 'idle';
        this.createKitchenTicketStatus = getState('ui.dineInOrderLifecycle.input.createKitchenTicket.status') ?? '';
        this.updateOrderStatusState = getState('ui.dineInOrderLifecycle.action.updateOrderStatus.status') ?? 'idle';
        this.updateOrderStatusStatus = getState('ui.dineInOrderLifecycle.input.updateOrderStatus.status') ?? '';
        this.updateOrderStatusClosedAt = getState('ui.dineInOrderLifecycle.input.updateOrderStatus.closedAt') ?? '';
        this.updateOrderStatusCancelledAt = getState('ui.dineInOrderLifecycle.input.updateOrderStatus.cancelledAt') ?? '';
        this.updateOrderStatusCancellationReason = getState('ui.dineInOrderLifecycle.input.updateOrderStatus.cancellationReason') ?? '';
        this.updateTableStatusState = getState('ui.dineInOrderLifecycle.action.updateTableStatus.status') ?? 'idle';
        this.updateTableStatusStatus = getState('ui.dineInOrderLifecycle.input.updateTableStatus.status') ?? '';
        // No initial loads defined for this page
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderState", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderOrderType", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderTotalAmount", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderNotes", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderCustomerName", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderCustomerPhone", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderNumberOfGuests", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderCancelledAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderCancellationReason", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemQuantity", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemUnitPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemTotalPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemObservations", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createKitchenTicketState", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "createKitchenTicketStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusCancelledAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusCancellationReason", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "updateTableStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowDineInOrderLifecycleBase.prototype, "updateTableStatusStatus", void 0);
