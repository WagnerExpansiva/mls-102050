/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'takeoutOrderLifecycle.section.main.title': 'Ciclo de pedido (takeout)',
    'takeoutOrderLifecycle.createOrder.title': 'Criar pedido',
    'takeoutOrderLifecycle.createOrder.form.title': 'Command Form',
    'takeoutOrderLifecycle.createOrder.orderType.label': 'Order Type',
    'takeoutOrderLifecycle.createOrder.status.label': 'Status',
    'takeoutOrderLifecycle.createOrder.totalAmount.label': 'Total Amount',
    'takeoutOrderLifecycle.createOrder.notes.label': 'Notes',
    'takeoutOrderLifecycle.createOrder.customerName.label': 'Customer Name',
    'takeoutOrderLifecycle.createOrder.customerPhone.label': 'Customer Phone',
    'takeoutOrderLifecycle.createOrder.numberOfGuests.label': 'Number Of Guests',
    'takeoutOrderLifecycle.createOrder.closedAt.label': 'Closed At',
    'takeoutOrderLifecycle.createOrder.cancelledAt.label': 'Cancelled At',
    'takeoutOrderLifecycle.createOrder.cancellationReason.label': 'Cancellation Reason',
    'takeoutOrderLifecycle.createOrder.submit': 'Create Order',
    'takeoutOrderLifecycle.addOrderItem.title': 'Adicionar item ao pedido',
    'takeoutOrderLifecycle.addOrderItem.form.title': 'Command Form',
    'takeoutOrderLifecycle.addOrderItem.quantity.label': 'Quantity',
    'takeoutOrderLifecycle.addOrderItem.unitPrice.label': 'Unit Price',
    'takeoutOrderLifecycle.addOrderItem.totalPrice.label': 'Total Price',
    'takeoutOrderLifecycle.addOrderItem.observations.label': 'Observations',
    'takeoutOrderLifecycle.addOrderItem.status.label': 'Status',
    'takeoutOrderLifecycle.addOrderItem.submit': 'Add Order Item',
    'takeoutOrderLifecycle.createKitchenTicket.title': 'Criar ticket de cozinha',
    'takeoutOrderLifecycle.createKitchenTicket.form.title': 'Command Form',
    'takeoutOrderLifecycle.createKitchenTicket.status.label': 'Status',
    'takeoutOrderLifecycle.createKitchenTicket.submit': 'Create Kitchen Ticket',
    'takeoutOrderLifecycle.updateOrderStatus.title': 'Atualizar status do pedido',
    'takeoutOrderLifecycle.updateOrderStatus.form.title': 'Command Form',
    'takeoutOrderLifecycle.updateOrderStatus.status.label': 'Status',
    'takeoutOrderLifecycle.updateOrderStatus.closedAt.label': 'Closed At',
    'takeoutOrderLifecycle.updateOrderStatus.cancelledAt.label': 'Cancelled At',
    'takeoutOrderLifecycle.updateOrderStatus.cancellationReason.label': 'Cancellation Reason',
    'takeoutOrderLifecycle.updateOrderStatus.submit': 'Update Order Status',
};
const message_en = {
    'takeoutOrderLifecycle.section.main.title': 'Takeout Order Lifecycle',
    'takeoutOrderLifecycle.createOrder.title': 'Create Order',
    'takeoutOrderLifecycle.createOrder.form.title': 'Command Form',
    'takeoutOrderLifecycle.createOrder.orderType.label': 'Order Type',
    'takeoutOrderLifecycle.createOrder.status.label': 'Status',
    'takeoutOrderLifecycle.createOrder.totalAmount.label': 'Total Amount',
    'takeoutOrderLifecycle.createOrder.notes.label': 'Notes',
    'takeoutOrderLifecycle.createOrder.customerName.label': 'Customer Name',
    'takeoutOrderLifecycle.createOrder.customerPhone.label': 'Customer Phone',
    'takeoutOrderLifecycle.createOrder.numberOfGuests.label': 'Number Of Guests',
    'takeoutOrderLifecycle.createOrder.closedAt.label': 'Closed At',
    'takeoutOrderLifecycle.createOrder.cancelledAt.label': 'Cancelled At',
    'takeoutOrderLifecycle.createOrder.cancellationReason.label': 'Cancellation Reason',
    'takeoutOrderLifecycle.createOrder.submit': 'Create Order',
    'takeoutOrderLifecycle.addOrderItem.title': 'Add Order Item',
    'takeoutOrderLifecycle.addOrderItem.form.title': 'Command Form',
    'takeoutOrderLifecycle.addOrderItem.quantity.label': 'Quantity',
    'takeoutOrderLifecycle.addOrderItem.unitPrice.label': 'Unit Price',
    'takeoutOrderLifecycle.addOrderItem.totalPrice.label': 'Total Price',
    'takeoutOrderLifecycle.addOrderItem.observations.label': 'Observations',
    'takeoutOrderLifecycle.addOrderItem.status.label': 'Status',
    'takeoutOrderLifecycle.addOrderItem.submit': 'Add Order Item',
    'takeoutOrderLifecycle.createKitchenTicket.title': 'Create Kitchen Ticket',
    'takeoutOrderLifecycle.createKitchenTicket.form.title': 'Command Form',
    'takeoutOrderLifecycle.createKitchenTicket.status.label': 'Status',
    'takeoutOrderLifecycle.createKitchenTicket.submit': 'Create Kitchen Ticket',
    'takeoutOrderLifecycle.updateOrderStatus.title': 'Update Order Status',
    'takeoutOrderLifecycle.updateOrderStatus.form.title': 'Command Form',
    'takeoutOrderLifecycle.updateOrderStatus.status.label': 'Status',
    'takeoutOrderLifecycle.updateOrderStatus.closedAt.label': 'Closed At',
    'takeoutOrderLifecycle.updateOrderStatus.cancelledAt.label': 'Cancelled At',
    'takeoutOrderLifecycle.updateOrderStatus.cancellationReason.label': 'Cancellation Reason',
    'takeoutOrderLifecycle.updateOrderStatus.submit': 'Update Order Status',
};
export class CafeFlowTakeoutOrderLifecycleBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        // ── pageStatus ──
        this.status = '';
        // ── actionStatus ──
        this.createOrderState = 'idle';
        this.addOrderItemState = 'idle';
        this.createKitchenTicketState = 'idle';
        this.updateOrderStatusState = 'idle';
        // ── createOrder inputs ──
        this.createOrderOrderType = '';
        this.createOrderStatus = '';
        this.createOrderTotalAmount = '';
        this.createOrderNotes = '';
        this.createOrderCustomerName = '';
        this.createOrderCustomerPhone = '';
        this.createOrderNumberOfGuests = '';
        this.createOrderClosedAt = '';
        this.createOrderCancelledAt = '';
        this.createOrderCancellationReason = '';
        // ── addOrderItem inputs ──
        this.addOrderItemQuantity = '';
        this.addOrderItemUnitPrice = '';
        this.addOrderItemTotalPrice = '';
        this.addOrderItemObservations = '';
        this.addOrderItemStatus = '';
        // ── createKitchenTicket inputs ──
        this.createKitchenTicketStatus = '';
        // ── updateOrderStatus inputs ──
        this.updateOrderStatusStatus = '';
        this.updateOrderStatusClosedAt = '';
        this.updateOrderStatusCancelledAt = '';
        this.updateOrderStatusCancellationReason = '';
    }
    // ── i18n ──
    get msg() {
        const lang = this.lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    // ──────────────────────────────────────
    //  State setters – createOrder
    // ──────────────────────────────────────
    setCreateOrderOrderType(value) {
        this.createOrderOrderType = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.orderType', value);
        this.requestUpdate();
    }
    handleCreateOrderOrderTypeChange(e) {
        const value = e.target.value;
        this.setCreateOrderOrderType(value);
    }
    setCreateOrderStatus(value) {
        this.createOrderStatus = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.status', value);
        this.requestUpdate();
    }
    handleCreateOrderStatusChange(e) {
        const value = e.target.value;
        this.setCreateOrderStatus(value);
    }
    setCreateOrderTotalAmount(value) {
        this.createOrderTotalAmount = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.totalAmount', value);
        this.requestUpdate();
    }
    handleCreateOrderTotalAmountChange(e) {
        const value = e.target.value;
        this.setCreateOrderTotalAmount(value);
    }
    setCreateOrderNotes(value) {
        this.createOrderNotes = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.notes', value);
        this.requestUpdate();
    }
    handleCreateOrderNotesChange(e) {
        const value = e.target.value;
        this.setCreateOrderNotes(value);
    }
    setCreateOrderCustomerName(value) {
        this.createOrderCustomerName = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.customerName', value);
        this.requestUpdate();
    }
    handleCreateOrderCustomerNameChange(e) {
        const value = e.target.value;
        this.setCreateOrderCustomerName(value);
    }
    setCreateOrderCustomerPhone(value) {
        this.createOrderCustomerPhone = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.customerPhone', value);
        this.requestUpdate();
    }
    handleCreateOrderCustomerPhoneChange(e) {
        const value = e.target.value;
        this.setCreateOrderCustomerPhone(value);
    }
    setCreateOrderNumberOfGuests(value) {
        this.createOrderNumberOfGuests = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.numberOfGuests', value);
        this.requestUpdate();
    }
    handleCreateOrderNumberOfGuestsChange(e) {
        const value = e.target.value;
        this.setCreateOrderNumberOfGuests(value);
    }
    setCreateOrderClosedAt(value) {
        this.createOrderClosedAt = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.closedAt', value);
        this.requestUpdate();
    }
    handleCreateOrderClosedAtChange(e) {
        const value = e.target.value;
        this.setCreateOrderClosedAt(value);
    }
    setCreateOrderCancelledAt(value) {
        this.createOrderCancelledAt = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.cancelledAt', value);
        this.requestUpdate();
    }
    handleCreateOrderCancelledAtChange(e) {
        const value = e.target.value;
        this.setCreateOrderCancelledAt(value);
    }
    setCreateOrderCancellationReason(value) {
        this.createOrderCancellationReason = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.cancellationReason', value);
        this.requestUpdate();
    }
    handleCreateOrderCancellationReasonChange(e) {
        const value = e.target.value;
        this.setCreateOrderCancellationReason(value);
    }
    // ──────────────────────────────────────
    //  State setters – addOrderItem
    // ──────────────────────────────────────
    setAddOrderItemQuantity(value) {
        this.addOrderItemQuantity = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.quantity', value);
        this.requestUpdate();
    }
    handleAddOrderItemQuantityChange(e) {
        const value = e.target.value;
        this.setAddOrderItemQuantity(value);
    }
    setAddOrderItemUnitPrice(value) {
        this.addOrderItemUnitPrice = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.unitPrice', value);
        this.requestUpdate();
    }
    handleAddOrderItemUnitPriceChange(e) {
        const value = e.target.value;
        this.setAddOrderItemUnitPrice(value);
    }
    setAddOrderItemTotalPrice(value) {
        this.addOrderItemTotalPrice = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.totalPrice', value);
        this.requestUpdate();
    }
    handleAddOrderItemTotalPriceChange(e) {
        const value = e.target.value;
        this.setAddOrderItemTotalPrice(value);
    }
    setAddOrderItemObservations(value) {
        this.addOrderItemObservations = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.observations', value);
        this.requestUpdate();
    }
    handleAddOrderItemObservationsChange(e) {
        const value = e.target.value;
        this.setAddOrderItemObservations(value);
    }
    setAddOrderItemStatus(value) {
        this.addOrderItemStatus = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.status', value);
        this.requestUpdate();
    }
    handleAddOrderItemStatusChange(e) {
        const value = e.target.value;
        this.setAddOrderItemStatus(value);
    }
    // ──────────────────────────────────────
    //  State setters – createKitchenTicket
    // ──────────────────────────────────────
    setCreateKitchenTicketStatus(value) {
        this.createKitchenTicketStatus = value;
        setState('ui.takeoutOrderLifecycle.input.createKitchenTicket.status', value);
        this.requestUpdate();
    }
    handleCreateKitchenTicketStatusChange(e) {
        const value = e.target.value;
        this.setCreateKitchenTicketStatus(value);
    }
    // ──────────────────────────────────────
    //  State setters – updateOrderStatus
    // ──────────────────────────────────────
    setUpdateOrderStatusStatus(value) {
        this.updateOrderStatusStatus = value;
        setState('ui.takeoutOrderLifecycle.input.updateOrderStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusStatusChange(e) {
        const value = e.target.value;
        this.setUpdateOrderStatusStatus(value);
    }
    setUpdateOrderStatusClosedAt(value) {
        this.updateOrderStatusClosedAt = value;
        setState('ui.takeoutOrderLifecycle.input.updateOrderStatus.closedAt', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusClosedAtChange(e) {
        const value = e.target.value;
        this.setUpdateOrderStatusClosedAt(value);
    }
    setUpdateOrderStatusCancelledAt(value) {
        this.updateOrderStatusCancelledAt = value;
        setState('ui.takeoutOrderLifecycle.input.updateOrderStatus.cancelledAt', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusCancelledAtChange(e) {
        const value = e.target.value;
        this.setUpdateOrderStatusCancelledAt(value);
    }
    setUpdateOrderStatusCancellationReason(value) {
        this.updateOrderStatusCancellationReason = value;
        setState('ui.takeoutOrderLifecycle.input.updateOrderStatus.cancellationReason', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusCancellationReasonChange(e) {
        const value = e.target.value;
        this.setUpdateOrderStatusCancellationReason(value);
    }
    // ──────────────────────────────────────
    //  Commands
    // ──────────────────────────────────────
    async createOrder() {
        this.createOrderState = 'loading';
        setState('ui.takeoutOrderLifecycle.action.createOrder.status', 'loading');
        this.requestUpdate();
        const params = {
            orderType: this.createOrderOrderType,
            status: this.createOrderStatus,
            totalAmount: Number(this.createOrderTotalAmount) || 0,
            ...(this.createOrderNotes ? { notes: this.createOrderNotes } : {}),
            ...(this.createOrderCustomerName ? { customerName: this.createOrderCustomerName } : {}),
            ...(this.createOrderCustomerPhone ? { customerPhone: this.createOrderCustomerPhone } : {}),
            ...(this.createOrderNumberOfGuests ? { numberOfGuests: Number(this.createOrderNumberOfGuests) || 0 } : {}),
            ...(this.createOrderClosedAt ? { closedAt: this.createOrderClosedAt } : {}),
            ...(this.createOrderCancelledAt ? { cancelledAt: this.createOrderCancelledAt } : {}),
            ...(this.createOrderCancellationReason ? { cancellationReason: this.createOrderCancellationReason } : {}),
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.takeoutOrderLifecycle.createOrder', params, options);
        if (response.ok) {
            this.createOrderState = 'success';
            setState('ui.takeoutOrderLifecycle.action.createOrder.status', 'success');
        }
        else {
            this.createOrderState = 'error';
            setState('ui.takeoutOrderLifecycle.action.createOrder.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateOrderClick() {
        runBlockingUiAction(async () => {
            await this.createOrder();
        });
    }
    async addOrderItem() {
        this.addOrderItemState = 'loading';
        setState('ui.takeoutOrderLifecycle.action.addOrderItem.status', 'loading');
        this.requestUpdate();
        const params = {
            quantity: Number(this.addOrderItemQuantity) || 0,
            unitPrice: Number(this.addOrderItemUnitPrice) || 0,
            totalPrice: Number(this.addOrderItemTotalPrice) || 0,
            ...(this.addOrderItemObservations ? { observations: this.addOrderItemObservations } : {}),
            status: this.addOrderItemStatus,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.takeoutOrderLifecycle.addOrderItem', params, options);
        if (response.ok) {
            this.addOrderItemState = 'success';
            setState('ui.takeoutOrderLifecycle.action.addOrderItem.status', 'success');
        }
        else {
            this.addOrderItemState = 'error';
            setState('ui.takeoutOrderLifecycle.action.addOrderItem.status', 'error');
        }
        this.requestUpdate();
    }
    handleAddOrderItemClick() {
        runBlockingUiAction(async () => {
            await this.addOrderItem();
        });
    }
    async createKitchenTicket() {
        this.createKitchenTicketState = 'loading';
        setState('ui.takeoutOrderLifecycle.action.createKitchenTicket.status', 'loading');
        this.requestUpdate();
        const params = {
            status: this.createKitchenTicketStatus,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.takeoutOrderLifecycle.createKitchenTicket', params, options);
        if (response.ok) {
            this.createKitchenTicketState = 'success';
            setState('ui.takeoutOrderLifecycle.action.createKitchenTicket.status', 'success');
        }
        else {
            this.createKitchenTicketState = 'error';
            setState('ui.takeoutOrderLifecycle.action.createKitchenTicket.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateKitchenTicketClick() {
        runBlockingUiAction(async () => {
            await this.createKitchenTicket();
        });
    }
    async updateOrderStatus() {
        this.updateOrderStatusState = 'loading';
        setState('ui.takeoutOrderLifecycle.action.updateOrderStatus.status', 'loading');
        this.requestUpdate();
        const params = {
            status: this.updateOrderStatusStatus,
            ...(this.updateOrderStatusClosedAt ? { closedAt: this.updateOrderStatusClosedAt } : {}),
            ...(this.updateOrderStatusCancelledAt ? { cancelledAt: this.updateOrderStatusCancelledAt } : {}),
            ...(this.updateOrderStatusCancellationReason ? { cancellationReason: this.updateOrderStatusCancellationReason } : {}),
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.takeoutOrderLifecycle.updateOrderStatus', params, options);
        if (response.ok) {
            this.updateOrderStatusState = 'success';
            setState('ui.takeoutOrderLifecycle.action.updateOrderStatus.status', 'success');
        }
        else {
            this.updateOrderStatusState = 'error';
            setState('ui.takeoutOrderLifecycle.action.updateOrderStatus.status', 'error');
        }
        this.requestUpdate();
    }
    handleUpdateOrderStatusClick() {
        runBlockingUiAction(async () => {
            await this.updateOrderStatus();
        });
    }
    // ──────────────────────────────────────
    //  Lifecycle
    // ──────────────────────────────────────
    connectedCallback() {
        super.connectedCallback();
        // Restore shared state if available, falling back to defaults
        const savedStatus = getState('ui.takeoutOrderLifecycle.status');
        if (savedStatus !== undefined) {
            this.status = savedStatus;
        }
        const savedCreateOrderState = getState('ui.takeoutOrderLifecycle.action.createOrder.status');
        if (savedCreateOrderState !== undefined) {
            this.createOrderState = savedCreateOrderState;
        }
        const savedAddOrderItemState = getState('ui.takeoutOrderLifecycle.action.addOrderItem.status');
        if (savedAddOrderItemState !== undefined) {
            this.addOrderItemState = savedAddOrderItemState;
        }
        const savedCreateKitchenTicketState = getState('ui.takeoutOrderLifecycle.action.createKitchenTicket.status');
        if (savedCreateKitchenTicketState !== undefined) {
            this.createKitchenTicketState = savedCreateKitchenTicketState;
        }
        const savedUpdateOrderStatusState = getState('ui.takeoutOrderLifecycle.action.updateOrderStatus.status');
        if (savedUpdateOrderStatusState !== undefined) {
            this.updateOrderStatusState = savedUpdateOrderStatusState;
        }
        // No initialLoads defined – nothing to run on connect
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderState", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createKitchenTicketState", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderOrderType", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderTotalAmount", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderNotes", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderCustomerName", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderCustomerPhone", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderNumberOfGuests", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderCancelledAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderCancellationReason", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemQuantity", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemUnitPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemTotalPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemObservations", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createKitchenTicketStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusCancelledAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusCancellationReason", void 0);
