/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'manageMenuCategories.section.title': 'Gerenciar categorias do cardápio',
    'manageMenuCategories.organism.title': 'Gerenciar categorias do cardápio',
    'manageMenuCategories.form.title': 'Dados da categoria',
    'manageMenuCategories.field.menuCategoryId': 'ID da categoria',
    'manageMenuCategories.field.name': 'Nome',
    'manageMenuCategories.field.description': 'Descrição',
    'manageMenuCategories.field.status': 'Status',
    'manageMenuCategories.action.submit': 'Salvar alterações',
};
const message_en = {
    'manageMenuCategories.section.title': 'Manage menu categories',
    'manageMenuCategories.organism.title': 'Manage menu categories',
    'manageMenuCategories.form.title': 'Category data',
    'manageMenuCategories.field.menuCategoryId': 'Category ID',
    'manageMenuCategories.field.name': 'Name',
    'manageMenuCategories.field.description': 'Description',
    'manageMenuCategories.field.status': 'Status',
    'manageMenuCategories.action.submit': 'Save changes',
};
export class CafeFlowManageMenuCategoriesBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.manageMenuCategoriesState = 'idle';
        this.manageMenuCategoriesMenuCategoryId = '';
        this.manageMenuCategoriesName = '';
        this.manageMenuCategoriesDescription = '';
        this.manageMenuCategoriesStatus = '';
    }
    get msg() {
        const lang = this.__lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.manageMenuCategories.status') ?? '';
        this.manageMenuCategoriesState = getState('ui.manageMenuCategories.action.manageMenuCategories.status') ?? 'idle';
        this.manageMenuCategoriesMenuCategoryId = getState('ui.manageMenuCategories.input.manageMenuCategories.menuCategoryId') ?? '';
        this.manageMenuCategoriesName = getState('ui.manageMenuCategories.input.manageMenuCategories.name') ?? '';
        this.manageMenuCategoriesDescription = getState('ui.manageMenuCategories.input.manageMenuCategories.description') ?? '';
        this.manageMenuCategoriesStatus = getState('ui.manageMenuCategories.input.manageMenuCategories.status') ?? '';
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // ── State setters ──────────────────────────────────────────────
    setManageMenuCategoriesMenuCategoryId(value) {
        this.manageMenuCategoriesMenuCategoryId = value;
        setState('ui.manageMenuCategories.input.manageMenuCategories.menuCategoryId', value);
        this.requestUpdate();
    }
    handleManageMenuCategoriesMenuCategoryIdChange(e) {
        const target = e.target;
        this.setManageMenuCategoriesMenuCategoryId(target.value);
    }
    setManageMenuCategoriesName(value) {
        this.manageMenuCategoriesName = value;
        setState('ui.manageMenuCategories.input.manageMenuCategories.name', value);
        this.requestUpdate();
    }
    handleManageMenuCategoriesNameChange(e) {
        const target = e.target;
        this.setManageMenuCategoriesName(target.value);
    }
    setManageMenuCategoriesDescription(value) {
        this.manageMenuCategoriesDescription = value;
        setState('ui.manageMenuCategories.input.manageMenuCategories.description', value);
        this.requestUpdate();
    }
    handleManageMenuCategoriesDescriptionChange(e) {
        const target = e.target;
        this.setManageMenuCategoriesDescription(target.value);
    }
    setManageMenuCategoriesStatus(value) {
        this.manageMenuCategoriesStatus = value;
        setState('ui.manageMenuCategories.input.manageMenuCategories.status', value);
        this.requestUpdate();
    }
    handleManageMenuCategoriesStatusChange(e) {
        const target = e.target;
        this.setManageMenuCategoriesStatus(target.value);
    }
    // ── Command action ─────────────────────────────────────────────
    async manageMenuCategories() {
        this.manageMenuCategoriesState = 'loading';
        setState('ui.manageMenuCategories.action.manageMenuCategories.status', 'loading');
        this.requestUpdate();
        const params = {
            menuCategoryId: this.manageMenuCategoriesMenuCategoryId || undefined,
            name: this.manageMenuCategoriesName,
            description: this.manageMenuCategoriesDescription || undefined,
            status: this.manageMenuCategoriesStatus,
        };
        const options = { mode: 'blocking', timeoutMs: 30000 };
        try {
            const response = await execBff('cafeFlow.manageMenuCategories.manageMenuCategories', params, options);
            if (response.ok) {
                this.manageMenuCategoriesState = 'success';
                setState('ui.manageMenuCategories.action.manageMenuCategories.status', 'success');
            }
            else {
                this.manageMenuCategoriesState = 'error';
                setState('ui.manageMenuCategories.action.manageMenuCategories.status', 'error');
            }
        }
        catch {
            this.manageMenuCategoriesState = 'error';
            setState('ui.manageMenuCategories.action.manageMenuCategories.status', 'error');
        }
        this.requestUpdate();
    }
    handleManageMenuCategoriesClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.manageMenuCategories();
        });
    }
}
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesState", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesMenuCategoryId", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesName", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesDescription", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesStatus", void 0);
