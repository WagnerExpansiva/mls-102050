/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'manageMenuItems.section.title': 'Gerenciar itens do cardápio',
    'manageMenuItems.organism.title': 'Gerenciar itens do cardápio',
    'manageMenuItems.form.title': 'Detalhes do item do cardápio',
    'manageMenuItems.actions.title': 'Ações',
    'manageMenuItems.field.menuItemId': 'ID do item',
    'manageMenuItems.field.menuCategoryId': 'Categoria',
    'manageMenuItems.field.name': 'Nome',
    'manageMenuItems.field.description': 'Descrição',
    'manageMenuItems.field.price': 'Preço',
    'manageMenuItems.field.status': 'Status',
    'manageMenuItems.action.submit': 'Salvar alterações',
};
const message_en = {
    'manageMenuItems.section.title': 'Manage menu items',
    'manageMenuItems.organism.title': 'Manage menu items',
    'manageMenuItems.form.title': 'Menu item details',
    'manageMenuItems.actions.title': 'Actions',
    'manageMenuItems.field.menuItemId': 'Item ID',
    'manageMenuItems.field.menuCategoryId': 'Category',
    'manageMenuItems.field.name': 'Name',
    'manageMenuItems.field.description': 'Description',
    'manageMenuItems.field.price': 'Price',
    'manageMenuItems.field.status': 'Status',
    'manageMenuItems.action.submit': 'Save changes',
};
export class CafeFlowManageMenuItemsBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.manageMenuItemsState = 'idle';
        this.manageMenuItemsMenuItemId = '';
        this.manageMenuItemsMenuCategoryId = '';
        this.manageMenuItemsName = '';
        this.manageMenuItemsDescription = '';
        this.manageMenuItemsPrice = '';
        this.manageMenuItemsStatus = '';
    }
    get msg() {
        const lang = this.__lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.manageMenuItems.status') ?? '';
        this.manageMenuItemsState = getState('ui.manageMenuItems.action.manageMenuItems.status') ?? 'idle';
        this.manageMenuItemsMenuItemId = getState('ui.manageMenuItems.input.manageMenuItems.menuItemId') ?? '';
        this.manageMenuItemsMenuCategoryId = getState('ui.manageMenuItems.input.manageMenuItems.menuCategoryId') ?? '';
        this.manageMenuItemsName = getState('ui.manageMenuItems.input.manageMenuItems.name') ?? '';
        this.manageMenuItemsDescription = getState('ui.manageMenuItems.input.manageMenuItems.description') ?? '';
        this.manageMenuItemsPrice = getState('ui.manageMenuItems.input.manageMenuItems.price') ?? '';
        this.manageMenuItemsStatus = getState('ui.manageMenuItems.input.manageMenuItems.status') ?? '';
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- State setters ---
    setManageMenuItemsMenuItemId(value) {
        this.manageMenuItemsMenuItemId = value;
        setState('ui.manageMenuItems.input.manageMenuItems.menuItemId', value);
        this.requestUpdate();
    }
    handleManageMenuItemsMenuItemIdChange(e) {
        const value = e.target.value;
        this.setManageMenuItemsMenuItemId(value);
    }
    setManageMenuItemsMenuCategoryId(value) {
        this.manageMenuItemsMenuCategoryId = value;
        setState('ui.manageMenuItems.input.manageMenuItems.menuCategoryId', value);
        this.requestUpdate();
    }
    handleManageMenuItemsMenuCategoryIdChange(e) {
        const value = e.target.value;
        this.setManageMenuItemsMenuCategoryId(value);
    }
    setManageMenuItemsName(value) {
        this.manageMenuItemsName = value;
        setState('ui.manageMenuItems.input.manageMenuItems.name', value);
        this.requestUpdate();
    }
    handleManageMenuItemsNameChange(e) {
        const value = e.target.value;
        this.setManageMenuItemsName(value);
    }
    setManageMenuItemsDescription(value) {
        this.manageMenuItemsDescription = value;
        setState('ui.manageMenuItems.input.manageMenuItems.description', value);
        this.requestUpdate();
    }
    handleManageMenuItemsDescriptionChange(e) {
        const value = e.target.value;
        this.setManageMenuItemsDescription(value);
    }
    setManageMenuItemsPrice(value) {
        this.manageMenuItemsPrice = value;
        setState('ui.manageMenuItems.input.manageMenuItems.price', value);
        this.requestUpdate();
    }
    handleManageMenuItemsPriceChange(e) {
        const value = e.target.value;
        this.setManageMenuItemsPrice(value);
    }
    setManageMenuItemsStatus(value) {
        this.manageMenuItemsStatus = value;
        setState('ui.manageMenuItems.input.manageMenuItems.status', value);
        this.requestUpdate();
    }
    handleManageMenuItemsStatusChange(e) {
        const value = e.target.value;
        this.setManageMenuItemsStatus(value);
    }
    // --- Command action ---
    async manageMenuItems() {
        this.manageMenuItemsState = 'loading';
        setState('ui.manageMenuItems.action.manageMenuItems.status', 'loading');
        this.requestUpdate();
        const params = {
            menuItemId: this.manageMenuItemsMenuItemId || undefined,
            menuCategoryId: this.manageMenuItemsMenuCategoryId || undefined,
            name: this.manageMenuItemsName,
            description: this.manageMenuItemsDescription || undefined,
            price: Number(this.manageMenuItemsPrice),
            status: this.manageMenuItemsStatus,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.manageMenuItems.manageMenuItems', params, options);
            if (response.ok) {
                this.manageMenuItemsState = 'success';
                setState('ui.manageMenuItems.action.manageMenuItems.status', 'success');
            }
            else {
                this.manageMenuItemsState = 'error';
                setState('ui.manageMenuItems.action.manageMenuItems.status', 'error');
            }
        }
        catch {
            this.manageMenuItemsState = 'error';
            setState('ui.manageMenuItems.action.manageMenuItems.status', 'error');
        }
        this.requestUpdate();
    }
    handleManageMenuItemsClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.manageMenuItems();
        });
    }
}
__decorate([
    property({ type: String })
], CafeFlowManageMenuItemsBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsState", void 0);
__decorate([
    property({ type: String })
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsMenuItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsMenuCategoryId", void 0);
__decorate([
    property({ type: String })
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsName", void 0);
__decorate([
    property({ type: String })
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsDescription", void 0);
__decorate([
    property({ type: String })
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsStatus", void 0);
