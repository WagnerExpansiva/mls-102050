/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'kitchenProductionFlow.section.main.title': 'Fluxo de produção da cozinha',
    'kitchenProductionFlow.organism.viewKitchenTickets.title': 'Consultar tickets da cozinha',
    'kitchenProductionFlow.intent.viewKitchenTickets.queryList.title': 'Query List',
    'kitchenProductionFlow.field.kitchenTicketId.label': 'Kitchen Ticket Id',
    'kitchenProductionFlow.field.orderId.label': 'Order Id',
    'kitchenProductionFlow.field.status.label': 'Status',
    'kitchenProductionFlow.field.createdAt.label': 'Created At',
    'kitchenProductionFlow.field.updatedAt.label': 'Updated At',
    'kitchenProductionFlow.filter.kitchenTicketId.label': 'Kitchen Ticket Id',
    'kitchenProductionFlow.filter.orderId.label': 'Order Id',
    'kitchenProductionFlow.filter.status.label': 'Status',
    'kitchenProductionFlow.filter.createdAt.label': 'Created At',
    'kitchenProductionFlow.filter.updatedAt.label': 'Updated At',
    'kitchenProductionFlow.action.viewKitchenTickets.label': 'View Kitchen Tickets',
    'kitchenProductionFlow.organism.updateKitchenTicketStatus.title': 'Atualizar status do ticket de cozinha',
    'kitchenProductionFlow.intent.updateKitchenTicketStatus.commandForm.title': 'Command Form',
    'kitchenProductionFlow.field.kitchenTicketStatus.label': 'Status',
    'kitchenProductionFlow.action.updateKitchenTicketStatus.label': 'Update Kitchen Ticket Status',
    'kitchenProductionFlow.organism.updateOrderItemStatus.title': 'Atualizar status de item do pedido',
    'kitchenProductionFlow.intent.updateOrderItemStatus.commandForm.title': 'Command Form',
    'kitchenProductionFlow.field.orderItemStatus.label': 'Status',
    'kitchenProductionFlow.action.updateOrderItemStatus.label': 'Update Order Item Status',
};
const message_en = {
    'kitchenProductionFlow.section.main.title': 'Kitchen Production Flow',
    'kitchenProductionFlow.organism.viewKitchenTickets.title': 'Query Kitchen Tickets',
    'kitchenProductionFlow.intent.viewKitchenTickets.queryList.title': 'Query List',
    'kitchenProductionFlow.field.kitchenTicketId.label': 'Kitchen Ticket Id',
    'kitchenProductionFlow.field.orderId.label': 'Order Id',
    'kitchenProductionFlow.field.status.label': 'Status',
    'kitchenProductionFlow.field.createdAt.label': 'Created At',
    'kitchenProductionFlow.field.updatedAt.label': 'Updated At',
    'kitchenProductionFlow.filter.kitchenTicketId.label': 'Kitchen Ticket Id',
    'kitchenProductionFlow.filter.orderId.label': 'Order Id',
    'kitchenProductionFlow.filter.status.label': 'Status',
    'kitchenProductionFlow.filter.createdAt.label': 'Created At',
    'kitchenProductionFlow.filter.updatedAt.label': 'Updated At',
    'kitchenProductionFlow.action.viewKitchenTickets.label': 'View Kitchen Tickets',
    'kitchenProductionFlow.organism.updateKitchenTicketStatus.title': 'Update Kitchen Ticket Status',
    'kitchenProductionFlow.intent.updateKitchenTicketStatus.commandForm.title': 'Command Form',
    'kitchenProductionFlow.field.kitchenTicketStatus.label': 'Status',
    'kitchenProductionFlow.action.updateKitchenTicketStatus.label': 'Update Kitchen Ticket Status',
    'kitchenProductionFlow.organism.updateOrderItemStatus.title': 'Update Order Item Status',
    'kitchenProductionFlow.intent.updateOrderItemStatus.commandForm.title': 'Command Form',
    'kitchenProductionFlow.field.orderItemStatus.label': 'Status',
    'kitchenProductionFlow.action.updateOrderItemStatus.label': 'Update Order Item Status',
};
export class CafeFlowKitchenProductionFlowBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        // ── Page status ──────────────────────────────────────────────
        this.status = '';
        // ── Action statuses ──────────────────────────────────────────
        this.viewKitchenTicketsState = 'idle';
        this.updateKitchenTicketStatusState = 'idle';
        this.updateOrderItemStatusState = 'idle';
        // ── viewKitchenTickets inputs ────────────────────────────────
        this.viewKitchenTicketsKitchenTicketId = '';
        this.viewKitchenTicketsOrderId = '';
        this.viewKitchenTicketsStatus = '';
        this.viewKitchenTicketsCreatedAt = '';
        this.viewKitchenTicketsUpdatedAt = '';
        // ── viewKitchenTickets data ──────────────────────────────────
        this.viewKitchenTicketsData = [];
        // ── updateKitchenTicketStatus input ──────────────────────────
        this.updateKitchenTicketStatusStatus = '';
        // ── updateOrderItemStatus input ──────────────────────────────
        this.updateOrderItemStatusStatus = '';
    }
    // ── i18n ─────────────────────────────────────────────────────
    get msg() {
        const lang = this.lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    // ═══════════════════════════════════════════════════════════════
    //  Query / Command methods
    // ═══════════════════════════════════════════════════════════════
    async loadViewKitchenTickets() {
        this.viewKitchenTicketsState = 'loading';
        setState('ui.kitchenProductionFlow.action.viewKitchenTickets.status', 'loading');
        this.requestUpdate();
        const params = {
            kitchenTicketId: this.viewKitchenTicketsKitchenTicketId || undefined,
            orderId: this.viewKitchenTicketsOrderId || undefined,
            status: this.viewKitchenTicketsStatus || undefined,
            createdAt: this.viewKitchenTicketsCreatedAt || undefined,
            updatedAt: this.viewKitchenTicketsUpdatedAt || undefined,
        };
        const options = { mode: 'silent' };
        try {
            const response = await execBff('cafeFlow.kitchenProductionFlow.viewKitchenTickets', params, options);
            if (response.ok) {
                this.viewKitchenTicketsData = response.data ?? [];
                setState('ui.kitchenProductionFlow.data.viewKitchenTickets', this.viewKitchenTicketsData);
                this.viewKitchenTicketsState = 'success';
                setState('ui.kitchenProductionFlow.action.viewKitchenTickets.status', 'success');
            }
            else {
                this.viewKitchenTicketsState = 'error';
                setState('ui.kitchenProductionFlow.action.viewKitchenTickets.status', 'error');
            }
        }
        catch {
            this.viewKitchenTicketsState = 'error';
            setState('ui.kitchenProductionFlow.action.viewKitchenTickets.status', 'error');
        }
        this.requestUpdate();
    }
    async updateKitchenTicketStatus() {
        this.updateKitchenTicketStatusState = 'loading';
        setState('ui.kitchenProductionFlow.action.updateKitchenTicketStatus.status', 'loading');
        this.requestUpdate();
        const params = {
            status: this.updateKitchenTicketStatusStatus,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.kitchenProductionFlow.updateKitchenTicketStatus', params, options);
            if (response.ok) {
                this.updateKitchenTicketStatusState = 'success';
                setState('ui.kitchenProductionFlow.action.updateKitchenTicketStatus.status', 'success');
            }
            else {
                this.updateKitchenTicketStatusState = 'error';
                setState('ui.kitchenProductionFlow.action.updateKitchenTicketStatus.status', 'error');
            }
        }
        catch {
            this.updateKitchenTicketStatusState = 'error';
            setState('ui.kitchenProductionFlow.action.updateKitchenTicketStatus.status', 'error');
        }
        this.requestUpdate();
    }
    async updateOrderItemStatus() {
        this.updateOrderItemStatusState = 'loading';
        setState('ui.kitchenProductionFlow.action.updateOrderItemStatus.status', 'loading');
        this.requestUpdate();
        const params = {
            status: this.updateOrderItemStatusStatus,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.kitchenProductionFlow.updateOrderItemStatus', params, options);
            if (response.ok) {
                this.updateOrderItemStatusState = 'success';
                setState('ui.kitchenProductionFlow.action.updateOrderItemStatus.status', 'success');
            }
            else {
                this.updateOrderItemStatusState = 'error';
                setState('ui.kitchenProductionFlow.action.updateOrderItemStatus.status', 'error');
            }
        }
        catch {
            this.updateOrderItemStatusState = 'error';
            setState('ui.kitchenProductionFlow.action.updateOrderItemStatus.status', 'error');
        }
        this.requestUpdate();
    }
    // ═══════════════════════════════════════════════════════════════
    //  Event handlers for query / command actions
    // ═══════════════════════════════════════════════════════════════
    handleViewKitchenTicketsClick() {
        void this.loadViewKitchenTickets();
    }
    handleUpdateKitchenTicketStatusClick() {
        void runBlockingUiAction(() => this.updateKitchenTicketStatus());
    }
    handleUpdateOrderItemStatusClick() {
        void runBlockingUiAction(() => this.updateOrderItemStatus());
    }
    // ═══════════════════════════════════════════════════════════════
    //  State setter methods
    // ═══════════════════════════════════════════════════════════════
    setViewKitchenTicketsKitchenTicketId(value) {
        this.viewKitchenTicketsKitchenTicketId = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.kitchenTicketId', value);
        this.requestUpdate();
    }
    setViewKitchenTicketsOrderId(value) {
        this.viewKitchenTicketsOrderId = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.orderId', value);
        this.requestUpdate();
    }
    setViewKitchenTicketsStatus(value) {
        this.viewKitchenTicketsStatus = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.status', value);
        this.requestUpdate();
    }
    setViewKitchenTicketsCreatedAt(value) {
        this.viewKitchenTicketsCreatedAt = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.createdAt', value);
        this.requestUpdate();
    }
    setViewKitchenTicketsUpdatedAt(value) {
        this.viewKitchenTicketsUpdatedAt = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.updatedAt', value);
        this.requestUpdate();
    }
    setUpdateKitchenTicketStatusStatus(value) {
        this.updateKitchenTicketStatusStatus = value;
        setState('ui.kitchenProductionFlow.input.updateKitchenTicketStatus.status', value);
        this.requestUpdate();
    }
    setUpdateOrderItemStatusStatus(value) {
        this.updateOrderItemStatusStatus = value;
        setState('ui.kitchenProductionFlow.input.updateOrderItemStatus.status', value);
        this.requestUpdate();
    }
    // ═══════════════════════════════════════════════════════════════
    //  State setter event handlers
    // ═══════════════════════════════════════════════════════════════
    handleViewKitchenTicketsKitchenTicketIdChange(e) {
        const target = e.target;
        this.setViewKitchenTicketsKitchenTicketId(target.value);
    }
    handleViewKitchenTicketsOrderIdChange(e) {
        const target = e.target;
        this.setViewKitchenTicketsOrderId(target.value);
    }
    handleViewKitchenTicketsStatusChange(e) {
        const target = e.target;
        this.setViewKitchenTicketsStatus(target.value);
    }
    handleViewKitchenTicketsCreatedAtChange(e) {
        const target = e.target;
        this.setViewKitchenTicketsCreatedAt(target.value);
    }
    handleViewKitchenTicketsUpdatedAtChange(e) {
        const target = e.target;
        this.setViewKitchenTicketsUpdatedAt(target.value);
    }
    handleUpdateKitchenTicketStatusStatusChange(e) {
        const target = e.target;
        this.setUpdateKitchenTicketStatusStatus(target.value);
    }
    handleUpdateOrderItemStatusStatusChange(e) {
        const target = e.target;
        this.setUpdateOrderItemStatusStatus(target.value);
    }
    // ═══════════════════════════════════════════════════════════════
    //  Lifecycle
    // ═══════════════════════════════════════════════════════════════
    connectedCallback() {
        super.connectedCallback();
        // Restore shared state where useful, falling back to defaults
        const savedStatus = getState('ui.kitchenProductionFlow.status');
        if (savedStatus !== undefined) {
            this.status = savedStatus;
        }
        const savedData = getState('ui.kitchenProductionFlow.data.viewKitchenTickets');
        if (savedData !== undefined) {
            this.viewKitchenTicketsData = savedData;
        }
        // Run initial loads
        void this.loadViewKitchenTickets();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsState", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "updateKitchenTicketStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "updateOrderItemStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsKitchenTicketId", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsOrderId", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsData", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "updateKitchenTicketStatusStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "updateOrderItemStatusStatus", void 0);
