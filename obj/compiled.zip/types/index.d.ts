declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/addOrderItem.defs" {
    export const addOrderItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "addOrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "addOrderItem";
            readonly controllerName: "AddOrderItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAddOrderItemHandler";
                readonly command: "addOrderItem";
                readonly usecaseRef: "addOrderItem";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.addOrderItem.addOrderItem";
                readonly handlerName: "cafeFlowAddOrderItemHandler";
            }];
        };
    };
    export default addOrderItemController;
    export const pipeline: readonly [{
        readonly id: "addOrderItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/addOrderItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/addOrderItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiPromotionSuggestions";
            readonly controllerName: "AiPromotionSuggestionsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAiPromotionSuggestionsHandler";
                readonly command: "aiPromotionSuggestions";
                readonly usecaseRef: "aiPromotionSuggestions";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.aiPromotionSuggestions.aiPromotionSuggestions";
                readonly handlerName: "cafeFlowAiPromotionSuggestionsHandler";
            }];
        };
    };
    export default aiPromotionSuggestionsController;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs" {
    export const aiSalesSummaryController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiSalesSummary";
            readonly controllerName: "AiSalesSummaryController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAiSalesSummaryHandler";
                readonly command: "aiSalesSummary";
                readonly usecaseRef: "aiSalesSummary";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.aiSalesSummary.aiSalesSummary";
                readonly handlerName: "cafeFlowAiSalesSummaryHandler";
            }];
        };
    };
    export default aiSalesSummaryController;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs" {
    export const browseMenuForPosController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseMenuForPos";
            readonly controllerName: "BrowseMenuForPosController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowBrowseMenuForPosHandler";
                readonly command: "browseMenuForPos";
                readonly usecaseRef: "browseMenuForPos";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.browseMenuForPos.browseMenuForPos";
                readonly handlerName: "cafeFlowBrowseMenuForPosHandler";
            }];
        };
    };
    export default browseMenuForPosController;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs" {
    export const closeDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "closeDailyShift";
            readonly controllerName: "CloseDailyShiftController";
            readonly ownerKind: "workflow";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCloseDailyShiftHandler";
                readonly command: "closeDailyShift";
                readonly usecaseRef: "closeDailyShift";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.closeDailyShift.closeDailyShift";
                readonly handlerName: "cafeFlowCloseDailyShiftHandler";
            }];
        };
    };
    export default closeDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "consumeIngredientsOnConfirmation";
            readonly controllerName: "ConsumeIngredientsOnConfirmationController";
            readonly ownerKind: "workflow";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowConsumeIngredientsOnConfirmationHandler";
                readonly command: "consumeIngredientsOnConfirmation";
                readonly usecaseRef: "consumeIngredientsOnConfirmation";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.consumeIngredientsOnConfirmation.consumeIngredientsOnConfirmation";
                readonly handlerName: "cafeFlowConsumeIngredientsOnConfirmationHandler";
            }];
        };
    };
    export default consumeIngredientsOnConfirmationController;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createDailyShift.defs" {
    export const createDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createDailyShift";
            readonly controllerName: "CreateDailyShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateDailyShiftHandler";
                readonly command: "createDailyShift";
                readonly usecaseRef: "createDailyShift";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createDailyShift.createDailyShift";
                readonly handlerName: "cafeFlowCreateDailyShiftHandler";
            }];
        };
    };
    export default createDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "createDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createKitchenTicket.defs" {
    export const createKitchenTicketController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createKitchenTicket";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createKitchenTicket";
            readonly controllerName: "CreateKitchenTicketController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateKitchenTicketHandler";
                readonly command: "createKitchenTicket";
                readonly usecaseRef: "createKitchenTicket";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createKitchenTicket.createKitchenTicket";
                readonly handlerName: "cafeFlowCreateKitchenTicketHandler";
            }];
        };
    };
    export default createKitchenTicketController;
    export const pipeline: readonly [{
        readonly id: "createKitchenTicket__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createKitchenTicket.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createKitchenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs" {
    export const createOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createOrder";
            readonly controllerName: "CreateOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateOrderHandler";
                readonly command: "createOrder";
                readonly usecaseRef: "createOrder";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createOrder.createOrder";
                readonly handlerName: "cafeFlowCreateOrderHandler";
            }];
        };
    };
    export default createOrderController;
    export const pipeline: readonly [{
        readonly id: "createOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockConsumption.defs" {
    export const createStockConsumptionController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createStockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createStockConsumption";
            readonly controllerName: "CreateStockConsumptionController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateStockConsumptionHandler";
                readonly command: "createStockConsumption";
                readonly usecaseRef: "createStockConsumption";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createStockConsumption.createStockConsumption";
                readonly handlerName: "cafeFlowCreateStockConsumptionHandler";
            }];
        };
    };
    export default createStockConsumptionController;
    export const pipeline: readonly [{
        readonly id: "createStockConsumption__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockConsumption.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "dineInOrderLifecycle";
            readonly controllerName: "DineInOrderLifecycleController";
            readonly ownerKind: "workflow";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDineInOrderLifecycleHandler";
                readonly command: "dineInOrderLifecycle";
                readonly usecaseRef: "dineInOrderLifecycle";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.dineInOrderLifecycle.dineInOrderLifecycle";
                readonly handlerName: "cafeFlowDineInOrderLifecycleHandler";
            }];
        };
    };
    export default dineInOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "generateShiftCloseReport";
            readonly controllerName: "GenerateShiftCloseReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowGenerateShiftCloseReportHandler";
                readonly command: "generateShiftCloseReport";
                readonly usecaseRef: "generateShiftCloseReport";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.generateShiftCloseReport.generateShiftCloseReport";
                readonly handlerName: "cafeFlowGenerateShiftCloseReportHandler";
            }];
        };
    };
    export default generateShiftCloseReportController;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "kitchenProductionFlow";
            readonly controllerName: "KitchenProductionFlowController";
            readonly ownerKind: "workflow";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowKitchenProductionFlowHandler";
                readonly command: "kitchenProductionFlow";
                readonly usecaseRef: "kitchenProductionFlow";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.kitchenProductionFlow.kitchenProductionFlow";
                readonly handlerName: "cafeFlowKitchenProductionFlowHandler";
            }];
        };
    };
    export default kitchenProductionFlowController;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs" {
    export const manageInventoryItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageInventoryItems";
            readonly controllerName: "ManageInventoryItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageInventoryItemsHandler";
                readonly command: "manageInventoryItems";
                readonly usecaseRef: "manageInventoryItems";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageInventoryItems.manageInventoryItems";
                readonly handlerName: "cafeFlowManageInventoryItemsHandler";
            }];
        };
    };
    export default manageInventoryItemsController;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs" {
    export const manageMenuCategoriesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuCategories";
            readonly controllerName: "ManageMenuCategoriesController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageMenuCategoriesHandler";
                readonly command: "manageMenuCategories";
                readonly usecaseRef: "manageMenuCategories";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageMenuCategories.manageMenuCategories";
                readonly handlerName: "cafeFlowManageMenuCategoriesHandler";
            }];
        };
    };
    export default manageMenuCategoriesController;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs" {
    export const manageMenuItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuItems";
            readonly controllerName: "ManageMenuItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageMenuItemsHandler";
                readonly command: "manageMenuItems";
                readonly usecaseRef: "manageMenuItems";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageMenuItems.manageMenuItems";
                readonly handlerName: "cafeFlowManageMenuItemsHandler";
            }];
        };
    };
    export default manageMenuItemsController;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs" {
    export const manageTablesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageTables";
            readonly controllerName: "ManageTablesController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageTablesHandler";
                readonly command: "manageTables";
                readonly usecaseRef: "manageTables";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageTables.manageTables";
                readonly handlerName: "cafeFlowManageTablesHandler";
            }];
        };
    };
    export default manageTablesController;
    export const pipeline: readonly [{
        readonly id: "manageTables__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs" {
    export const openDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "openDailyShift";
            readonly controllerName: "OpenDailyShiftController";
            readonly ownerKind: "workflow";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowOpenDailyShiftHandler";
                readonly command: "openDailyShift";
                readonly usecaseRef: "openDailyShift";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.openDailyShift.openDailyShift";
                readonly handlerName: "cafeFlowOpenDailyShiftHandler";
            }];
        };
    };
    export default openDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordOpeningCashMovement.defs" {
    export const recordOpeningCashMovementController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "recordOpeningCashMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "recordOpeningCashMovement";
            readonly controllerName: "RecordOpeningCashMovementController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRecordOpeningCashMovementHandler";
                readonly command: "recordOpeningCashMovement";
                readonly usecaseRef: "recordOpeningCashMovement";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.recordOpeningCashMovement.recordOpeningCashMovement";
                readonly handlerName: "cafeFlowRecordOpeningCashMovementHandler";
            }];
        };
    };
    export default recordOpeningCashMovementController;
    export const pipeline: readonly [{
        readonly id: "recordOpeningCashMovement__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordOpeningCashMovement.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordOpeningCashMovement.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs" {
    export const recordPaymentController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "recordPayment";
            readonly controllerName: "RecordPaymentController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRecordPaymentHandler";
                readonly command: "recordPayment";
                readonly usecaseRef: "recordPayment";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.recordPayment.recordPayment";
                readonly handlerName: "cafeFlowRecordPaymentHandler";
            }];
        };
    };
    export default recordPaymentController;
    export const pipeline: readonly [{
        readonly id: "recordPayment__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "takeoutOrderLifecycle";
            readonly controllerName: "TakeoutOrderLifecycleController";
            readonly ownerKind: "workflow";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowTakeoutOrderLifecycleHandler";
                readonly command: "takeoutOrderLifecycle";
                readonly usecaseRef: "takeoutOrderLifecycle";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.takeoutOrderLifecycle.takeoutOrderLifecycle";
                readonly handlerName: "cafeFlowTakeoutOrderLifecycleHandler";
            }];
        };
    };
    export default takeoutOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenTicketStatus.defs" {
    export const updateKitchenTicketStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateKitchenTicketStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateKitchenTicketStatus";
            readonly controllerName: "UpdateKitchenTicketStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateKitchenTicketStatusHandler";
                readonly command: "updateKitchenTicketStatus";
                readonly usecaseRef: "updateKitchenTicketStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateKitchenTicketStatus.updateKitchenTicketStatus";
                readonly handlerName: "cafeFlowUpdateKitchenTicketStatusHandler";
            }];
        };
    };
    export default updateKitchenTicketStatusController;
    export const pipeline: readonly [{
        readonly id: "updateKitchenTicketStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenTicketStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenTicketStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderItemStatus.defs" {
    export const updateOrderItemStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderItemStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateOrderItemStatus";
            readonly controllerName: "UpdateOrderItemStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderItemStatusHandler";
                readonly command: "updateOrderItemStatus";
                readonly usecaseRef: "updateOrderItemStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateOrderItemStatus.updateOrderItemStatus";
                readonly handlerName: "cafeFlowUpdateOrderItemStatusHandler";
            }];
        };
    };
    export default updateOrderItemStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderItemStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderItemStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderItemStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs" {
    export const updateOrderStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateOrderStatus";
            readonly controllerName: "UpdateOrderStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
                readonly command: "updateOrderStatus";
                readonly usecaseRef: "updateOrderStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateOrderStatus.updateOrderStatus";
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
            }];
        };
    };
    export default updateOrderStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTableStatus.defs" {
    export const updateTableStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateTableStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateTableStatus";
            readonly controllerName: "UpdateTableStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateTableStatusHandler";
                readonly command: "updateTableStatus";
                readonly usecaseRef: "updateTableStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateTableStatus.updateTableStatus";
                readonly handlerName: "cafeFlowUpdateTableStatusHandler";
            }];
        };
    };
    export default updateTableStatusController;
    export const pipeline: readonly [{
        readonly id: "updateTableStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTableStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTableStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenTickets.defs" {
    export const viewKitchenTicketsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewKitchenTickets";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewKitchenTickets";
            readonly controllerName: "ViewKitchenTicketsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewKitchenTicketsHandler";
                readonly command: "viewKitchenTickets";
                readonly usecaseRef: "viewKitchenTickets";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.viewKitchenTickets.viewKitchenTickets";
                readonly handlerName: "cafeFlowViewKitchenTicketsHandler";
            }];
        };
    };
    export default viewKitchenTicketsController;
    export const pipeline: readonly [{
        readonly id: "viewKitchenTickets__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenTickets.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenTickets.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewOperationalDashboard";
            readonly controllerName: "ViewOperationalDashboardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewOperationalDashboardHandler";
                readonly command: "viewOperationalDashboard";
                readonly usecaseRef: "viewOperationalDashboard";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.viewOperationalDashboard.viewOperationalDashboard";
                readonly handlerName: "cafeFlowViewOperationalDashboardHandler";
            }];
        };
    };
    export default viewOperationalDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "DailyShift";
            readonly tableName: "daily_shift";
            readonly columns: readonly [{
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status field";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains: shiftDate, openedAt, closedAt, openingCashBalance, closingCashBalance, totalSales, totalPayments, closingNotes, updatedAt";
            }];
            readonly primaryKey: readonly ["daily_shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_daily_shift_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_daily_shift_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["CashMovement"];
            };
        };
    };
    export default dailyShiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "dailyShift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs" {
    export const dailyShiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "DailyShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly className: "DailyShiftRepository";
            readonly portRef: "IDailyShiftRepository";
            readonly tableRef: "daily_shifts";
            readonly notes: readonly ["columns: daily_shift_id, status, created_at", "details JSONB: shiftDate, openedAt, closedAt, openingCashBalance, closingCashBalance, totalSales, totalPayments, closingNotes, updatedAt, CashMovement[]"];
        };
    };
    export default dailyShiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs" {
    export const inventoryItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "InventoryItem";
            readonly tableName: "inventory_item";
            readonly columns: readonly [{
                readonly name: "inventory_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status field";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains: name, description, unit, currentQuantity, minimumLevel, updatedAt";
            }];
            readonly primaryKey: readonly ["inventory_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_inventory_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_inventory_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default inventoryItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs" {
    export const inventoryItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "InventoryItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly className: "InventoryItemRepository";
            readonly portRef: "IInventoryItemRepository";
            readonly tableRef: "inventory_items";
            readonly notes: readonly ["columns: inventory_item_id, status, created_at", "details JSONB: name, description, unit, currentQuantity, minimumLevel, updatedAt"];
        };
    };
    export default inventoryItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs" {
    export const menuItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "MenuItem";
            readonly tableName: "menu_item";
            readonly columns: readonly [{
                readonly name: "menu_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier";
            }, {
                readonly name: "menu_category_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to menu category";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status field";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains: name, description, price, updatedAt";
            }];
            readonly primaryKey: readonly ["menu_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_menu_item_menu_category_id";
                readonly columns: readonly ["menu_category_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["RecipeComponent"];
            };
        };
    };
    export default menuItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "menuItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs" {
    export const menuItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MenuItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly className: "MenuItemRepository";
            readonly portRef: "IMenuItemRepository";
            readonly tableRef: "menu_items";
            readonly mdmReads: readonly ["MenuCategory"];
            readonly notes: readonly ["columns: menu_item_id, menu_category_id, status, created_at", "details JSONB: name, description, price, updatedAt, RecipeComponent[]", "mdmRefs resolved via 102034: MenuCategory"];
        };
    };
    export default menuItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "menuItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to daily shift";
            }, {
                readonly name: "table_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to table";
            }, {
                readonly name: "kitchen_ticket_id";
                readonly type: "uuid";
                readonly nullable: true;
                readonly description: "FK to kitchen ticket";
            }, {
                readonly name: "order_type";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Order type status field";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status field";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains: totalAmount, notes, customerName, customerPhone, numberOfGuests, closedAt, cancelledAt, cancellationReason, updatedAt";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_table_id";
                readonly columns: readonly ["table_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_kitchen_ticket_id";
                readonly columns: readonly ["kitchen_ticket_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_order_type";
                readonly columns: readonly ["order_type"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["OrderItem", "KitchenTicket"];
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly className: "OrderRepository";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly ["Table"];
            readonly notes: readonly ["columns: order_id, daily_shift_id, table_id, kitchen_ticket_id, order_type, status, created_at", "details JSONB: totalAmount, notes, customerName, customerPhone, numberOfGuests, closedAt, cancelledAt, cancellationReason, updatedAt, OrderItem[], KitchenTicket[]", "mdmRefs resolved via 102034: Table"];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs" {
    export const paymentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Payment";
            readonly tableName: "payment";
            readonly columns: readonly [{
                readonly name: "payment_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier";
            }, {
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to order";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to daily shift";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status field";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains: method, amount, updatedAt";
            }];
            readonly primaryKey: readonly ["payment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_payment_order_id";
                readonly columns: readonly ["order_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default paymentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "payment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs" {
    export const paymentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "PaymentRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly className: "PaymentRepository";
            readonly portRef: "IPaymentRepository";
            readonly tableRef: "payments";
            readonly notes: readonly ["columns: payment_id, order_id, daily_shift_id, status, created_at", "details JSONB: method, amount, updatedAt"];
        };
    };
    export default paymentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "paymentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs" {
    export const dailyShiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "DailyShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly interfaceName: "IDailyShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "DailyShift";
                readonly params: readonly ["dailyShiftId: string"];
                readonly description: "Retrieve a single DailyShift aggregate by its identity";
            }, {
                readonly name: "list";
                readonly returns: "DailyShift[]";
                readonly params: readonly ["filter: DailyShiftFilter"];
                readonly description: "List DailyShift aggregates matching the domain filter";
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["dailyShift: DailyShift"];
                readonly description: "Persist a DailyShift aggregate and its embedded CashMovements";
            }, {
                readonly name: "findByDate";
                readonly returns: "DailyShift[]";
                readonly params: readonly ["date: CalendarDate"];
                readonly description: "Domain finder: shifts on a specific calendar date";
            }, {
                readonly name: "findOpenShift";
                readonly returns: "DailyShift";
                readonly params: readonly [];
                readonly description: "Domain finder: the currently open shift, if any";
            }, {
                readonly name: "findByCashier";
                readonly returns: "DailyShift[]";
                readonly params: readonly ["cashierId: string"];
                readonly description: "Domain finder: shifts worked by a specific cashier";
            }];
        };
    };
    export default dailyShiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs" {
    export const inventoryItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "InventoryItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly interfaceName: "IInventoryItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "InventoryItem";
                readonly params: readonly ["inventoryItemId: string"];
                readonly description: "Retrieve a single InventoryItem aggregate by its identity";
            }, {
                readonly name: "list";
                readonly returns: "InventoryItem[]";
                readonly params: readonly ["filter: InventoryItemFilter"];
                readonly description: "List InventoryItem aggregates matching the domain filter";
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["inventoryItem: InventoryItem"];
                readonly description: "Persist an InventoryItem aggregate";
            }, {
                readonly name: "findBySku";
                readonly returns: "InventoryItem";
                readonly params: readonly ["sku: Sku"];
                readonly description: "Domain finder: item by stock-keeping unit";
            }, {
                readonly name: "findLowStock";
                readonly returns: "InventoryItem[]";
                readonly params: readonly [];
                readonly description: "Domain finder: items below their reorder threshold";
            }, {
                readonly name: "findBySupplier";
                readonly returns: "InventoryItem[]";
                readonly params: readonly ["supplierId: string"];
                readonly description: "Domain finder: items provided by a given supplier";
            }];
        };
    };
    export default inventoryItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs" {
    export const menuItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "MenuItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly interfaceName: "IMenuItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "MenuItem";
                readonly params: readonly ["menuItemId: string"];
                readonly description: "Retrieve a single MenuItem aggregate by its identity";
            }, {
                readonly name: "list";
                readonly returns: "MenuItem[]";
                readonly params: readonly ["filter: MenuItemFilter"];
                readonly description: "List MenuItem aggregates matching the domain filter";
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["menuItem: MenuItem"];
                readonly description: "Persist a MenuItem aggregate and its embedded RecipeComponents";
            }, {
                readonly name: "findByCategory";
                readonly returns: "MenuItem[]";
                readonly params: readonly ["category: MenuCategory"];
                readonly description: "Domain finder: items belonging to a menu category";
            }, {
                readonly name: "findAvailable";
                readonly returns: "MenuItem[]";
                readonly params: readonly [];
                readonly description: "Domain finder: items currently available for sale";
            }, {
                readonly name: "findByName";
                readonly returns: "MenuItem[]";
                readonly params: readonly ["name: string"];
                readonly description: "Domain finder: items matching a name search";
            }];
        };
    };
    export default menuItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "menuItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Order";
                readonly params: readonly ["orderId: string"];
                readonly description: "Retrieve a single Order aggregate by its identity";
            }, {
                readonly name: "list";
                readonly returns: "Order[]";
                readonly params: readonly ["filter: OrderFilter"];
                readonly description: "List Order aggregates matching the domain filter";
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["order: Order"];
                readonly description: "Persist an Order aggregate and its embedded OrderItems and KitchenTickets";
            }, {
                readonly name: "findByTableNumber";
                readonly returns: "Order[]";
                readonly params: readonly ["tableNumber: TableNumber"];
                readonly description: "Domain finder: orders for a specific table";
            }, {
                readonly name: "findByStatus";
                readonly returns: "Order[]";
                readonly params: readonly ["status: OrderStatus"];
                readonly description: "Domain finder: orders in a given lifecycle status";
            }, {
                readonly name: "findActiveOrders";
                readonly returns: "Order[]";
                readonly params: readonly [];
                readonly description: "Domain finder: orders that are not yet closed or cancelled";
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs" {
    export const paymentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "PaymentRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly interfaceName: "IPaymentRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Payment";
                readonly params: readonly ["paymentId: string"];
                readonly description: "Retrieve a single Payment aggregate by its identity";
            }, {
                readonly name: "list";
                readonly returns: "Payment[]";
                readonly params: readonly ["filter: PaymentFilter"];
                readonly description: "List Payment aggregates matching the domain filter";
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["payment: Payment"];
                readonly description: "Persist a Payment aggregate";
            }, {
                readonly name: "findByOrderId";
                readonly returns: "Payment[]";
                readonly params: readonly ["orderId: string"];
                readonly description: "Domain finder: payments associated with an order";
            }, {
                readonly name: "findByMethod";
                readonly returns: "Payment[]";
                readonly params: readonly ["method: PaymentMethod"];
                readonly description: "Domain finder: payments made with a specific method";
            }, {
                readonly name: "findByDateRange";
                readonly returns: "Payment[]";
                readonly params: readonly ["from: CalendarDate", "to: CalendarDate"];
                readonly description: "Domain finder: payments within a date range";
            }];
        };
    };
    export default paymentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "paymentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs" {
    export const addOrderItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "addOrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "addOrderItem";
            readonly functionName: "addOrderItem";
            readonly inputTypeName: "AddOrderItemInput";
            readonly outputTypeName: "AddOrderItemOutput";
            readonly ports: readonly ["MenuItem", "Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Validate order exists and is in a status that allows item additions (OPEN or similar)", "Validate referenced MenuItem exists and is available", "Apply orderStatusTransitions rule to ensure order can accept items", "Create OrderItem entity linked to Order and MenuItem", "Persist OrderItem via Order port (aggregate root manages items)", "Recalculate Order.totalAmount", "Persist updated Order", "If ingredientConsumptionTrigger applies, enqueue stock consumption for later confirmation"];
        };
    };
    export default addOrderItemUsecase;
    export const pipeline: readonly [{
        readonly id: "addOrderItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiPromotionSuggestions";
            readonly functionName: "aiPromotionSuggestions";
            readonly inputTypeName: "AiPromotionSuggestionsInput";
            readonly outputTypeName: "AiPromotionSuggestionsOutput";
            readonly ports: readonly ["Order", "MenuItem"];
            readonly rulesApplied: readonly [];
            readonly transactional: false;
            readonly steps: readonly ["Read recent OrderItem history via Order port", "Read MenuItem catalog via MenuItem port", "Aggregate sales frequency and revenue per MenuItem", "Generate promotion suggestions based on sales patterns", "Return structured suggestion list"];
        };
    };
    export default aiPromotionSuggestionsUsecase;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs" {
    export const aiSalesSummaryUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiSalesSummary";
            readonly functionName: "aiSalesSummary";
            readonly inputTypeName: "AiSalesSummaryInput";
            readonly outputTypeName: "AiSalesSummaryOutput";
            readonly ports: readonly ["Order", "DailyShift", "MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read DailyShift for the requested period via DailyShift port", "Read Orders within the shift via Order port", "Read MenuItem details via MenuItem port", "Aggregate totalAmount, status counts, closedAt timestamps", "Apply aiOutputLanguageSelection rule to format output language", "Generate natural-language sales summary", "Return summary with key metrics"];
        };
    };
    export default aiSalesSummaryUsecase;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs" {
    export const browseMenuForPosUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseMenuForPos";
            readonly functionName: "browseMenuForPos";
            readonly inputTypeName: "BrowseMenuForPosInput";
            readonly outputTypeName: "BrowseMenuForPosOutput";
            readonly ports: readonly ["MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read all MenuItem entries grouped by MenuCategory via MenuItem port", "Apply aiOutputLanguageSelection rule to localize item names/descriptions", "Filter out unavailable items", "Return structured menu tree for POS display"];
        };
    };
    export default browseMenuForPosUsecase;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs" {
    export const closeDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeDailyShift";
            readonly functionName: "closeDailyShift";
            readonly inputTypeName: "CloseDailyShiftInput";
            readonly outputTypeName: "CloseDailyShiftOutput";
            readonly ports: readonly ["DailyShift", "Order", "Payment"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Read current DailyShift via DailyShift port and verify status=OPEN", "Read all Orders for the shift via Order port", "Apply orderStatusTransitions rule: verify no Orders remain in OPEN or IN_PROGRESS status (close or block)", "Read all Payments via Payment port and reconcile totals", "Apply paymentTimingByOrderType rule to verify all expected payments are recorded", "Set DailyShift.status=CLOSED, closedAt, closingCashBalance, closingNotes", "Apply aiOutputLanguageSelection rule for localized close metadata", "Persist DailyShift via DailyShift port", "Invoke generateShiftCloseReport as final step", "Return close confirmation with report summary"];
        };
    };
    export default closeDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "consumeIngredientsOnConfirmation";
            readonly functionName: "consumeIngredientsOnConfirmation";
            readonly inputTypeName: "ConsumeIngredientsOnConfirmationInput";
            readonly outputTypeName: "ConsumeIngredientsOnConfirmationOutput";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order and confirmed OrderItems via Order port", "Read MenuItem recipes via MenuItem port", "Read InventoryItem stock levels via InventoryItem port", "Apply ingredientConsumptionTrigger rule to compute consumption quantities from RecipeComponent", "Validate sufficient stock for each InventoryItem", "Create StockConsumption records", "Decrement InventoryItem.currentQuantity and update status if below threshold", "Persist all changes via InventoryItem port", "Return consumption summary with any low-stock alerts"];
        };
    };
    export default consumeIngredientsOnConfirmationUsecase;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs" {
    export const createDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createDailyShift";
            readonly functionName: "createDailyShift";
            readonly inputTypeName: "CreateDailyShiftInput";
            readonly outputTypeName: "CreateDailyShiftOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Validate no open DailyShift exists for the same shiftDate via DailyShift port", "Create DailyShift entity with shiftDate, openingCashBalance, openedAt, status=OPEN", "Apply paymentTimingByOrderType rule to set expected payment flows", "Apply aiOutputLanguageSelection rule for localized shift metadata", "Persist DailyShift via DailyShift port", "Return created shift with generated dailyShiftId"];
        };
    };
    export default createDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "createDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs" {
    export const createKitchenTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createKitchenTicket";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createKitchenTicket";
            readonly functionName: "createKitchenTicket";
            readonly inputTypeName: "CreateKitchenTicketInput";
            readonly outputTypeName: "CreateKitchenTicketOutput";
            readonly ports: readonly ["Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order and its OrderItems via Order port", "Apply orderStatusTransitions rule to verify order is in a kitchen-ready status", "Build KitchenTicket from OrderItems that require preparation", "Persist KitchenTicket", "Return created ticket reference"];
        };
    };
    export default createKitchenTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "createKitchenTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly functionName: "createOrder";
            readonly inputTypeName: "CreateOrderInput";
            readonly outputTypeName: "CreateOrderOutput";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Validate DailyShift is OPEN via DailyShift port", "If orderType is DINE_IN, validate Table availability and apply tableOccupancyConsistency rule", "Apply paymentTimingByOrderType rule to determine payment expectations", "Create Order entity with status=OPEN, link to DailyShift and optional Table", "Apply orderStatusTransitions rule for initial state", "Apply aiOutputLanguageSelection rule for localized order metadata", "Persist Order via Order port", "If Table assigned, update Table status to OCCUPIED", "Return created order with generated orderId"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs" {
    export const createStockConsumptionUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createStockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createStockConsumption";
            readonly functionName: "createStockConsumption";
            readonly inputTypeName: "CreateStockConsumptionInput";
            readonly outputTypeName: "CreateStockConsumptionOutput";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order and OrderItems via Order port", "Read MenuItem recipes via MenuItem port", "Read InventoryItem current quantities via InventoryItem port", "Apply ingredientConsumptionTrigger rule to compute required quantities from RecipeComponent", "Validate sufficient stock for each InventoryItem", "Create StockConsumption records per InventoryItem", "Decrement InventoryItem.currentQuantity", "Persist updated InventoryItem via InventoryItem port", "Return consumption summary"];
        };
    };
    export default createStockConsumptionUsecase;
    export const pipeline: readonly [{
        readonly id: "createStockConsumption__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "dineInOrderLifecycle";
            readonly functionName: "dineInOrderLifecycle";
            readonly inputTypeName: "DineInOrderLifecycleInput";
            readonly outputTypeName: "DineInOrderLifecycleOutput";
            readonly ports: readonly ["Order", "MenuItem", "Payment", "InventoryItem"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 — Create Order: invoke createOrder with orderType=DINE_IN, assign Table (apply tableOccupancyConsistency)", "Step 2 — Add Items: invoke addOrderItem for each requested MenuItem (apply orderStatusTransitions)", "Step 3 — Send to Kitchen: invoke createKitchenTicket for the order", "Step 4 — Kitchen Production: invoke updateKitchenTicketStatus and updateOrderItemStatus as items are prepared", "Step 5 — Consume Ingredients: invoke consumeIngredientsOnConfirmation when items are confirmed (apply ingredientConsumptionTrigger via InventoryItem port)", "Step 6 — Record Payment: invoke recordPayment (apply paymentTimingByOrderType — dine-in pays after consumption)", "Step 7 — Close Order: invoke updateOrderStatus to CLOSED, release Table (apply tableOccupancyConsistency)", "Apply aiOutputLanguageSelection rule throughout for localized communication", "Return full lifecycle result with order, ticket, payment, and consumption references"];
        };
    };
    export default dineInOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "generateShiftCloseReport";
            readonly functionName: "generateShiftCloseReport";
            readonly inputTypeName: "GenerateShiftCloseReportInput";
            readonly outputTypeName: "GenerateShiftCloseReportOutput";
            readonly ports: readonly ["DailyShift", "Payment", "Order"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read DailyShift via DailyShift port", "Read all Payments for the shift via Payment port", "Read all Orders for the shift via Order port", "Read OrderItems for revenue breakdown", "Apply paymentTimingByOrderType rule to categorize payments", "Compute totalSales, totalPayments, cash reconciliation", "Apply aiOutputLanguageSelection rule for report language", "Return structured shift close report"];
        };
    };
    export default generateShiftCloseReportUsecase;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "kitchenProductionFlow";
            readonly functionName: "kitchenProductionFlow";
            readonly inputTypeName: "KitchenProductionFlowInput";
            readonly outputTypeName: "KitchenProductionFlowOutput";
            readonly ports: readonly ["Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 — Receive Order: read Order and its OrderItems via Order port", "Step 2 — Create Ticket: invoke createKitchenTicket (apply orderStatusTransitions)", "Step 3 — Track Progress: invoke updateOrderItemStatus as each item progresses (PENDING → IN_PROGRESS → READY)", "Step 4 — Update Ticket: invoke updateKitchenTicketStatus when all items are READY (apply orderStatusTransitions)", "Step 5 — Trigger Consumption: apply ingredientConsumptionTrigger rule when items are confirmed", "Return production flow result with ticket and item statuses"];
        };
    };
    export default kitchenProductionFlowUsecase;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs" {
    export const manageInventoryItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageInventoryItems";
            readonly functionName: "manageInventoryItems";
            readonly inputTypeName: "ManageInventoryItemsInput";
            readonly outputTypeName: "ManageInventoryItemsOutput";
            readonly ports: readonly ["InventoryItem"];
            readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read existing InventoryItem via InventoryItem port (for updates)", "Validate input fields (name, unit, currentQuantity, minimumLevel)", "Create or update InventoryItem entity", "Apply inventoryLowStockThreshold rule to set status=LOW_STOCK if below minimumLevel", "Apply ingredientConsumptionTrigger rule to verify item is not locked by pending consumptions", "Persist InventoryItem via InventoryItem port", "Return updated item"];
        };
    };
    export default manageInventoryItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs" {
    export const manageMenuCategoriesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuCategories";
            readonly functionName: "manageMenuCategories";
            readonly inputTypeName: "ManageMenuCategoriesInput";
            readonly outputTypeName: "ManageMenuCategoriesOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Validate category name uniqueness", "Create or update MenuCategory entity", "Persist via repository", "Return category"];
        };
    };
    export default manageMenuCategoriesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs" {
    export const manageMenuItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuItems";
            readonly functionName: "manageMenuItems";
            readonly inputTypeName: "ManageMenuItemsInput";
            readonly outputTypeName: "ManageMenuItemsOutput";
            readonly ports: readonly ["MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Read existing MenuItem via MenuItem port (for updates)", "Validate referenced MenuCategory exists", "Apply aiOutputLanguageSelection rule for localized name/description fields", "Create or update MenuItem entity", "Persist MenuItem via MenuItem port", "Return updated item"];
        };
    };
    export default manageMenuItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs" {
    export const manageTablesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageTables";
            readonly functionName: "manageTables";
            readonly inputTypeName: "ManageTablesInput";
            readonly outputTypeName: "ManageTablesOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly ["tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Read existing Table (for updates)", "Apply tableOccupancyConsistency rule to prevent changes that conflict with active orders", "Create or update Table entity", "Persist via repository", "Return table"];
        };
    };
    export default manageTablesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageTables__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs" {
    export const openDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "openDailyShift";
            readonly functionName: "openDailyShift";
            readonly inputTypeName: "OpenDailyShiftInput";
            readonly outputTypeName: "OpenDailyShiftOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 — Create Shift: invoke createDailyShift with shiftDate, openingCashBalance (apply paymentTimingByOrderType, aiOutputLanguageSelection)", "Step 2 — Record Opening Cash: invoke recordOpeningCashMovement with opening cash amount and reason", "Step 3 — Verify: read DailyShift to confirm status=OPEN and cash movement recorded", "Return shift opening confirmation with dailyShiftId and opening balance"];
        };
    };
    export default openDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs" {
    export const recordOpeningCashMovementUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordOpeningCashMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordOpeningCashMovement";
            readonly functionName: "recordOpeningCashMovement";
            readonly inputTypeName: "RecordOpeningCashMovementInput";
            readonly outputTypeName: "RecordOpeningCashMovementOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Validate DailyShift exists and is OPEN via DailyShift port", "Create CashMovement entity with movementType=OPENING, amount, reason", "Link CashMovement to dailyShiftId", "Persist CashMovement", "Return created movement"];
        };
    };
    export default recordOpeningCashMovementUsecase;
    export const pipeline: readonly [{
        readonly id: "recordOpeningCashMovement__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs" {
    export const recordPaymentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordPayment";
            readonly functionName: "recordPayment";
            readonly inputTypeName: "RecordPaymentInput";
            readonly outputTypeName: "RecordPaymentOutput";
            readonly ports: readonly ["Payment", "Order", "DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order via Order port to verify it exists and accepts payments", "Read DailyShift via DailyShift port to verify shift is OPEN", "Apply paymentTimingByOrderType rule to validate payment timing is allowed for orderType", "Create Payment entity linked to Order and DailyShift", "Persist Payment via Payment port", "Update Order payment status if fully paid", "Return recorded payment"];
        };
    };
    export default recordPaymentUsecase;
    export const pipeline: readonly [{
        readonly id: "recordPayment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "takeoutOrderLifecycle";
            readonly functionName: "takeoutOrderLifecycle";
            readonly inputTypeName: "TakeoutOrderLifecycleInput";
            readonly outputTypeName: "TakeoutOrderLifecycleOutput";
            readonly ports: readonly ["Order", "MenuItem", "Payment", "InventoryItem"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 — Create Order: invoke createOrder with orderType=TAKEOUT (no Table assignment, no tableOccupancyConsistency)", "Step 2 — Add Items: invoke addOrderItem for each requested MenuItem (apply orderStatusTransitions)", "Step 3 — Record Payment: invoke recordPayment (apply paymentTimingByOrderType — takeout pays upfront before preparation)", "Step 4 — Send to Kitchen: invoke createKitchenTicket for the order", "Step 5 — Kitchen Production: invoke updateKitchenTicketStatus and updateOrderItemStatus as items are prepared", "Step 6 — Consume Ingredients: invoke consumeIngredientsOnConfirmation when items are confirmed (apply ingredientConsumptionTrigger via InventoryItem port)", "Step 7 — Close Order: invoke updateOrderStatus to CLOSED (no Table release needed)", "Apply aiOutputLanguageSelection rule throughout for localized communication", "Return full lifecycle result with order, ticket, payment, and consumption references"];
        };
    };
    export default takeoutOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs" {
    export const updateKitchenTicketStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateKitchenTicketStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateKitchenTicketStatus";
            readonly functionName: "updateKitchenTicketStatus";
            readonly inputTypeName: "UpdateKitchenTicketStatusInput";
            readonly outputTypeName: "UpdateKitchenTicketStatusOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly ["orderStatusTransitions"];
            readonly transactional: true;
            readonly steps: readonly ["Read KitchenTicket by id", "Apply orderStatusTransitions rule to validate target status is reachable from current", "Update KitchenTicket.status and updatedAt", "Persist via repository", "Return updated ticket"];
        };
    };
    export default updateKitchenTicketStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateKitchenTicketStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs" {
    export const updateOrderItemStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderItemStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderItemStatus";
            readonly functionName: "updateOrderItemStatus";
            readonly inputTypeName: "UpdateOrderItemStatusInput";
            readonly outputTypeName: "UpdateOrderItemStatusOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read OrderItem by id", "Apply orderStatusTransitions rule to validate target status is reachable", "Update OrderItem.status and updatedAt", "If status transitions to CONFIRMED, apply ingredientConsumptionTrigger rule to enqueue stock consumption", "Persist via repository", "Return updated item"];
        };
    };
    export default updateOrderItemStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderItemStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly functionName: "updateOrderStatus";
            readonly inputTypeName: "UpdateOrderStatusInput";
            readonly outputTypeName: "UpdateOrderStatusOutput";
            readonly ports: readonly ["Order", "Payment", "InventoryItem"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order with OrderItems, KitchenTickets, Payments via Order port", "Apply orderStatusTransitions rule to validate target status is reachable from current", "If transitioning to CLOSED: apply paymentTimingByOrderType rule to verify all payments settled", "If transitioning to CLOSED: apply ingredientConsumptionTrigger rule to ensure stock consumed via InventoryItem port", "If transitioning to CLOSED: set closedAt, release Table (apply tableOccupancyConsistency rule)", "If transitioning to CANCELLED: set cancelledAt and cancellationReason, release Table", "Apply aiOutputLanguageSelection rule for localized status metadata", "Update Order.status and updatedAt", "If Table released, update Table status to AVAILABLE", "Persist Order via Order port", "Return updated order"];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs" {
    export const updateTableStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTableStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTableStatus";
            readonly functionName: "updateTableStatus";
            readonly inputTypeName: "UpdateTableStatusInput";
            readonly outputTypeName: "UpdateTableStatusOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly ["tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Read Table by id", "Apply tableOccupancyConsistency rule to validate status change does not conflict with active orders", "Update Table.status and updatedAt", "Persist via repository", "Return updated table"];
        };
    };
    export default updateTableStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTableStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs" {
    export const viewKitchenTicketsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewKitchenTickets";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewKitchenTickets";
            readonly functionName: "viewKitchenTickets";
            readonly inputTypeName: "ViewKitchenTicketsInput";
            readonly outputTypeName: "ViewKitchenTicketsOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly transactional: false;
            readonly steps: readonly ["Read KitchenTickets filtered by status/date via repository", "Return list of tickets with associated order references"];
        };
    };
    export default viewKitchenTicketsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewKitchenTickets__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewOperationalDashboard";
            readonly functionName: "viewOperationalDashboard";
            readonly inputTypeName: "ViewOperationalDashboardInput";
            readonly outputTypeName: "ViewOperationalDashboardOutput";
            readonly ports: readonly ["DailyShift", "Order", "Payment"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read current DailyShift via DailyShift port", "Read active Orders for the shift via Order port", "Read Payments for the shift via Payment port", "Read CashMovements for the shift", "Apply paymentTimingByOrderType rule to categorize revenue", "Apply aiOutputLanguageSelection rule for dashboard labels", "Compute real-time metrics: open orders, revenue, kitchen load", "Return dashboard data structure"];
        };
    };
    export default viewOperationalDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs" {
    export const dailyShiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly fields: readonly [{
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno diário.";
            }, {
                readonly fieldId: "shiftDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Data operacional do turno.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado atual do turno.";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de abertura do turno.";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora de fechamento do turno.";
            }, {
                readonly fieldId: "openingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor inicial em caixa ao abrir o turno.";
            }, {
                readonly fieldId: "closingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor final em caixa ao fechar o turno.";
            }, {
                readonly fieldId: "totalSales";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de vendas no turno.";
            }, {
                readonly fieldId: "totalPayments";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de pagamentos recebidos no turno.";
            }, {
                readonly fieldId: "closingNotes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações e relatório de fechamento do turno.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly invariants: readonly ["only one DailyShift can be open at a time", "status can only transition from open to closed", "closedAt must be set when status is closed", "closedAt must be after openedAt", "cannot add Orders or CashMovements to a closed DailyShift", "closingCashBalance must be set when status is closed", "totalSales must equal the sum of all closed Order.totalAmount for this shift", "totalPayments must equal the sum of all captured Payment.amount for this shift", "openingCashBalance must be greater than or equal to zero"];
            readonly valueObjects: readonly [{
                readonly name: "CashMovement";
                readonly fields: readonly [{
                    readonly fieldId: "cashMovementId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do movimento de caixa";
                }, {
                    readonly fieldId: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao turno (DailyShift) ao qual o movimento pertence";
                }, {
                    readonly fieldId: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo do movimento: entrada ou saída de caixa";
                    readonly enum: readonly ["entrada", "saída"];
                }, {
                    readonly fieldId: "amount";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Valor do movimento";
                }, {
                    readonly fieldId: "reason";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Motivo do movimento (ex.: sangria, reforço, estorno)";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default dailyShiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "dailyShift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs" {
    export const inventoryItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly fields: readonly [{
                readonly fieldId: "inventoryItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item de estoque";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do ingrediente ou insumo";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida (ex.: kg, L, unidade, gramas)";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual disponível em estoque";
            }, {
                readonly fieldId: "minimumLevel";
                readonly type: "number";
                readonly required: true;
                readonly description: "Nível mínimo para geração de alerta de baixo estoque";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["active", "inactive"];
            readonly invariants: readonly ["currentQuantity must not be negative", "minimumLevel must be greater than or equal to zero", "name must not be empty", "unit must not be empty", "status can only transition between active and inactive", "an inactive InventoryItem cannot be used in new RecipeComponents"];
            readonly valueObjects: readonly [];
        };
    };
    export default inventoryItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs" {
    export const menuItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly fields: readonly [{
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item do cardápio";
            }, {
                readonly fieldId: "menuCategoryId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à categoria do cardápio à qual o item pertence";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do item (ex.: cappuccino, pão de queijo)";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "price";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço de venda do item";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["draft", "active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "active", "inactive"];
            readonly invariants: readonly ["price must be greater than zero", "name must not be empty", "status can only transition from draft to active, active to inactive, and inactive to active", "cannot delete a MenuItem that is referenced by active Orders"];
            readonly valueObjects: readonly [{
                readonly name: "RecipeComponent";
                readonly fields: readonly [{
                    readonly fieldId: "recipeComponentId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do componente de receita";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de menu ao qual este componente pertence";
                }, {
                    readonly fieldId: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de inventário utilizado como ingrediente";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade consumida do item de inventário por unidade vendida do menu item";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default menuItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "menuItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Turno diário em que o pedido foi registrado";
            }, {
                readonly fieldId: "tableId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência à mesa associada (para pedidos do tipo mesa)";
            }, {
                readonly fieldId: "kitchenTicketId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Ticket de cozinha gerado para fila de preparo";
            }, {
                readonly fieldId: "orderType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do pedido: mesa ou takeout";
                readonly enum: readonly ["mesa", "takeout"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido na coordenação com a cozinha";
                readonly enum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            }, {
                readonly fieldId: "totalAmount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total do pedido com preços no momento da venda";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações gerais do pedido";
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: false;
                readonly description: "Nome do cliente para identificação do pedido";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do cliente";
            }, {
                readonly fieldId: "numberOfGuests";
                readonly type: "number";
                readonly required: false;
                readonly description: "Número de pessoas na mesa";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do fechamento do pedido";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do cancelamento do pedido";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            readonly invariants: readonly ["totalAmount must equal the sum of all OrderItem.totalPrice", "when orderType is mesa, tableId is required", "when orderType is takeout, tableId must be null", "status transitions must follow: draft -> sentToKitchen -> inPreparation -> ready -> served -> closed; any state can go to cancelled", "closedAt must be set when status is closed", "cancelledAt and cancellationReason must be set when status is cancelled", "cannot modify OrderItems after status is sentToKitchen", "dailyShift must be open when Order is created", "numberOfGuests must be greater than zero when provided"];
            readonly valueObjects: readonly [{
                readonly name: "OrderItem";
                readonly fields: readonly [{
                    readonly fieldId: "id";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do pedido";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido (Order) ao qual este item pertence";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio (MenuItem) solicitado";
                }, {
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly description: "Referência ao ticket de cozinha (KitchenTicket) quando o item exige preparo";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade solicitada do item";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do item no momento do pedido";
                }, {
                    readonly fieldId: "totalPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço total do item (quantidade × preço unitário)";
                }, {
                    readonly fieldId: "observations";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações ou instruções especiais para o item";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status de produção/atendimento do item";
                    readonly enum: readonly ["new", "sentToKitchen", "inPreparation", "ready", "served", "cancelled"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }, {
                readonly name: "KitchenTicket";
                readonly fields: readonly [{
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do ticket de cozinha";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido que gerou este ticket para a fila de preparo";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual do ticket na fila de preparo da cozinha";
                    readonly enum: readonly ["open", "inProgress", "done", "void"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do ticket";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do ticket";
                }];
                readonly collection: true;
            }];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs" {
    export const paymentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly fields: readonly [{
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pagamento.";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao pedido associado ao pagamento, quando aplicável.";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao turno diário de fechamento ao qual o pagamento será consolidado.";
            }, {
                readonly fieldId: "method";
                readonly type: "string";
                readonly required: true;
                readonly description: "Método de pagamento utilizado (ex.: dinheiro, cartão de crédito, PIX).";
            }, {
                readonly fieldId: "amount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor recebido/pago.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do pagamento no ciclo de vida.";
                readonly enum: readonly ["authorized", "captured", "voided", "refunded"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["authorized", "captured", "voided", "refunded"];
            readonly invariants: readonly ["amount must be greater than zero", "method must not be empty", "status transitions must follow: authorized -> captured; authorized -> voided; captured -> refunded", "dailyShiftId must reference an open DailyShift when Payment is created", "a voided or refunded Payment cannot change status", "orderId and dailyShiftId cannot both be null"];
            readonly valueObjects: readonly [];
        };
    };
    export default paymentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "payment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageTables.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        action?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        action?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        action?: undefined;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageTables.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/shared/recordPayment.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "aiPromotionSuggestions.section.title": string;
            "aiPromotionSuggestions.organism.title": string;
            "aiPromotionSuggestions.intent.query.title": string;
            "aiPromotionSuggestions.field.id": string;
            "aiPromotionSuggestions.field.orderId": string;
            "aiPromotionSuggestions.field.menuItemId": string;
            "aiPromotionSuggestions.field.kitchenTicketId": string;
            "aiPromotionSuggestions.field.quantity": string;
            "aiPromotionSuggestions.field.unitPrice": string;
            "aiPromotionSuggestions.field.totalPrice": string;
            "aiPromotionSuggestions.field.observations": string;
            "aiPromotionSuggestions.filter.id": string;
            "aiPromotionSuggestions.filter.orderId": string;
            "aiPromotionSuggestions.filter.menuItemId": string;
            "aiPromotionSuggestions.filter.kitchenTicketId": string;
            "aiPromotionSuggestions.filter.status": string;
            "aiPromotionSuggestions.filter.createdAt": string;
            "aiPromotionSuggestions.action.run": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "aiSalesSummary.section.title": string;
            "aiSalesSummary.organism.title": string;
            "aiSalesSummary.form.title": string;
            "aiSalesSummary.results.title": string;
            "aiSalesSummary.field.dailyShiftId": string;
            "aiSalesSummary.field.status": string;
            "aiSalesSummary.field.closedAt": string;
            "aiSalesSummary.action.run": string;
            "aiSalesSummary.col.dailyShiftId": string;
            "aiSalesSummary.col.status": string;
            "aiSalesSummary.col.totalAmount": string;
            "aiSalesSummary.col.closedAt": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "page.title": string;
            "section.menu.title": string;
            "organism.menu.title": string;
            "intent.menu.query.title": string;
            "filter.menuItemId.label": string;
            "filter.menuCategoryId.label": string;
            "filter.name.label": string;
            "filter.status.label": string;
            "filter.createdAt.label": string;
            "filter.updatedAt.label": string;
            "column.menuItemId.label": string;
            "column.menuCategoryId.label": string;
            "column.name.label": string;
            "column.description.label": string;
            "column.price.label": string;
            "column.status.label": string;
            "column.createdAt.label": string;
            "column.updatedAt.label": string;
            "action.browseMenuForPos.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "closeDailyShift.section.main.title": string;
            "closeDailyShift.organism.updateDailyShiftStatus.title": string;
            "closeDailyShift.organism.recordClosingCashMovement.title": string;
            "closeDailyShift.intent.updateDailyShiftStatus.title": string;
            "closeDailyShift.intent.recordClosingCashMovement.title": string;
            "closeDailyShift.field.dailyShiftId": string;
            "closeDailyShift.field.shiftDate": string;
            "closeDailyShift.field.status": string;
            "closeDailyShift.field.openedAt": string;
            "closeDailyShift.field.closedAt": string;
            "closeDailyShift.field.openingCashBalance": string;
            "closeDailyShift.field.closingCashBalance": string;
            "closeDailyShift.field.totalSales": string;
            "closeDailyShift.field.totalPayments": string;
            "closeDailyShift.field.closingNotes": string;
            "closeDailyShift.action.updateDailyShiftStatus": string;
            "closeDailyShift.action.recordClosingCashMovement": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "consumeIngredientsOnConfirmation.section.main.title": string;
            "consumeIngredientsOnConfirmation.organism.createStockConsumption.title": string;
            "consumeIngredientsOnConfirmation.intention.createStockConsumption.title": string;
            "consumeIngredientsOnConfirmation.field.quantity.label": string;
            "consumeIngredientsOnConfirmation.field.status.label": string;
            "consumeIngredientsOnConfirmation.field.consumedAt.label": string;
            "consumeIngredientsOnConfirmation.action.createStockConsumption.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "section.dineInOrderLifecycle.title": string;
            "organism.createOrder.title": string;
            "organism.addOrderItem.title": string;
            "organism.createKitchenTicket.title": string;
            "organism.updateOrderStatus.title": string;
            "organism.updateTableStatus.title": string;
            "intention.createOrder.form.title": string;
            "intention.addOrderItem.form.title": string;
            "intention.createKitchenTicket.form.title": string;
            "intention.updateOrderStatus.form.title": string;
            "intention.updateTableStatus.form.title": string;
            "field.orderType.label": string;
            "field.status.label": string;
            "field.totalAmount.label": string;
            "field.notes.label": string;
            "field.customerName.label": string;
            "field.customerPhone.label": string;
            "field.numberOfGuests.label": string;
            "field.closedAt.label": string;
            "field.cancelledAt.label": string;
            "field.cancellationReason.label": string;
            "field.quantity.label": string;
            "field.unitPrice.label": string;
            "field.totalPrice.label": string;
            "field.observations.label": string;
            "field.kitchenTicketStatus.label": string;
            "field.tableStatus.label": string;
            "action.createOrder.label": string;
            "action.addOrderItem.label": string;
            "action.createKitchenTicket.label": string;
            "action.updateOrderStatus.label": string;
            "action.updateTableStatus.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "section.generateShiftCloseReport.title": string;
            "organism.generateShiftCloseReport.title": string;
            "intention.shiftCloseReport.filters.title": string;
            "intention.shiftCloseReport.filters.empty": string;
            "intention.shiftCloseReport.summary.title": string;
            "intention.shiftCloseReport.summary.empty": string;
            "field.status.label": string;
            "field.openedAt.label": string;
            "field.closedAt.label": string;
            "field.openingCashBalance.label": string;
            "field.closingCashBalance.label": string;
            "field.totalSales.label": string;
            "field.totalPayments.label": string;
            "field.closingNotes.label": string;
            "action.generateShiftCloseReport.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "kitchenProductionFlow.section.main.title": string;
            "kitchenProductionFlow.organism.viewKitchenTickets.title": string;
            "kitchenProductionFlow.intention.viewKitchenTickets.list.title": string;
            "kitchenProductionFlow.field.kitchenTicketId": string;
            "kitchenProductionFlow.field.orderId": string;
            "kitchenProductionFlow.field.status": string;
            "kitchenProductionFlow.field.createdAt": string;
            "kitchenProductionFlow.field.updatedAt": string;
            "kitchenProductionFlow.action.viewKitchenTickets": string;
            "kitchenProductionFlow.organism.updateKitchenTicketStatus.title": string;
            "kitchenProductionFlow.intention.updateKitchenTicketStatus.form.title": string;
            "kitchenProductionFlow.action.updateKitchenTicketStatus": string;
            "kitchenProductionFlow.organism.updateOrderItemStatus.title": string;
            "kitchenProductionFlow.intention.updateOrderItemStatus.form.title": string;
            "kitchenProductionFlow.field.orderItem.status": string;
            "kitchenProductionFlow.action.updateOrderItemStatus": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageInventoryItems.section.main.title": string;
            "manageInventoryItems.organism.form.title": string;
            "manageInventoryItems.intention.commandForm.title": string;
            "manageInventoryItems.field.name.label": string;
            "manageInventoryItems.field.description.label": string;
            "manageInventoryItems.field.unit.label": string;
            "manageInventoryItems.field.currentQuantity.label": string;
            "manageInventoryItems.field.minimumLevel.label": string;
            "manageInventoryItems.field.status.label": string;
            "manageInventoryItems.action.submit.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "page.manageMenuCategories.title": string;
            "section.manageMenuCategories.title": string;
            "organism.manageMenuCategories.title": string;
            "intention.manageMenuCategories.form.title": string;
            "field.menuCategoryId.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.status.label": string;
            "action.manageMenuCategories.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageMenuItems.section.title": string;
            "manageMenuItems.organism.title": string;
            "manageMenuItems.list.title": string;
            "manageMenuItems.field.menuItemId": string;
            "manageMenuItems.field.name": string;
            "manageMenuItems.field.menuCategoryId": string;
            "manageMenuItems.field.price": string;
            "manageMenuItems.field.status": string;
            "manageMenuItems.filter.name": string;
            "manageMenuItems.filter.menuCategoryId": string;
            "manageMenuItems.filter.status": string;
            "manageMenuItems.form.title": string;
            "manageMenuItems.field.description": string;
            "manageMenuItems.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageTables.section.title": string;
            "manageTables.organism.title": string;
            "manageTables.form.title": string;
            "manageTables.field.tableId": string;
            "manageTables.field.number": string;
            "manageTables.field.status": string;
            "manageTables.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "openDailyShift.section.openDailyShift.title": string;
            "openDailyShift.organism.createDailyShift.title": string;
            "openDailyShift.organism.recordOpeningCashMovement.title": string;
            "openDailyShift.intention.createDailyShiftForm.title": string;
            "openDailyShift.intention.recordOpeningCashMovementForm.title": string;
            "openDailyShift.field.shiftDate.label": string;
            "openDailyShift.field.status.label": string;
            "openDailyShift.field.openedAt.label": string;
            "openDailyShift.field.openingCashBalance.label": string;
            "openDailyShift.field.movementType.label": string;
            "openDailyShift.field.amount.label": string;
            "openDailyShift.field.reason.label": string;
            "openDailyShift.action.createDailyShift.label": string;
            "openDailyShift.action.recordOpeningCashMovement.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts", "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "recordPayment.page.title": string;
            "recordPayment.section.title": string;
            "recordPayment.organism.title": string;
            "recordPayment.order.summary.title": string;
            "recordPayment.order.field.orderId": string;
            "recordPayment.order.field.orderType": string;
            "recordPayment.order.field.status": string;
            "recordPayment.order.field.totalAmount": string;
            "recordPayment.order.field.tableId": string;
            "recordPayment.order.field.customerName": string;
            "recordPayment.payment.form.title": string;
            "recordPayment.payment.field.method": string;
            "recordPayment.payment.field.amount": string;
            "recordPayment.payment.field.status": string;
            "recordPayment.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts", "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "takeoutOrderLifecycle.section.title": string;
            "takeoutOrderLifecycle.createOrder.title": string;
            "takeoutOrderLifecycle.createOrder.form.title": string;
            "takeoutOrderLifecycle.createOrder.field.orderType": string;
            "takeoutOrderLifecycle.createOrder.field.status": string;
            "takeoutOrderLifecycle.createOrder.field.totalAmount": string;
            "takeoutOrderLifecycle.createOrder.field.notes": string;
            "takeoutOrderLifecycle.createOrder.field.customerName": string;
            "takeoutOrderLifecycle.createOrder.field.customerPhone": string;
            "takeoutOrderLifecycle.createOrder.field.numberOfGuests": string;
            "takeoutOrderLifecycle.createOrder.field.closedAt": string;
            "takeoutOrderLifecycle.createOrder.field.cancelledAt": string;
            "takeoutOrderLifecycle.createOrder.field.cancellationReason": string;
            "takeoutOrderLifecycle.createOrder.action.submit": string;
            "takeoutOrderLifecycle.addOrderItem.title": string;
            "takeoutOrderLifecycle.addOrderItem.form.title": string;
            "takeoutOrderLifecycle.addOrderItem.field.quantity": string;
            "takeoutOrderLifecycle.addOrderItem.field.unitPrice": string;
            "takeoutOrderLifecycle.addOrderItem.field.totalPrice": string;
            "takeoutOrderLifecycle.addOrderItem.field.observations": string;
            "takeoutOrderLifecycle.addOrderItem.field.status": string;
            "takeoutOrderLifecycle.addOrderItem.action.submit": string;
            "takeoutOrderLifecycle.createKitchenTicket.title": string;
            "takeoutOrderLifecycle.createKitchenTicket.form.title": string;
            "takeoutOrderLifecycle.createKitchenTicket.field.status": string;
            "takeoutOrderLifecycle.createKitchenTicket.action.submit": string;
            "takeoutOrderLifecycle.updateOrderStatus.title": string;
            "takeoutOrderLifecycle.updateOrderStatus.form.title": string;
            "takeoutOrderLifecycle.updateOrderStatus.field.status": string;
            "takeoutOrderLifecycle.updateOrderStatus.field.closedAt": string;
            "takeoutOrderLifecycle.updateOrderStatus.field.cancelledAt": string;
            "takeoutOrderLifecycle.updateOrderStatus.field.cancellationReason": string;
            "takeoutOrderLifecycle.updateOrderStatus.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "viewOperationalDashboard.section.dashboard.title": string;
            "viewOperationalDashboard.organism.dashboard.title": string;
            "viewOperationalDashboard.intention.query.title": string;
            "viewOperationalDashboard.field.dailyShiftId.label": string;
            "viewOperationalDashboard.field.shiftDate.label": string;
            "viewOperationalDashboard.field.status.label": string;
            "viewOperationalDashboard.field.openedAt.label": string;
            "viewOperationalDashboard.field.closedAt.label": string;
            "viewOperationalDashboard.field.createdAt.label": string;
            "viewOperationalDashboard.col.dailyShiftId.label": string;
            "viewOperationalDashboard.col.shiftDate.label": string;
            "viewOperationalDashboard.col.status.label": string;
            "viewOperationalDashboard.col.openedAt.label": string;
            "viewOperationalDashboard.col.closedAt.label": string;
            "viewOperationalDashboard.col.openingCashBalance.label": string;
            "viewOperationalDashboard.col.closingCashBalance.label": string;
            "viewOperationalDashboard.col.totalSales.label": string;
            "viewOperationalDashboard.filter.dailyShiftId.label": string;
            "viewOperationalDashboard.filter.shiftDate.label": string;
            "viewOperationalDashboard.filter.status.label": string;
            "viewOperationalDashboard.filter.openedAt.label": string;
            "viewOperationalDashboard.filter.closedAt.label": string;
            "viewOperationalDashboard.filter.createdAt.label": string;
            "viewOperationalDashboard.action.viewOperationalDashboard.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
