declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/addOrderItem.defs" {
    export const addOrderItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "addOrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "addOrderItem";
            readonly controllerName: "AddOrderItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAddOrderItemHandler";
                readonly command: "addOrderItem";
                readonly usecaseRef: "addOrderItem";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.addOrderItem.addOrderItem";
                readonly handlerName: "cafeFlowAddOrderItemHandler";
            }];
        };
    };
    export default addOrderItemController;
    export const pipeline: readonly [{
        readonly id: "addOrderItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/addOrderItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/addOrderItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiPromotionSuggestions";
            readonly controllerName: "AiPromotionSuggestionsController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAiPromotionSuggestionsHandler";
                readonly command: "aiPromotionSuggestions";
                readonly usecaseRef: "aiPromotionSuggestions";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.aiPromotionSuggestions.aiPromotionSuggestions";
                readonly handlerName: "cafeFlowAiPromotionSuggestionsHandler";
            }];
        };
    };
    export default aiPromotionSuggestionsController;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.d.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs" {
    export const aiSalesSummaryController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiSalesSummary";
            readonly controllerName: "AiSalesSummaryController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAiSalesSummaryHandler";
                readonly command: "aiSalesSummary";
                readonly usecaseRef: "aiSalesSummary";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.aiSalesSummary.aiSalesSummary";
                readonly handlerName: "cafeFlowAiSalesSummaryHandler";
            }];
        };
    };
    export default aiSalesSummaryController;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.d.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs" {
    export const browseMenuForPosController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseMenuForPos";
            readonly controllerName: "BrowseMenuForPosController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowBrowseMenuForPosHandler";
                readonly command: "browseMenuForPos";
                readonly usecaseRef: "browseMenuForPos";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.browseMenuForPos.browseMenuForPos";
                readonly handlerName: "cafeFlowBrowseMenuForPosHandler";
            }];
        };
    };
    export default browseMenuForPosController;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.d.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs" {
    export const closeDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "closeDailyShift";
            readonly controllerName: "CloseDailyShiftController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCloseDailyShiftHandler";
                readonly command: "closeDailyShift";
                readonly usecaseRef: "closeDailyShift";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.closeDailyShift.closeDailyShift";
                readonly handlerName: "cafeFlowCloseDailyShiftHandler";
            }];
        };
    };
    export default closeDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.d.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "consumeIngredientsOnConfirmation";
            readonly controllerName: "ConsumeIngredientsOnConfirmationController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowConsumeIngredientsOnConfirmationHandler";
                readonly command: "consumeIngredientsOnConfirmation";
                readonly usecaseRef: "consumeIngredientsOnConfirmation";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.consumeIngredientsOnConfirmation.consumeIngredientsOnConfirmation";
                readonly handlerName: "cafeFlowConsumeIngredientsOnConfirmationHandler";
            }];
        };
    };
    export default consumeIngredientsOnConfirmationController;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.d.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createDailyShift.defs" {
    export const createDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createDailyShift";
            readonly controllerName: "CreateDailyShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateDailyShiftHandler";
                readonly command: "createDailyShift";
                readonly usecaseRef: "createDailyShift";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createDailyShift.createDailyShift";
                readonly handlerName: "cafeFlowCreateDailyShiftHandler";
            }];
        };
    };
    export default createDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "createDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createKitchenTicket.defs" {
    export const createKitchenTicketController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createKitchenTicket";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createKitchenTicket";
            readonly controllerName: "CreateKitchenTicketController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateKitchenTicketHandler";
                readonly command: "createKitchenTicket";
                readonly usecaseRef: "createKitchenTicket";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createKitchenTicket.createKitchenTicket";
                readonly handlerName: "cafeFlowCreateKitchenTicketHandler";
            }];
        };
    };
    export default createKitchenTicketController;
    export const pipeline: readonly [{
        readonly id: "createKitchenTicket__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createKitchenTicket.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createKitchenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs" {
    export const createOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createOrder";
            readonly controllerName: "CreateOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateOrderHandler";
                readonly command: "createOrder";
                readonly usecaseRef: "createOrder";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createOrder.createOrder";
                readonly handlerName: "cafeFlowCreateOrderHandler";
            }];
        };
    };
    export default createOrderController;
    export const pipeline: readonly [{
        readonly id: "createOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockConsumption.defs" {
    export const createStockConsumptionController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createStockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createStockConsumption";
            readonly controllerName: "CreateStockConsumptionController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateStockConsumptionHandler";
                readonly command: "createStockConsumption";
                readonly usecaseRef: "createStockConsumption";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createStockConsumption.createStockConsumption";
                readonly handlerName: "cafeFlowCreateStockConsumptionHandler";
            }];
        };
    };
    export default createStockConsumptionController;
    export const pipeline: readonly [{
        readonly id: "createStockConsumption__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockConsumption.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "dineInOrderLifecycle";
            readonly controllerName: "DineInOrderLifecycleController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDineInOrderLifecycleHandler";
                readonly command: "dineInOrderLifecycle";
                readonly usecaseRef: "dineInOrderLifecycle";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.dineInOrderLifecycle.dineInOrderLifecycle";
                readonly handlerName: "cafeFlowDineInOrderLifecycleHandler";
            }];
        };
    };
    export default dineInOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.d.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "generateShiftCloseReport";
            readonly controllerName: "GenerateShiftCloseReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowGenerateShiftCloseReportHandler";
                readonly command: "generateShiftCloseReport";
                readonly usecaseRef: "generateShiftCloseReport";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.generateShiftCloseReport.generateShiftCloseReport";
                readonly handlerName: "cafeFlowGenerateShiftCloseReportHandler";
            }];
        };
    };
    export default generateShiftCloseReportController;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.d.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "kitchenProductionFlow";
            readonly controllerName: "KitchenProductionFlowController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowKitchenProductionFlowHandler";
                readonly command: "kitchenProductionFlow";
                readonly usecaseRef: "kitchenProductionFlow";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.kitchenProductionFlow.kitchenProductionFlow";
                readonly handlerName: "cafeFlowKitchenProductionFlowHandler";
            }];
        };
    };
    export default kitchenProductionFlowController;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.d.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs" {
    export const manageInventoryItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageInventoryItems";
            readonly controllerName: "ManageInventoryItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageInventoryItemsHandler";
                readonly command: "manageInventoryItems";
                readonly usecaseRef: "manageInventoryItems";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageInventoryItems.manageInventoryItems";
                readonly handlerName: "cafeFlowManageInventoryItemsHandler";
            }];
        };
    };
    export default manageInventoryItemsController;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.d.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs" {
    export const manageMenuCategoriesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuCategories";
            readonly controllerName: "ManageMenuCategoriesController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageMenuCategoriesHandler";
                readonly command: "manageMenuCategories";
                readonly usecaseRef: "manageMenuCategories";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageMenuCategories.manageMenuCategories";
                readonly handlerName: "cafeFlowManageMenuCategoriesHandler";
            }];
        };
    };
    export default manageMenuCategoriesController;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.d.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs" {
    export const manageMenuItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuItems";
            readonly controllerName: "ManageMenuItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageMenuItemsHandler";
                readonly command: "manageMenuItems";
                readonly usecaseRef: "manageMenuItems";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageMenuItems.manageMenuItems";
                readonly handlerName: "cafeFlowManageMenuItemsHandler";
            }];
        };
    };
    export default manageMenuItemsController;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.d.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs" {
    export const manageTablesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageTables";
            readonly controllerName: "ManageTablesController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageTablesHandler";
                readonly command: "manageTables";
                readonly usecaseRef: "manageTables";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageTables.manageTables";
                readonly handlerName: "cafeFlowManageTablesHandler";
            }];
        };
    };
    export default manageTablesController;
    export const pipeline: readonly [{
        readonly id: "manageTables__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.d.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs" {
    export const openDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "openDailyShift";
            readonly controllerName: "OpenDailyShiftController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowOpenDailyShiftHandler";
                readonly command: "openDailyShift";
                readonly usecaseRef: "openDailyShift";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.openDailyShift.openDailyShift";
                readonly handlerName: "cafeFlowOpenDailyShiftHandler";
            }];
        };
    };
    export default openDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.d.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordOpeningCashMovement.defs" {
    export const recordOpeningCashMovementController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "recordOpeningCashMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "recordOpeningCashMovement";
            readonly controllerName: "RecordOpeningCashMovementController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRecordOpeningCashMovementHandler";
                readonly command: "recordOpeningCashMovement";
                readonly usecaseRef: "recordOpeningCashMovement";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.recordOpeningCashMovement.recordOpeningCashMovement";
                readonly handlerName: "cafeFlowRecordOpeningCashMovementHandler";
            }];
        };
    };
    export default recordOpeningCashMovementController;
    export const pipeline: readonly [{
        readonly id: "recordOpeningCashMovement__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordOpeningCashMovement.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordOpeningCashMovement.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs" {
    export const recordPaymentController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "recordPayment";
            readonly controllerName: "RecordPaymentController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRecordPaymentHandler";
                readonly command: "recordPayment";
                readonly usecaseRef: "recordPayment";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.recordPayment.recordPayment";
                readonly handlerName: "cafeFlowRecordPaymentHandler";
            }];
        };
    };
    export default recordPaymentController;
    export const pipeline: readonly [{
        readonly id: "recordPayment__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.d.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "takeoutOrderLifecycle";
            readonly controllerName: "TakeoutOrderLifecycleController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowTakeoutOrderLifecycleHandler";
                readonly command: "takeoutOrderLifecycle";
                readonly usecaseRef: "takeoutOrderLifecycle";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.takeoutOrderLifecycle.takeoutOrderLifecycle";
                readonly handlerName: "cafeFlowTakeoutOrderLifecycleHandler";
            }];
        };
    };
    export default takeoutOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.d.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenTicketStatus.defs" {
    export const updateKitchenTicketStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateKitchenTicketStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateKitchenTicketStatus";
            readonly controllerName: "UpdateKitchenTicketStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateKitchenTicketStatusHandler";
                readonly command: "updateKitchenTicketStatus";
                readonly usecaseRef: "updateKitchenTicketStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateKitchenTicketStatus.updateKitchenTicketStatus";
                readonly handlerName: "cafeFlowUpdateKitchenTicketStatusHandler";
            }];
        };
    };
    export default updateKitchenTicketStatusController;
    export const pipeline: readonly [{
        readonly id: "updateKitchenTicketStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenTicketStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenTicketStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderItemStatus.defs" {
    export const updateOrderItemStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderItemStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateOrderItemStatus";
            readonly controllerName: "UpdateOrderItemStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderItemStatusHandler";
                readonly command: "updateOrderItemStatus";
                readonly usecaseRef: "updateOrderItemStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateOrderItemStatus.updateOrderItemStatus";
                readonly handlerName: "cafeFlowUpdateOrderItemStatusHandler";
            }];
        };
    };
    export default updateOrderItemStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderItemStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderItemStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderItemStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs" {
    export const updateOrderStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateOrderStatus";
            readonly controllerName: "UpdateOrderStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
                readonly command: "updateOrderStatus";
                readonly usecaseRef: "updateOrderStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateOrderStatus.updateOrderStatus";
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
            }];
        };
    };
    export default updateOrderStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTableStatus.defs" {
    export const updateTableStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateTableStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateTableStatus";
            readonly controllerName: "UpdateTableStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateTableStatusHandler";
                readonly command: "updateTableStatus";
                readonly usecaseRef: "updateTableStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateTableStatus.updateTableStatus";
                readonly handlerName: "cafeFlowUpdateTableStatusHandler";
            }];
        };
    };
    export default updateTableStatusController;
    export const pipeline: readonly [{
        readonly id: "updateTableStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTableStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTableStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenTickets.defs" {
    export const viewKitchenTicketsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewKitchenTickets";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewKitchenTickets";
            readonly controllerName: "ViewKitchenTicketsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewKitchenTicketsHandler";
                readonly command: "viewKitchenTickets";
                readonly usecaseRef: "viewKitchenTickets";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.viewKitchenTickets.viewKitchenTickets";
                readonly handlerName: "cafeFlowViewKitchenTicketsHandler";
            }];
        };
    };
    export default viewKitchenTicketsController;
    export const pipeline: readonly [{
        readonly id: "viewKitchenTickets__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenTickets.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenTickets.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewOperationalDashboard";
            readonly controllerName: "ViewOperationalDashboardController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewOperationalDashboardHandler";
                readonly command: "viewOperationalDashboard";
                readonly usecaseRef: "viewOperationalDashboard";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.viewOperationalDashboard.viewOperationalDashboard";
                readonly handlerName: "cafeFlowViewOperationalDashboardHandler";
            }];
        };
    };
    export default viewOperationalDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.d.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "DailyShift";
            readonly tableName: "daily_shift";
            readonly columns: readonly [{
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for daily shift";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the daily shift";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains shiftDate, openedAt, closedAt, openingCashBalance, closingCashBalance, totalSales, totalPayments, closingNotes, updatedAt and child collection CashMovement";
            }];
            readonly primaryKey: readonly ["daily_shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_daily_shift_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_daily_shift_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["CashMovement"];
            };
        };
    };
    export default dailyShiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "dailyShift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs" {
    export const dailyShiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "DailyShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "DailyShiftRepository";
            readonly entityId: "DailyShift";
            readonly portRef: "IDailyShiftRepository";
            readonly tableRef: "daily_shifts";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Columns: daily_shift_id, status, created_at. Details JSONB: shiftDate, openedAt, closedAt, openingCashBalance, closingCashBalance, totalSales, totalPayments, closingNotes, updatedAt, cashMovements. No MDM refs."];
        };
    };
    export default dailyShiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs" {
    export const inventoryItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "InventoryItem";
            readonly tableName: "inventory_item";
            readonly columns: readonly [{
                readonly name: "inventory_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for inventory item";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the inventory item";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains name, description, unit, currentQuantity, minimumLevel, updatedAt";
            }];
            readonly primaryKey: readonly ["inventory_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_inventory_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_inventory_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default inventoryItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs" {
    export const inventoryItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "InventoryItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "InventoryItemRepository";
            readonly entityId: "InventoryItem";
            readonly portRef: "IInventoryItemRepository";
            readonly tableRef: "inventory_items";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Columns: inventory_item_id, status, created_at. Details JSONB: name, description, unit, currentQuantity, minimumLevel, updatedAt. No MDM refs."];
        };
    };
    export default inventoryItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs" {
    export const menuItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "MenuItem";
            readonly tableName: "menu_item";
            readonly columns: readonly [{
                readonly name: "menu_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for menu item";
            }, {
                readonly name: "menu_category_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to menu category";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the menu item";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains name, description, price, updatedAt and child collection RecipeComponent";
            }];
            readonly primaryKey: readonly ["menu_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_menu_item_menu_category_id";
                readonly columns: readonly ["menu_category_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["RecipeComponent"];
            };
        };
    };
    export default menuItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "menuItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs" {
    export const menuItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MenuItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "MenuItemRepository";
            readonly entityId: "MenuItem";
            readonly portRef: "IMenuItemRepository";
            readonly tableRef: "menu_items";
            readonly mdmReads: readonly ["MenuCategory"];
            readonly notes: readonly ["Columns: menu_item_id, menu_category_id, status, created_at. Details JSONB: name, description, price, updatedAt, recipeComponents. MDM ref MenuCategory resolved through 102034."];
        };
    };
    export default menuItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "menuItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for order";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to daily shift";
            }, {
                readonly name: "table_id";
                readonly type: "uuid";
                readonly nullable: true;
                readonly description: "FK to table (nullable for non-dine-in orders)";
            }, {
                readonly name: "kitchen_ticket_id";
                readonly type: "uuid";
                readonly nullable: true;
                readonly description: "FK to kitchen ticket";
            }, {
                readonly name: "order_type";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Order type (dine-in, takeaway, delivery, etc.)";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the order";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains totalAmount, notes, customerName, customerPhone, numberOfGuests, closedAt, cancelledAt, cancellationReason, updatedAt and child collections OrderItem, KitchenTicket";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_table_id";
                readonly columns: readonly ["table_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_kitchen_ticket_id";
                readonly columns: readonly ["kitchen_ticket_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_order_type";
                readonly columns: readonly ["order_type"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["OrderItem", "KitchenTicket"];
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepository";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly ["Table"];
            readonly notes: readonly ["Columns: order_id, daily_shift_id, table_id, kitchen_ticket_id, order_type, status, created_at. Details JSONB: totalAmount, notes, customerName, customerPhone, numberOfGuests, closedAt, cancelledAt, cancellationReason, updatedAt, orderItems, kitchenTicket. MDM ref Table resolved through 102034."];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs" {
    export const paymentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Payment";
            readonly tableName: "payment";
            readonly columns: readonly [{
                readonly name: "payment_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for payment";
            }, {
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to order";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to daily shift";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the payment";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains method, amount, updatedAt";
            }];
            readonly primaryKey: readonly ["payment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_payment_order_id";
                readonly columns: readonly ["order_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default paymentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "payment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs" {
    export const paymentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "PaymentRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "PaymentRepository";
            readonly entityId: "Payment";
            readonly portRef: "IPaymentRepository";
            readonly tableRef: "payments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Columns: payment_id, order_id, daily_shift_id, status, created_at. Details JSONB: method, amount, updatedAt. No MDM refs."];
        };
    };
    export default paymentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "paymentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs" {
    export const dailyShiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "DailyShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly interfaceName: "IDailyShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "DailyShift | null";
                readonly params: readonly ["dailyShiftId: DailyShiftId"];
            }, {
                readonly name: "list";
                readonly returns: "DailyShift[]";
                readonly params: readonly ["filter: DailyShiftFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["dailyShift: DailyShift"];
            }, {
                readonly name: "findByDate";
                readonly returns: "DailyShift | null";
                readonly params: readonly ["businessDate: BusinessDate"];
            }, {
                readonly name: "findOpenShift";
                readonly returns: "DailyShift | null";
                readonly params: readonly [];
            }, {
                readonly name: "findByCashier";
                readonly returns: "DailyShift[]";
                readonly params: readonly ["cashierId: EmployeeId"];
            }];
        };
    };
    export default dailyShiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs" {
    export const inventoryItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "InventoryItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly interfaceName: "IInventoryItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "InventoryItem | null";
                readonly params: readonly ["inventoryItemId: InventoryItemId"];
            }, {
                readonly name: "list";
                readonly returns: "InventoryItem[]";
                readonly params: readonly ["filter: InventoryItemFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["inventoryItem: InventoryItem"];
            }, {
                readonly name: "findBySku";
                readonly returns: "InventoryItem | null";
                readonly params: readonly ["sku: Sku"];
            }, {
                readonly name: "findLowStock";
                readonly returns: "InventoryItem[]";
                readonly params: readonly [];
            }, {
                readonly name: "findBySupplier";
                readonly returns: "InventoryItem[]";
                readonly params: readonly ["supplierId: SupplierId"];
            }];
        };
    };
    export default inventoryItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs" {
    export const menuItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "MenuItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly interfaceName: "IMenuItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "MenuItem | null";
                readonly params: readonly ["menuItemId: MenuItemId"];
            }, {
                readonly name: "list";
                readonly returns: "MenuItem[]";
                readonly params: readonly ["filter: MenuItemFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["menuItem: MenuItem"];
            }, {
                readonly name: "findByCategory";
                readonly returns: "MenuItem[]";
                readonly params: readonly ["category: Category"];
            }, {
                readonly name: "findAvailable";
                readonly returns: "MenuItem[]";
                readonly params: readonly [];
            }, {
                readonly name: "findByNamePattern";
                readonly returns: "MenuItem[]";
                readonly params: readonly ["pattern: string"];
            }];
        };
    };
    export default menuItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "menuItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Order | null";
                readonly params: readonly ["orderId: OrderId"];
            }, {
                readonly name: "list";
                readonly returns: "Order[]";
                readonly params: readonly ["filter: OrderFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["order: Order"];
            }, {
                readonly name: "findByTableNumber";
                readonly returns: "Order[]";
                readonly params: readonly ["tableNumber: TableNumber"];
            }, {
                readonly name: "findByStatus";
                readonly returns: "Order[]";
                readonly params: readonly ["status: OrderStatus"];
            }, {
                readonly name: "findActiveOrders";
                readonly returns: "Order[]";
                readonly params: readonly [];
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs" {
    export const paymentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "PaymentRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly interfaceName: "IPaymentRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Payment | null";
                readonly params: readonly ["paymentId: PaymentId"];
            }, {
                readonly name: "list";
                readonly returns: "Payment[]";
                readonly params: readonly ["filter: PaymentFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["payment: Payment"];
            }, {
                readonly name: "findByOrderId";
                readonly returns: "Payment[]";
                readonly params: readonly ["orderId: OrderId"];
            }, {
                readonly name: "findByMethod";
                readonly returns: "Payment[]";
                readonly params: readonly ["method: PaymentMethod"];
            }, {
                readonly name: "findByDateRange";
                readonly returns: "Payment[]";
                readonly params: readonly ["start: Date", "end: Date"];
            }];
        };
    };
    export default paymentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "paymentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs" {
    export const addOrderItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "addOrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "addOrderItem";
            readonly ports: readonly ["Order", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "addOrderItem";
                readonly inputTypeName: "AddOrderItemInput";
                readonly outputTypeName: "AddOrderItemOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "ID of the parent Order to which the item is added";
                }, {
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "ID of the MenuItem being ordered";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantity ordered";
                }, {
                    readonly name: "observations";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Free-text observations for the kitchen";
                }];
                readonly output: readonly [{
                    readonly name: "orderItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Generated ID of the new OrderItem";
                }, {
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Parent Order ID";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Initial status of the OrderItem (new)";
                }, {
                    readonly name: "unitPrice";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Unit price copied from MenuItem";
                }, {
                    readonly name: "totalPrice";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "unitPrice * quantity";
                }, {
                    readonly name: "orderTotalAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Recalculated Order total after adding item";
                }];
                readonly ports: readonly ["Order", "MenuItem"];
                readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order by orderId via Order port", "Load MenuItem by menuItemId via MenuItem port to get current price and status", "Validate MenuItem status is 'active'", "Validate Order status allows adding items (draft or sentToKitchen) per orderStatusTransitions rule", "Create OrderItem with unitPrice from MenuItem.price, totalPrice = unitPrice * quantity, status = 'new'", "Add OrderItem to Order's items collection", "Recalculate Order.totalAmount as sum of all non-cancelled item totalPrice", "Save Order via Order port", "If Order status transitions to sentToKitchen, trigger ingredientConsumptionTrigger for stock consumption"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default addOrderItemUsecase;
    export const pipeline: readonly [{
        readonly id: "addOrderItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiPromotionSuggestions";
            readonly functionName: "aiPromotionSuggestions";
            readonly inputTypeName: "AiPromotionSuggestionsInput";
            readonly outputTypeName: "AiPromotionSuggestionsOutput";
            readonly ports: readonly ["Order", "MenuItem"];
            readonly rulesApplied: readonly [];
            readonly transactional: false;
            readonly steps: readonly ["Read recent OrderItem history via Order port", "Read MenuItem catalog via MenuItem port", "Aggregate sales frequency and revenue per MenuItem", "Generate promotion suggestions based on sales patterns", "Return structured suggestion list"];
        };
    };
    export default aiPromotionSuggestionsUsecase;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs" {
    export const aiSalesSummaryUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiSalesSummary";
            readonly functionName: "aiSalesSummary";
            readonly inputTypeName: "AiSalesSummaryInput";
            readonly outputTypeName: "AiSalesSummaryOutput";
            readonly ports: readonly ["Order", "DailyShift", "MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read DailyShift for the requested period via DailyShift port", "Read Orders within the shift via Order port", "Read MenuItem details via MenuItem port", "Aggregate totalAmount, status counts, closedAt timestamps", "Apply aiOutputLanguageSelection rule to format output language", "Generate natural-language sales summary", "Return summary with key metrics"];
        };
    };
    export default aiSalesSummaryUsecase;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs" {
    export const browseMenuForPosUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseMenuForPos";
            readonly functionName: "browseMenuForPos";
            readonly inputTypeName: "BrowseMenuForPosInput";
            readonly outputTypeName: "BrowseMenuForPosOutput";
            readonly ports: readonly ["MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read all MenuItem entries grouped by MenuCategory via MenuItem port", "Apply aiOutputLanguageSelection rule to localize item names/descriptions", "Filter out unavailable items", "Return structured menu tree for POS display"];
        };
    };
    export default browseMenuForPosUsecase;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs" {
    export const closeDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeDailyShift";
            readonly functionName: "closeDailyShift";
            readonly inputTypeName: "CloseDailyShiftInput";
            readonly outputTypeName: "CloseDailyShiftOutput";
            readonly ports: readonly ["DailyShift", "Order", "Payment"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Read current DailyShift via DailyShift port and verify status=OPEN", "Read all Orders for the shift via Order port", "Apply orderStatusTransitions rule: verify no Orders remain in OPEN or IN_PROGRESS status (close or block)", "Read all Payments via Payment port and reconcile totals", "Apply paymentTimingByOrderType rule to verify all expected payments are recorded", "Set DailyShift.status=CLOSED, closedAt, closingCashBalance, closingNotes", "Apply aiOutputLanguageSelection rule for localized close metadata", "Persist DailyShift via DailyShift port", "Invoke generateShiftCloseReport as final step", "Return close confirmation with report summary"];
        };
    };
    export default closeDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "consumeIngredientsOnConfirmation";
            readonly functionName: "consumeIngredientsOnConfirmation";
            readonly inputTypeName: "ConsumeIngredientsOnConfirmationInput";
            readonly outputTypeName: "ConsumeIngredientsOnConfirmationOutput";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order and confirmed OrderItems via Order port", "Read MenuItem recipes via MenuItem port", "Read InventoryItem stock levels via InventoryItem port", "Apply ingredientConsumptionTrigger rule to compute consumption quantities from RecipeComponent", "Validate sufficient stock for each InventoryItem", "Create StockConsumption records", "Decrement InventoryItem.currentQuantity and update status if below threshold", "Persist all changes via InventoryItem port", "Return consumption summary with any low-stock alerts"];
        };
    };
    export default consumeIngredientsOnConfirmationUsecase;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs" {
    export const createDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createDailyShift";
            readonly functionName: "createDailyShift";
            readonly inputTypeName: "CreateDailyShiftInput";
            readonly outputTypeName: "CreateDailyShiftOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Validate no open DailyShift exists for the same shiftDate via DailyShift port", "Create DailyShift entity with shiftDate, openingCashBalance, openedAt, status=OPEN", "Apply paymentTimingByOrderType rule to set expected payment flows", "Apply aiOutputLanguageSelection rule for localized shift metadata", "Persist DailyShift via DailyShift port", "Return created shift with generated dailyShiftId"];
        };
    };
    export default createDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "createDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs" {
    export const createKitchenTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createKitchenTicket";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createKitchenTicket";
            readonly functionName: "createKitchenTicket";
            readonly inputTypeName: "CreateKitchenTicketInput";
            readonly outputTypeName: "CreateKitchenTicketOutput";
            readonly ports: readonly ["Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order and its OrderItems via Order port", "Apply orderStatusTransitions rule to verify order is in a kitchen-ready status", "Build KitchenTicket from OrderItems that require preparation", "Persist KitchenTicket", "Return created ticket reference"];
        };
    };
    export default createKitchenTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "createKitchenTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly functionName: "createOrder";
            readonly inputTypeName: "CreateOrderInput";
            readonly outputTypeName: "CreateOrderOutput";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Validate DailyShift is OPEN via DailyShift port", "If orderType is DINE_IN, validate Table availability and apply tableOccupancyConsistency rule", "Apply paymentTimingByOrderType rule to determine payment expectations", "Create Order entity with status=OPEN, link to DailyShift and optional Table", "Apply orderStatusTransitions rule for initial state", "Apply aiOutputLanguageSelection rule for localized order metadata", "Persist Order via Order port", "If Table assigned, update Table status to OCCUPIED", "Return created order with generated orderId"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs" {
    export const createStockConsumptionUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createStockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createStockConsumption";
            readonly functionName: "createStockConsumption";
            readonly inputTypeName: "CreateStockConsumptionInput";
            readonly outputTypeName: "CreateStockConsumptionOutput";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order and OrderItems via Order port", "Read MenuItem recipes via MenuItem port", "Read InventoryItem current quantities via InventoryItem port", "Apply ingredientConsumptionTrigger rule to compute required quantities from RecipeComponent", "Validate sufficient stock for each InventoryItem", "Create StockConsumption records per InventoryItem", "Decrement InventoryItem.currentQuantity", "Persist updated InventoryItem via InventoryItem port", "Return consumption summary"];
        };
    };
    export default createStockConsumptionUsecase;
    export const pipeline: readonly [{
        readonly id: "createStockConsumption__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "dineInOrderLifecycle";
            readonly functionName: "dineInOrderLifecycle";
            readonly inputTypeName: "DineInOrderLifecycleInput";
            readonly outputTypeName: "DineInOrderLifecycleOutput";
            readonly ports: readonly ["Order", "MenuItem", "Payment", "InventoryItem"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 — Create Order: invoke createOrder with orderType=DINE_IN, assign Table (apply tableOccupancyConsistency)", "Step 2 — Add Items: invoke addOrderItem for each requested MenuItem (apply orderStatusTransitions)", "Step 3 — Send to Kitchen: invoke createKitchenTicket for the order", "Step 4 — Kitchen Production: invoke updateKitchenTicketStatus and updateOrderItemStatus as items are prepared", "Step 5 — Consume Ingredients: invoke consumeIngredientsOnConfirmation when items are confirmed (apply ingredientConsumptionTrigger via InventoryItem port)", "Step 6 — Record Payment: invoke recordPayment (apply paymentTimingByOrderType — dine-in pays after consumption)", "Step 7 — Close Order: invoke updateOrderStatus to CLOSED, release Table (apply tableOccupancyConsistency)", "Apply aiOutputLanguageSelection rule throughout for localized communication", "Return full lifecycle result with order, ticket, payment, and consumption references"];
        };
    };
    export default dineInOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "generateShiftCloseReport";
            readonly functionName: "generateShiftCloseReport";
            readonly inputTypeName: "GenerateShiftCloseReportInput";
            readonly outputTypeName: "GenerateShiftCloseReportOutput";
            readonly ports: readonly ["DailyShift", "Payment", "Order"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read DailyShift via DailyShift port", "Read all Payments for the shift via Payment port", "Read all Orders for the shift via Order port", "Read OrderItems for revenue breakdown", "Apply paymentTimingByOrderType rule to categorize payments", "Compute totalSales, totalPayments, cash reconciliation", "Apply aiOutputLanguageSelection rule for report language", "Return structured shift close report"];
        };
    };
    export default generateShiftCloseReportUsecase;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "kitchenProductionFlow";
            readonly functionName: "kitchenProductionFlow";
            readonly inputTypeName: "KitchenProductionFlowInput";
            readonly outputTypeName: "KitchenProductionFlowOutput";
            readonly ports: readonly ["Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 — Receive Order: read Order and its OrderItems via Order port", "Step 2 — Create Ticket: invoke createKitchenTicket (apply orderStatusTransitions)", "Step 3 — Track Progress: invoke updateOrderItemStatus as each item progresses (PENDING → IN_PROGRESS → READY)", "Step 4 — Update Ticket: invoke updateKitchenTicketStatus when all items are READY (apply orderStatusTransitions)", "Step 5 — Trigger Consumption: apply ingredientConsumptionTrigger rule when items are confirmed", "Return production flow result with ticket and item statuses"];
        };
    };
    export default kitchenProductionFlowUsecase;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs" {
    export const manageInventoryItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageInventoryItems";
            readonly functionName: "manageInventoryItems";
            readonly inputTypeName: "ManageInventoryItemsInput";
            readonly outputTypeName: "ManageInventoryItemsOutput";
            readonly ports: readonly ["InventoryItem"];
            readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read existing InventoryItem via InventoryItem port (for updates)", "Validate input fields (name, unit, currentQuantity, minimumLevel)", "Create or update InventoryItem entity", "Apply inventoryLowStockThreshold rule to set status=LOW_STOCK if below minimumLevel", "Apply ingredientConsumptionTrigger rule to verify item is not locked by pending consumptions", "Persist InventoryItem via InventoryItem port", "Return updated item"];
        };
    };
    export default manageInventoryItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs" {
    export const manageMenuCategoriesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuCategories";
            readonly functionName: "manageMenuCategories";
            readonly inputTypeName: "ManageMenuCategoriesInput";
            readonly outputTypeName: "ManageMenuCategoriesOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Validate category name uniqueness", "Create or update MenuCategory entity", "Persist via repository", "Return category"];
        };
    };
    export default manageMenuCategoriesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs" {
    export const manageMenuItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuItems";
            readonly functionName: "manageMenuItems";
            readonly inputTypeName: "ManageMenuItemsInput";
            readonly outputTypeName: "ManageMenuItemsOutput";
            readonly ports: readonly ["MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Read existing MenuItem via MenuItem port (for updates)", "Validate referenced MenuCategory exists", "Apply aiOutputLanguageSelection rule for localized name/description fields", "Create or update MenuItem entity", "Persist MenuItem via MenuItem port", "Return updated item"];
        };
    };
    export default manageMenuItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs" {
    export const manageTablesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageTables";
            readonly functionName: "manageTables";
            readonly inputTypeName: "ManageTablesInput";
            readonly outputTypeName: "ManageTablesOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly ["tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Read existing Table (for updates)", "Apply tableOccupancyConsistency rule to prevent changes that conflict with active orders", "Create or update Table entity", "Persist via repository", "Return table"];
        };
    };
    export default manageTablesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageTables__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs" {
    export const openDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "openDailyShift";
            readonly functionName: "openDailyShift";
            readonly inputTypeName: "OpenDailyShiftInput";
            readonly outputTypeName: "OpenDailyShiftOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 — Create Shift: invoke createDailyShift with shiftDate, openingCashBalance (apply paymentTimingByOrderType, aiOutputLanguageSelection)", "Step 2 — Record Opening Cash: invoke recordOpeningCashMovement with opening cash amount and reason", "Step 3 — Verify: read DailyShift to confirm status=OPEN and cash movement recorded", "Return shift opening confirmation with dailyShiftId and opening balance"];
        };
    };
    export default openDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs" {
    export const recordOpeningCashMovementUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordOpeningCashMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordOpeningCashMovement";
            readonly functionName: "recordOpeningCashMovement";
            readonly inputTypeName: "RecordOpeningCashMovementInput";
            readonly outputTypeName: "RecordOpeningCashMovementOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Validate DailyShift exists and is OPEN via DailyShift port", "Create CashMovement entity with movementType=OPENING, amount, reason", "Link CashMovement to dailyShiftId", "Persist CashMovement", "Return created movement"];
        };
    };
    export default recordOpeningCashMovementUsecase;
    export const pipeline: readonly [{
        readonly id: "recordOpeningCashMovement__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs" {
    export const recordPaymentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordPayment";
            readonly functionName: "recordPayment";
            readonly inputTypeName: "RecordPaymentInput";
            readonly outputTypeName: "RecordPaymentOutput";
            readonly ports: readonly ["Payment", "Order", "DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order via Order port to verify it exists and accepts payments", "Read DailyShift via DailyShift port to verify shift is OPEN", "Apply paymentTimingByOrderType rule to validate payment timing is allowed for orderType", "Create Payment entity linked to Order and DailyShift", "Persist Payment via Payment port", "Update Order payment status if fully paid", "Return recorded payment"];
        };
    };
    export default recordPaymentUsecase;
    export const pipeline: readonly [{
        readonly id: "recordPayment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "takeoutOrderLifecycle";
            readonly functionName: "takeoutOrderLifecycle";
            readonly inputTypeName: "TakeoutOrderLifecycleInput";
            readonly outputTypeName: "TakeoutOrderLifecycleOutput";
            readonly ports: readonly ["Order", "MenuItem", "Payment", "InventoryItem"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 — Create Order: invoke createOrder with orderType=TAKEOUT (no Table assignment, no tableOccupancyConsistency)", "Step 2 — Add Items: invoke addOrderItem for each requested MenuItem (apply orderStatusTransitions)", "Step 3 — Record Payment: invoke recordPayment (apply paymentTimingByOrderType — takeout pays upfront before preparation)", "Step 4 — Send to Kitchen: invoke createKitchenTicket for the order", "Step 5 — Kitchen Production: invoke updateKitchenTicketStatus and updateOrderItemStatus as items are prepared", "Step 6 — Consume Ingredients: invoke consumeIngredientsOnConfirmation when items are confirmed (apply ingredientConsumptionTrigger via InventoryItem port)", "Step 7 — Close Order: invoke updateOrderStatus to CLOSED (no Table release needed)", "Apply aiOutputLanguageSelection rule throughout for localized communication", "Return full lifecycle result with order, ticket, payment, and consumption references"];
        };
    };
    export default takeoutOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs" {
    export const updateKitchenTicketStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateKitchenTicketStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateKitchenTicketStatus";
            readonly functionName: "updateKitchenTicketStatus";
            readonly inputTypeName: "UpdateKitchenTicketStatusInput";
            readonly outputTypeName: "UpdateKitchenTicketStatusOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly ["orderStatusTransitions"];
            readonly transactional: true;
            readonly steps: readonly ["Read KitchenTicket by id", "Apply orderStatusTransitions rule to validate target status is reachable from current", "Update KitchenTicket.status and updatedAt", "Persist via repository", "Return updated ticket"];
        };
    };
    export default updateKitchenTicketStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateKitchenTicketStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs" {
    export const updateOrderItemStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderItemStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderItemStatus";
            readonly functionName: "updateOrderItemStatus";
            readonly inputTypeName: "UpdateOrderItemStatusInput";
            readonly outputTypeName: "UpdateOrderItemStatusOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read OrderItem by id", "Apply orderStatusTransitions rule to validate target status is reachable", "Update OrderItem.status and updatedAt", "If status transitions to CONFIRMED, apply ingredientConsumptionTrigger rule to enqueue stock consumption", "Persist via repository", "Return updated item"];
        };
    };
    export default updateOrderItemStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderItemStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly functionName: "updateOrderStatus";
            readonly inputTypeName: "UpdateOrderStatusInput";
            readonly outputTypeName: "UpdateOrderStatusOutput";
            readonly ports: readonly ["Order", "Payment", "InventoryItem"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order with OrderItems, KitchenTickets, Payments via Order port", "Apply orderStatusTransitions rule to validate target status is reachable from current", "If transitioning to CLOSED: apply paymentTimingByOrderType rule to verify all payments settled", "If transitioning to CLOSED: apply ingredientConsumptionTrigger rule to ensure stock consumed via InventoryItem port", "If transitioning to CLOSED: set closedAt, release Table (apply tableOccupancyConsistency rule)", "If transitioning to CANCELLED: set cancelledAt and cancellationReason, release Table", "Apply aiOutputLanguageSelection rule for localized status metadata", "Update Order.status and updatedAt", "If Table released, update Table status to AVAILABLE", "Persist Order via Order port", "Return updated order"];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs" {
    export const updateTableStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTableStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTableStatus";
            readonly functionName: "updateTableStatus";
            readonly inputTypeName: "UpdateTableStatusInput";
            readonly outputTypeName: "UpdateTableStatusOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly ["tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Read Table by id", "Apply tableOccupancyConsistency rule to validate status change does not conflict with active orders", "Update Table.status and updatedAt", "Persist via repository", "Return updated table"];
        };
    };
    export default updateTableStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTableStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs" {
    export const viewKitchenTicketsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewKitchenTickets";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewKitchenTickets";
            readonly functionName: "viewKitchenTickets";
            readonly inputTypeName: "ViewKitchenTicketsInput";
            readonly outputTypeName: "ViewKitchenTicketsOutput";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly transactional: false;
            readonly steps: readonly ["Read KitchenTickets filtered by status/date via repository", "Return list of tickets with associated order references"];
        };
    };
    export default viewKitchenTicketsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewKitchenTickets__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewOperationalDashboard";
            readonly functionName: "viewOperationalDashboard";
            readonly inputTypeName: "ViewOperationalDashboardInput";
            readonly outputTypeName: "ViewOperationalDashboardOutput";
            readonly ports: readonly ["DailyShift", "Order", "Payment"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read current DailyShift via DailyShift port", "Read active Orders for the shift via Order port", "Read Payments for the shift via Payment port", "Read CashMovements for the shift", "Apply paymentTimingByOrderType rule to categorize revenue", "Apply aiOutputLanguageSelection rule for dashboard labels", "Compute real-time metrics: open orders, revenue, kitchen load", "Return dashboard data structure"];
        };
    };
    export default viewOperationalDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs" {
    export const dailyShiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly fields: readonly [{
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno diário.";
            }, {
                readonly fieldId: "shiftDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Data operacional do turno.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado atual do turno.";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de abertura do turno.";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora de fechamento do turno.";
            }, {
                readonly fieldId: "openingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor inicial em caixa ao abrir o turno.";
            }, {
                readonly fieldId: "closingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor final em caixa ao fechar o turno.";
            }, {
                readonly fieldId: "totalSales";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de vendas no turno.";
            }, {
                readonly fieldId: "totalPayments";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de pagamentos recebidos no turno.";
            }, {
                readonly fieldId: "closingNotes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações e relatório de fechamento do turno.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly invariants: readonly ["only one DailyShift with status 'open' per shiftDate", "status transitions: open -> closed; once closed it cannot be reopened", "when status is 'closed', closedAt must be set", "when status is 'closed', closingCashBalance and totalSales must be set", "openingCashBalance must be >= 0 when provided", "closingCashBalance must be >= 0 when provided", "cannot add CashMovements to a closed shift", "CashMovement.amount must be > 0", "CashMovement.movementType determines whether amount is added (entrada) or subtracted (saída) from cash balance"];
            readonly valueObjects: readonly [{
                readonly name: "CashMovement";
                readonly fields: readonly [{
                    readonly fieldId: "cashMovementId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do movimento de caixa";
                }, {
                    readonly fieldId: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao turno (DailyShift) ao qual o movimento pertence";
                }, {
                    readonly fieldId: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo do movimento: entrada ou saída de caixa";
                    readonly enum: readonly ["entrada", "saída"];
                }, {
                    readonly fieldId: "amount";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Valor do movimento";
                }, {
                    readonly fieldId: "reason";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Motivo do movimento (ex.: sangria, reforço, estorno)";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default dailyShiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "dailyShift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs" {
    export const inventoryItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly fields: readonly [{
                readonly fieldId: "inventoryItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item de estoque";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do ingrediente ou insumo";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida (ex.: kg, L, unidade, gramas)";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual disponível em estoque";
            }, {
                readonly fieldId: "minimumLevel";
                readonly type: "number";
                readonly required: true;
                readonly description: "Nível mínimo para geração de alerta de baixo estoque";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["active", "inactive"];
            readonly invariants: readonly ["currentQuantity must be >= 0", "minimumLevel must be >= 0", "name must not be empty or whitespace", "unit must not be empty or whitespace", "status transitions: active -> inactive; inactive -> active allowed", "low-stock alert is raised when currentQuantity <= minimumLevel"];
            readonly valueObjects: readonly [];
        };
    };
    export default inventoryItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs" {
    export const menuItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly fields: readonly [{
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item do cardápio";
            }, {
                readonly fieldId: "menuCategoryId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à categoria do cardápio à qual o item pertence";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do item (ex.: cappuccino, pão de queijo)";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "price";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço de venda do item";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["draft", "active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "active", "inactive"];
            readonly invariants: readonly ["price must be >= 0", "name must not be empty or whitespace", "status transitions: draft -> active -> inactive; inactive -> active allowed", "cannot delete a MenuItem that is referenced by active Orders", "each RecipeComponent.inventoryItemId must be unique within the MenuItem", "RecipeComponent.quantity must be > 0"];
            readonly valueObjects: readonly [{
                readonly name: "RecipeComponent";
                readonly fields: readonly [{
                    readonly fieldId: "recipeComponentId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do componente de receita";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de menu ao qual este componente pertence";
                }, {
                    readonly fieldId: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de inventário utilizado como ingrediente";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade consumida do item de inventário por unidade vendida do menu item";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default menuItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "menuItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Turno diário em que o pedido foi registrado";
            }, {
                readonly fieldId: "tableId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência à mesa associada (para pedidos do tipo mesa)";
            }, {
                readonly fieldId: "kitchenTicketId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Ticket de cozinha gerado para fila de preparo";
            }, {
                readonly fieldId: "orderType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do pedido: mesa ou takeout";
                readonly enum: readonly ["mesa", "takeout"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido na coordenação com a cozinha";
                readonly enum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            }, {
                readonly fieldId: "totalAmount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total do pedido com preços no momento da venda";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações gerais do pedido";
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: false;
                readonly description: "Nome do cliente para identificação do pedido";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do cliente";
            }, {
                readonly fieldId: "numberOfGuests";
                readonly type: "number";
                readonly required: false;
                readonly description: "Número de pessoas na mesa";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do fechamento do pedido";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do cancelamento do pedido";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            readonly invariants: readonly ["totalAmount must equal the sum of all OrderItem.totalPrice", "when orderType is 'mesa', tableId is required", "when orderType is 'takeout', tableId must be null", "status transitions: draft -> sentToKitchen -> inPreparation -> ready -> served -> closed; draft or any pre-closed state -> cancelled allowed", "when status is 'closed', closedAt must be set", "when status is 'cancelled', cancelledAt and cancellationReason must be set", "cannot add or modify OrderItems after status is sentToKitchen", "OrderItem.quantity must be > 0", "OrderItem.totalPrice must equal OrderItem.quantity * OrderItem.unitPrice", "OrderItem.status transitions: new -> sentToKitchen -> inPreparation -> ready -> served; any pre-served -> cancelled", "KitchenTicket.status transitions: open -> inProgress -> done; open or inProgress -> void", "at least one OrderItem is required before sending to kitchen"];
            readonly valueObjects: readonly [{
                readonly name: "OrderItem";
                readonly fields: readonly [{
                    readonly fieldId: "id";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do pedido";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido (Order) ao qual este item pertence";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio (MenuItem) solicitado";
                }, {
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly description: "Referência ao ticket de cozinha (KitchenTicket) quando o item exige preparo";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade solicitada do item";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do item no momento do pedido";
                }, {
                    readonly fieldId: "totalPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço total do item (quantidade × preço unitário)";
                }, {
                    readonly fieldId: "observations";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações ou instruções especiais para o item";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status de produção/atendimento do item";
                    readonly enum: readonly ["new", "sentToKitchen", "inPreparation", "ready", "served", "cancelled"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }, {
                readonly name: "KitchenTicket";
                readonly fields: readonly [{
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do ticket de cozinha";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido que gerou este ticket para a fila de preparo";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual do ticket na fila de preparo da cozinha";
                    readonly enum: readonly ["open", "inProgress", "done", "void"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do ticket";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do ticket";
                }];
                readonly collection: true;
            }];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs" {
    export const paymentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly fields: readonly [{
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pagamento.";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao pedido associado ao pagamento, quando aplicável.";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao turno diário de fechamento ao qual o pagamento será consolidado.";
            }, {
                readonly fieldId: "method";
                readonly type: "string";
                readonly required: true;
                readonly description: "Método de pagamento utilizado (ex.: dinheiro, cartão de crédito, PIX).";
            }, {
                readonly fieldId: "amount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor recebido/pago.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do pagamento no ciclo de vida.";
                readonly enum: readonly ["authorized", "captured", "voided", "refunded"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["authorized", "captured", "voided", "refunded"];
            readonly invariants: readonly ["amount must be > 0", "method must not be empty or whitespace", "status transitions: authorized -> captured; authorized -> voided; captured -> refunded", "cannot void a payment that is already captured (must refund instead)", "cannot refund a payment that is not captured", "dailyShiftId must reference an open DailyShift when payment is captured", "sum of all Payment.amount for an Order must not exceed Order.totalAmount"];
            readonly valueObjects: readonly [];
        };
    };
    export default paymentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "payment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageTables.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        action?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        action?: undefined;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                    stateKey?: undefined;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        stateKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageTables.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/shared/recordPayment.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        action?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "aiPromotionSuggestions.section.main.title": string;
            "aiPromotionSuggestions.organism.main.title": string;
            "aiPromotionSuggestions.intent.query.title": string;
            "aiPromotionSuggestions.field.id.label": string;
            "aiPromotionSuggestions.field.orderId.label": string;
            "aiPromotionSuggestions.field.menuItemId.label": string;
            "aiPromotionSuggestions.field.kitchenTicketId.label": string;
            "aiPromotionSuggestions.field.quantity.label": string;
            "aiPromotionSuggestions.field.unitPrice.label": string;
            "aiPromotionSuggestions.field.totalPrice.label": string;
            "aiPromotionSuggestions.field.observations.label": string;
            "aiPromotionSuggestions.filter.id.label": string;
            "aiPromotionSuggestions.filter.orderId.label": string;
            "aiPromotionSuggestions.filter.menuItemId.label": string;
            "aiPromotionSuggestions.filter.kitchenTicketId.label": string;
            "aiPromotionSuggestions.filter.status.label": string;
            "aiPromotionSuggestions.filter.createdAt.label": string;
            "aiPromotionSuggestions.action.run.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "aiSalesSummary.section.main.title": string;
            "aiSalesSummary.organism.main.title": string;
            "aiSalesSummary.intent.filters.title": string;
            "aiSalesSummary.intent.results.title": string;
            "aiSalesSummary.field.dailyShiftId.label": string;
            "aiSalesSummary.field.status.label": string;
            "aiSalesSummary.field.closedAt.label": string;
            "aiSalesSummary.action.run.label": string;
            "aiSalesSummary.col.dailyShiftId.label": string;
            "aiSalesSummary.col.status.label": string;
            "aiSalesSummary.col.totalAmount.label": string;
            "aiSalesSummary.col.closedAt.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "browseMenuForPos.page.title": string;
            "browseMenuForPos.section.menu.title": string;
            "browseMenuForPos.organism.menu.title": string;
            "browseMenuForPos.intent.list.title": string;
            "browseMenuForPos.filter.menuItemId.label": string;
            "browseMenuForPos.filter.menuCategoryId.label": string;
            "browseMenuForPos.filter.name.label": string;
            "browseMenuForPos.filter.status.label": string;
            "browseMenuForPos.filter.createdAt.label": string;
            "browseMenuForPos.filter.updatedAt.label": string;
            "browseMenuForPos.column.menuItemId.label": string;
            "browseMenuForPos.column.menuCategoryId.label": string;
            "browseMenuForPos.column.name.label": string;
            "browseMenuForPos.column.description.label": string;
            "browseMenuForPos.column.price.label": string;
            "browseMenuForPos.column.status.label": string;
            "browseMenuForPos.column.createdAt.label": string;
            "browseMenuForPos.column.updatedAt.label": string;
            "browseMenuForPos.toolbar.search.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "closeDailyShift.section.main.title": string;
            "closeDailyShift.organism.updateDailyShiftStatus.title": string;
            "closeDailyShift.organism.recordClosingCashMovement.title": string;
            "closeDailyShift.intent.updateDailyShiftStatus.title": string;
            "closeDailyShift.intent.recordClosingCashMovement.title": string;
            "closeDailyShift.field.dailyShiftId.label": string;
            "closeDailyShift.field.shiftDate.label": string;
            "closeDailyShift.field.status.label": string;
            "closeDailyShift.field.openedAt.label": string;
            "closeDailyShift.field.closedAt.label": string;
            "closeDailyShift.field.openingCashBalance.label": string;
            "closeDailyShift.field.closingCashBalance.label": string;
            "closeDailyShift.field.totalSales.label": string;
            "closeDailyShift.field.totalPayments.label": string;
            "closeDailyShift.field.closingNotes.label": string;
            "closeDailyShift.action.updateDailyShiftStatus.label": string;
            "closeDailyShift.action.recordClosingCashMovement.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "consumeIngredientsOnConfirmation.section.main.title": string;
            "consumeIngredientsOnConfirmation.organism.createStockConsumption.title": string;
            "consumeIngredientsOnConfirmation.intent.createStockConsumption.form.title": string;
            "consumeIngredientsOnConfirmation.field.quantity.label": string;
            "consumeIngredientsOnConfirmation.field.status.label": string;
            "consumeIngredientsOnConfirmation.field.consumedAt.label": string;
            "consumeIngredientsOnConfirmation.action.createStockConsumption.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "section.dineInOrderLifecycle.title": string;
            "organism.createOrder.title": string;
            "intent.createOrder.form.title": string;
            "field.createOrder.orderType": string;
            "field.createOrder.status": string;
            "field.createOrder.totalAmount": string;
            "field.createOrder.notes": string;
            "field.createOrder.customerName": string;
            "field.createOrder.customerPhone": string;
            "field.createOrder.numberOfGuests": string;
            "field.createOrder.closedAt": string;
            "field.createOrder.cancelledAt": string;
            "field.createOrder.cancellationReason": string;
            "action.createOrder.submit": string;
            "organism.addOrderItem.title": string;
            "intent.addOrderItem.form.title": string;
            "field.addOrderItem.quantity": string;
            "field.addOrderItem.unitPrice": string;
            "field.addOrderItem.totalPrice": string;
            "field.addOrderItem.observations": string;
            "field.addOrderItem.status": string;
            "action.addOrderItem.submit": string;
            "organism.createKitchenTicket.title": string;
            "intent.createKitchenTicket.form.title": string;
            "field.createKitchenTicket.status": string;
            "action.createKitchenTicket.submit": string;
            "organism.updateOrderStatus.title": string;
            "intent.updateOrderStatus.form.title": string;
            "field.updateOrderStatus.status": string;
            "field.updateOrderStatus.closedAt": string;
            "field.updateOrderStatus.cancelledAt": string;
            "field.updateOrderStatus.cancellationReason": string;
            "action.updateOrderStatus.submit": string;
            "organism.updateTableStatus.title": string;
            "intent.updateTableStatus.form.title": string;
            "field.updateTableStatus.status": string;
            "action.updateTableStatus.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "generateShiftCloseReport.section.title": string;
            "generateShiftCloseReport.organism.title": string;
            "generateShiftCloseReport.filters.title": string;
            "generateShiftCloseReport.filters.status": string;
            "generateShiftCloseReport.filters.openedAt": string;
            "generateShiftCloseReport.filters.closedAt": string;
            "generateShiftCloseReport.actions.generate": string;
            "generateShiftCloseReport.summary.title": string;
            "generateShiftCloseReport.summary.status": string;
            "generateShiftCloseReport.summary.openedAt": string;
            "generateShiftCloseReport.summary.closedAt": string;
            "generateShiftCloseReport.summary.openingCashBalance": string;
            "generateShiftCloseReport.summary.closingCashBalance": string;
            "generateShiftCloseReport.summary.totalSales": string;
            "generateShiftCloseReport.summary.totalPayments": string;
            "generateShiftCloseReport.summary.closingNotes": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "kitchenProductionFlow.section.main.title": string;
            "kitchenProductionFlow.organism.viewKitchenTickets.title": string;
            "kitchenProductionFlow.intent.viewKitchenTickets.queryList.title": string;
            "kitchenProductionFlow.field.kitchenTicketId.label": string;
            "kitchenProductionFlow.field.orderId.label": string;
            "kitchenProductionFlow.field.status.label": string;
            "kitchenProductionFlow.field.createdAt.label": string;
            "kitchenProductionFlow.field.updatedAt.label": string;
            "kitchenProductionFlow.filter.kitchenTicketId.label": string;
            "kitchenProductionFlow.filter.orderId.label": string;
            "kitchenProductionFlow.filter.status.label": string;
            "kitchenProductionFlow.filter.createdAt.label": string;
            "kitchenProductionFlow.filter.updatedAt.label": string;
            "kitchenProductionFlow.action.viewKitchenTickets.label": string;
            "kitchenProductionFlow.organism.updateKitchenTicketStatus.title": string;
            "kitchenProductionFlow.intent.updateKitchenTicketStatus.commandForm.title": string;
            "kitchenProductionFlow.field.kitchenTicketStatus.label": string;
            "kitchenProductionFlow.action.updateKitchenTicketStatus.label": string;
            "kitchenProductionFlow.organism.updateOrderItemStatus.title": string;
            "kitchenProductionFlow.intent.updateOrderItemStatus.commandForm.title": string;
            "kitchenProductionFlow.field.orderItemStatus.label": string;
            "kitchenProductionFlow.action.updateOrderItemStatus.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageInventoryItems.section.main.title": string;
            "manageInventoryItems.organism.form.title": string;
            "manageInventoryItems.intention.status.title": string;
            "manageInventoryItems.intention.form.title": string;
            "manageInventoryItems.field.name.label": string;
            "manageInventoryItems.field.description.label": string;
            "manageInventoryItems.field.unit.label": string;
            "manageInventoryItems.field.currentQuantity.label": string;
            "manageInventoryItems.field.minimumLevel.label": string;
            "manageInventoryItems.field.status.label": string;
            "manageInventoryItems.action.submit.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageMenuCategories.section.title": string;
            "manageMenuCategories.organism.title": string;
            "manageMenuCategories.form.title": string;
            "manageMenuCategories.field.menuCategoryId": string;
            "manageMenuCategories.field.name": string;
            "manageMenuCategories.field.description": string;
            "manageMenuCategories.field.status": string;
            "manageMenuCategories.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageMenuItems.section.title": string;
            "manageMenuItems.organism.title": string;
            "manageMenuItems.form.title": string;
            "manageMenuItems.actions.title": string;
            "manageMenuItems.field.menuItemId": string;
            "manageMenuItems.field.menuCategoryId": string;
            "manageMenuItems.field.name": string;
            "manageMenuItems.field.description": string;
            "manageMenuItems.field.price": string;
            "manageMenuItems.field.status": string;
            "manageMenuItems.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageTables.section.title": string;
            "manageTables.organism.title": string;
            "manageTables.form.title": string;
            "manageTables.field.tableId": string;
            "manageTables.field.number": string;
            "manageTables.field.status": string;
            "manageTables.action.submit": string;
            "manageTables.status.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "openDailyShift.section.main.title": string;
            "openDailyShift.organism.createDailyShift.title": string;
            "openDailyShift.intention.createDailyShift.form.title": string;
            "openDailyShift.field.createDailyShift.shiftDate.label": string;
            "openDailyShift.field.createDailyShift.status.label": string;
            "openDailyShift.field.createDailyShift.openedAt.label": string;
            "openDailyShift.field.createDailyShift.openingCashBalance.label": string;
            "openDailyShift.action.createDailyShift.submit.label": string;
            "openDailyShift.organism.recordOpeningCashMovement.title": string;
            "openDailyShift.intention.recordOpeningCashMovement.form.title": string;
            "openDailyShift.field.recordOpeningCashMovement.movementType.label": string;
            "openDailyShift.field.recordOpeningCashMovement.amount.label": string;
            "openDailyShift.field.recordOpeningCashMovement.reason.label": string;
            "openDailyShift.action.recordOpeningCashMovement.submit.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts", "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "recordPayment.section.title": string;
            "recordPayment.organism.title": string;
            "recordPayment.form.title": string;
            "recordPayment.field.method": string;
            "recordPayment.field.amount": string;
            "recordPayment.field.status": string;
            "recordPayment.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts", "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "takeoutOrderLifecycle.section.main.title": string;
            "takeoutOrderLifecycle.createOrder.title": string;
            "takeoutOrderLifecycle.createOrder.form.title": string;
            "takeoutOrderLifecycle.createOrder.orderType.label": string;
            "takeoutOrderLifecycle.createOrder.status.label": string;
            "takeoutOrderLifecycle.createOrder.totalAmount.label": string;
            "takeoutOrderLifecycle.createOrder.notes.label": string;
            "takeoutOrderLifecycle.createOrder.customerName.label": string;
            "takeoutOrderLifecycle.createOrder.customerPhone.label": string;
            "takeoutOrderLifecycle.createOrder.numberOfGuests.label": string;
            "takeoutOrderLifecycle.createOrder.closedAt.label": string;
            "takeoutOrderLifecycle.createOrder.cancelledAt.label": string;
            "takeoutOrderLifecycle.createOrder.cancellationReason.label": string;
            "takeoutOrderLifecycle.createOrder.submit": string;
            "takeoutOrderLifecycle.addOrderItem.title": string;
            "takeoutOrderLifecycle.addOrderItem.form.title": string;
            "takeoutOrderLifecycle.addOrderItem.quantity.label": string;
            "takeoutOrderLifecycle.addOrderItem.unitPrice.label": string;
            "takeoutOrderLifecycle.addOrderItem.totalPrice.label": string;
            "takeoutOrderLifecycle.addOrderItem.observations.label": string;
            "takeoutOrderLifecycle.addOrderItem.status.label": string;
            "takeoutOrderLifecycle.addOrderItem.submit": string;
            "takeoutOrderLifecycle.createKitchenTicket.title": string;
            "takeoutOrderLifecycle.createKitchenTicket.form.title": string;
            "takeoutOrderLifecycle.createKitchenTicket.status.label": string;
            "takeoutOrderLifecycle.createKitchenTicket.submit": string;
            "takeoutOrderLifecycle.updateOrderStatus.title": string;
            "takeoutOrderLifecycle.updateOrderStatus.form.title": string;
            "takeoutOrderLifecycle.updateOrderStatus.status.label": string;
            "takeoutOrderLifecycle.updateOrderStatus.closedAt.label": string;
            "takeoutOrderLifecycle.updateOrderStatus.cancelledAt.label": string;
            "takeoutOrderLifecycle.updateOrderStatus.cancellationReason.label": string;
            "takeoutOrderLifecycle.updateOrderStatus.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "viewOperationalDashboard.section.title": string;
            "viewOperationalDashboard.organism.title": string;
            "viewOperationalDashboard.filters.title": string;
            "viewOperationalDashboard.field.dailyShiftId": string;
            "viewOperationalDashboard.field.shiftDate": string;
            "viewOperationalDashboard.field.status": string;
            "viewOperationalDashboard.field.openedAt": string;
            "viewOperationalDashboard.field.closedAt": string;
            "viewOperationalDashboard.field.createdAt": string;
            "viewOperationalDashboard.action.run": string;
            "viewOperationalDashboard.summary.title": string;
            "viewOperationalDashboard.summary.dailyShiftId": string;
            "viewOperationalDashboard.summary.shiftDate": string;
            "viewOperationalDashboard.summary.status": string;
            "viewOperationalDashboard.summary.openedAt": string;
            "viewOperationalDashboard.summary.closedAt": string;
            "viewOperationalDashboard.summary.openingCashBalance": string;
            "viewOperationalDashboard.summary.closingCashBalance": string;
            "viewOperationalDashboard.summary.totalSales": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
